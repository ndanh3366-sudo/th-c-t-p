const fs = require('fs');
const path = require('path');

const cwd = process.cwd();
const publicDir = path.join(cwd, 'public');

function getAllPublicFiles(dir) {
  let results = [];
  const list = fs.readdirSync(dir);
  list.forEach(file => {
    const filePath = path.join(dir, file);
    const stat = fs.statSync(filePath);
    if (stat && stat.isDirectory()) {
      results = results.concat(getAllPublicFiles(filePath));
    } else {
      const rel = filePath.substring(publicDir.length).replace(/\\/g, '/');
      results.push(rel);
    }
  });
  return results;
}

const anhFiles = getAllPublicFiles(publicDir).filter(f => f.startsWith('/anh/'));

const products = [
  // DX Belts
  { id: 'p-dx-01', name: 'Kamen Rider Zeztz DX Henshin Belt Lord Invoker', code: 'BANDAI-DX-ZEZTS-01', category: 'dx-belt', era: 'Reiwa', series: 'Kamen Rider Zeztz', price: 1850000, originalPrice: 2150000, isFlashSale: true, flashSaleEndTime: '2026-07-31T23:59:59Z', flashSaleStock: 12, soldCount: 340, stock: 28, rating: 5.0, reviewCount: 112, isHot: true, isNew: true, condition: 'New Seal 100%', description: 'Đai biến hình chính hãng Kamen Rider Zeztz DX Henshin Belt Lord Invoker. Tích hợp âm thanh biến hình uy lực, hiệu ứng LED rực rỡ và cơ chế gạt chốt biến hình cực ấn tượng.' },
  { id: 'p-dx-02', name: 'Kamen Rider Zeztz DX Rider Capsem Set 02', code: 'BANDAI-DX-CAPSEM-02', category: 'dx-belt', era: 'Reiwa', series: 'Kamen Rider Zeztz', price: 650000, originalPrice: 850000, soldCount: 210, stock: 35, rating: 4.9, reviewCount: 45, isHot: false, isNew: true, condition: 'New Seal 100%', description: 'Bộ Capsem mở rộng Set 02 dùng cho đai Lord Invoker, mở khóa các dạng biến hình tuyệt chiêu mới.' },
  { id: 'p-dx-03', name: 'Super Best DX Sengoku Driver Kamen Rider Gaim & Baron Set', code: 'BANDAI-DX-GAIM-SB', category: 'dx-belt', era: 'Heisei', series: 'Kamen Rider Gaim', price: 2450000, originalPrice: 2850000, isFlashSale: true, flashSaleEndTime: '2026-07-31T23:59:59Z', flashSaleStock: 6, soldCount: 520, stock: 14, rating: 5.0, reviewCount: 198, isHot: true, isNew: false, condition: 'New Seal 100%', description: 'Tái bản Super Best của đai Sengoku Driver kèm Lockseed Cam và Chuối đặc trưng của Gaim & Baron.' },
  { id: 'p-dx-04', name: 'Kamen Rider Gavv DX Gavv Driver & Poppingummy Gochizo', code: 'BANDAI-DX-GAVV-01', category: 'dx-belt', era: 'Reiwa', series: 'Kamen Rider Gavv', price: 1750000, originalPrice: 2050000, soldCount: 480, stock: 20, rating: 5.0, reviewCount: 160, isHot: true, isNew: true, condition: 'New Seal 100%', description: 'Đai biến hình Gavv Driver có cơ chế nhai kẹo Gochizo phát âm thanh vô cùng nhộn nhịp.' },
  { id: 'p-dx-05', name: 'Kamen Rider Geats DX Desire Driver & Magnum Boost Set', code: 'BANDAI-DX-DESIRE-01', category: 'dx-belt', era: 'Reiwa', series: 'Kamen Rider Geats', price: 1950000, originalPrice: 2300000, soldCount: 610, stock: 18, rating: 5.0, reviewCount: 210, isHot: true, isNew: false, condition: 'New Seal 100%', description: 'Bộ đai Desire Driver cùng cặp đôi khoen Buckle Magnum & Boost đỉnh cao của Kamen Rider Geats.' },
  { id: 'p-dx-06', name: 'CSM Kamen Rider Kabuto Zecter Ver 1.5 Bandai Premium', code: 'BANDAI-CSM-KABUTO-15', category: 'dx-belt', era: 'Heisei', series: 'Kamen Rider Kabuto', price: 6800000, originalPrice: 7500000, isCSM: true, soldCount: 190, stock: 5, rating: 5.0, reviewCount: 95, isHot: true, isNew: false, condition: 'New Seal 100%', description: 'Phiên bản CSM Ver 1.5 với hiệu ứng âm thanh Clock Up nén mạ kim loại sắc sảo như trên phim.' },

  // SHF Regular
  { id: 'p-shf-01', name: 'SHF Kamen Rider Bitter Gavv Marblebreacookie Form', code: 'BANDAI-SHF-BITTER-COOKIE', category: 'shf', era: 'Reiwa', series: 'Kamen Rider Gavv', price: 1950000, originalPrice: 2250000, isFlashSale: true, flashSaleEndTime: '2026-07-31T23:59:59Z', flashSaleStock: 10, soldCount: 145, stock: 16, rating: 5.0, reviewCount: 42, isHot: true, isNew: true, condition: 'New Seal 100%', description: 'Mô hình khớp S.H.Figuarts Kamen Rider Bitter Gavv dạng bánh quy cẩm thạch Marblebreacookie Form.' },
  { id: 'p-shf-02', name: 'SHF Kamen Rider Bitter Gavv Sparkingummy Form', code: 'BANDAI-SHF-BITTER-SPARK', category: 'shf', era: 'Reiwa', series: 'Kamen Rider Gavv', price: 1880000, originalPrice: 2150000, soldCount: 130, stock: 12, rating: 4.9, reviewCount: 38, isHot: true, isNew: true, condition: 'New Seal 100%', description: 'Phiên bản Bitter Gavv Sparkingummy Form màu đỏ trong suốt hiệu ứng kẹo dẻo nổ lách tách.' },
  { id: 'p-shf-03', name: 'SHF Kamen Rider Durendal Ocean History', code: 'BANDAI-SHF-DURENDAL', category: 'shf', era: 'Reiwa', series: 'Kamen Rider Saber', price: 2100000, originalPrice: 2400000, soldCount: 88, stock: 9, rating: 4.8, reviewCount: 29, isHot: false, isNew: false, condition: 'New Seal 100%', description: 'Hiệp sĩ đại dương Durendal với vũ khí thương đao biến chuyển linh hoạt.' },
  { id: 'p-shf-04', name: 'SHF Kamen Rider Gavv Amazingummy Form', code: 'BANDAI-SHF-GAVV-AMAZING', category: 'shf', era: 'Reiwa', series: 'Kamen Rider Gavv', price: 1820000, originalPrice: 2100000, soldCount: 175, stock: 22, rating: 5.0, reviewCount: 52, isHot: true, isNew: true, condition: 'New Seal 100%', description: 'Dạng kẹo dẻo Amazingummy rực rỡ sắc màu của Kamen Rider Gavv.' },
  { id: 'p-shf-05', name: 'SHF Kamen Rider Gavv Caking Form', code: 'BANDAI-SHF-GAVV-CAKING', category: 'shf', era: 'Reiwa', series: 'Kamen Rider Gavv', price: 2250000, originalPrice: 2600000, isFlashSale: true, flashSaleEndTime: '2026-07-31T23:59:59Z', flashSaleStock: 8, soldCount: 210, stock: 15, rating: 5.0, reviewCount: 84, isHot: true, isNew: true, condition: 'New Seal 100%', description: 'Dạng Caking Form mang phong cách bánh sinh nhật hoàng gia vô cùng lộng lẫy.' },
  { id: 'p-shf-06', name: 'SHF Kamen Rider Geats Boost Form Mark III', code: 'BANDAI-SHF-GEATS-MK3', category: 'shf', era: 'Reiwa', series: 'Kamen Rider Geats', price: 2150000, originalPrice: 2500000, soldCount: 310, stock: 14, rating: 5.0, reviewCount: 110, isHot: true, isNew: false, condition: 'New Seal 100%', description: 'Mô hình Geats Boost Form Mark III với phối màu trắng đỏ quyền uy.' },
  { id: 'p-shf-07', name: 'SHF Kamen Rider Ryugen Budou Arms', code: 'BANDAI-SHF-RYUGEN', category: 'shf', era: 'Heisei', series: 'Kamen Rider Gaim', price: 1650000, originalPrice: 1950000, soldCount: 95, stock: 11, rating: 4.8, reviewCount: 31, isHot: false, isNew: false, condition: 'New Seal 100%', description: 'Mô hình SHF Ryugen áo giáp Nho trang bị súng Budou Ryuugun.' },
  { id: 'p-shf-08', name: 'SHF Kamen Rider Xross Saber', code: 'BANDAI-SHF-XROSS-SABER', category: 'shf', era: 'Reiwa', series: 'Kamen Rider Saber', price: 2350000, originalPrice: 2700000, soldCount: 260, stock: 8, rating: 5.0, reviewCount: 89, isHot: true, isNew: false, condition: 'New Seal 100%', description: 'Dạng cuối Xross Saber với nước sơn dải ngân hà lấp lánh cực kỳ ấn tượng.' },

  // SHF P-Bandai
  { id: 'p-pb-01', name: 'SHF Kamen Rider Zeztz Physicam Impact (P-Bandai)', code: 'PBANDAI-SHF-ZEZTS-PHYSICAM', category: 'shf-pbandai', era: 'Reiwa', series: 'Kamen Rider Zeztz', price: 2650000, originalPrice: 3000000, soldCount: 115, stock: 7, rating: 5.0, reviewCount: 41, isHot: true, isNew: true, condition: 'New Seal 100%', description: 'Bản giới hạn Premium Bandai Kamen Rider Zeztz Physicam Impact.' },
  { id: 'p-pb-02', name: 'SHF Inui Takumi (Kamen Rider Faiz 555) P-Bandai', code: 'PBANDAI-SHF-TAKUMI', category: 'shf-pbandai', era: 'Heisei', series: 'Kamen Rider Faiz', price: 2400000, originalPrice: 2800000, soldCount: 205, stock: 6, rating: 5.0, reviewCount: 78, isHot: true, isNew: false, condition: 'New Seal 100%', description: 'Mô hình dạng người của nhân vật chính Inui Takumi (Kamen Rider Faiz).' },
  { id: 'p-pb-03', name: 'SHF Masked Rider Stronger & Kabutorawer Set P-Bandai', code: 'PBANDAI-SHF-STRONGER', category: 'shf-pbandai', era: 'Showa', series: 'Kamen Rider Stronger', price: 2900000, originalPrice: 3300000, soldCount: 65, stock: 4, rating: 4.9, reviewCount: 22, isHot: false, isNew: false, condition: 'New Seal 100%', description: 'Bộ đôi Hiệp sĩ Showa Stronger kèm mô tô Kabutorawer chính hãng.' },

  // Weapons & Items & Sentai
  { id: 'p-wp-01', name: 'DX Beat Axe Kamen Rider Geats', code: 'BANDAI-DX-BEAT-AXE', category: 'weapon', era: 'Reiwa', series: 'Kamen Rider Geats', price: 1250000, originalPrice: 1500000, soldCount: 180, stock: 15, rating: 4.8, reviewCount: 55, isHot: false, isNew: false, condition: 'New Seal 100%', description: 'Vũ khí Rìu Guitar Beat Axe có hiệu ứng gảy đàn và âm thanh cực sung.' },
  { id: 'p-it-01', name: 'Hộp Mù Blokees Figures Kamen Rider All Stars 01', code: 'BLOKEES-KR-01', category: 'item', era: 'Reiwa', series: 'Kamen Rider Series', price: 180000, originalPrice: 220000, soldCount: 850, stock: 50, rating: 4.9, reviewCount: 310, isHot: true, isNew: true, condition: 'New Seal 100%', description: 'Hộp mù Blokees mô hình Kamen Rider khớp cựa mini cực dễ thương.' },
  { id: 'p-st-01', name: 'SMP Hyakujuu Gattai GaoKing - Hyakujuu Sentai Gaoranger', code: 'BANDAI-SMP-GAOKING', category: 'sentai', era: 'Heisei', series: 'Gaoranger', price: 2150000, originalPrice: 2500000, soldCount: 420, stock: 10, rating: 5.0, reviewCount: 140, isHot: true, isNew: false, condition: 'New Seal 100%', description: 'Mô hình lắp ráp SMP Vua Siêu Thú GaoKing huyền thoại 5 Gao Animals.' }
];

let imgCounter = 0;
const formattedProducts = products.map((p) => {
  const img1 = anhFiles[imgCounter % anhFiles.length];
  const img2 = anhFiles[(imgCounter + 1) % anhFiles.length];
  const img3 = anhFiles[(imgCounter + 2) % anhFiles.length];
  imgCounter += 3;
  return {
    ...p,
    images: [img1, img2, img3]
  };
});

const fileContent = `import { Product } from '../types';

const REVIEW_USER_NAMES = [
  'Nguyễn Minh Tuấn', 'Trần Hoàng Nam', 'Lê Quốc Bảo', 'Phạm Đức Anh', 'Vũ Huy Hoàng',
  'Đặng Quốc Việt', 'Bùi Thanh Tùng', 'Đỗ Quang Minh', 'Ngô Tấn Tài', 'Dương Văn Sơn',
  'Hoàng Ngọc Anh', 'Phan Gia Huy', 'Trịnh Tiến Dũng', 'Lý Thanh Hải', 'Mai Văn Hùng',
  'Đinh Quang Khải', 'Hồ Minh Châu', 'Võ Văn Thắng', 'Cao Đức Thịnh', 'Lương Tuấn Kiệt',
  'Tô Văn Hòa', 'Trương Quốc Khánh', 'Đoàn Minh Trí', 'Phan Văn Long', 'Đỗ Minh Quân'
];

const REVIEW_COMMENTS_TEMPLATE = [
  'Hàng New Seal 100% cực kỳ xịn xò. Đóng gói 3 lớp xốp bọc nổ an toàn tuyệt đối từ TIENDAT SHOP!',
  'Âm thanh loa to nét giòn tan, đèn LED sáng rực đúng chuẩn Bandai Japan. Rất đáng đồng tiền bát gạo.',
  'Giao hàng siêu tốc trong vòng 24h tại TP.HCM. Nhân viên tư vấn nhiệt tình, đai lên tay rất vừa vặn.',
  'Màu sơn metallic bóng loáng, các khớp bấm chuyển động mượt mà không chút dăm nhựa.',
  'Xịn hơn mong đợi! Bản CSM / DX / SHF này tỉ lệ chuẩn như trên phim Tokusatsu luôn.',
  'Đã mua lần thứ 5 ở shop TIENDATSHF và chưa bao giờ thất vọng. 1000 điểm uy tín!',
  'Hộp không một vết móp góc, có tem niêm phong Bandai đầy đủ. Rất hài lòng.',
  'Cơ chế gạt chốt chắc chắn, giắc cắm nhạy không bị trễ âm thanh. 5 sao chất lượng!',
  'Shop tặng kèm pin đầy đủ và thẻ quà tặng may mắn. Dịch vụ chăm sóc khách hàng số 1 Việt Nam.',
  'Mô hình SHF / DX biên độ khớp linh hoạt, posing tạo dáng Henshin đẹp mê hốt.',
  'Chi tiết mạ kim loại sắc nét, không lem màu. Trưng trên kệ mica đèn LED cực sang trọng.',
  'Đã test với các phụ kiện đi kèm, khớp hoàn hảo 100%. Rất đáng sưu tầm.',
  'Sản phẩm chính hãng Bandai Nhật Bản tem vàng. Mua đợt Flash Sale giá siêu hời!',
  'Giao về Hà Nội mất có 2 ngày, mở hộp ra mồ hôi hột vì đẹp quá dã man.',
  'Reviewer trên Youtube khen sao thì ngoài đời đẹp đúng như vậy, cực mượt.',
  'Trải nghiệm mua sắm tuyệt vời, shop gói hàng cẩn thận tỉ mỉ như đồ thủy tinh.',
  'Khớp xoay chắc tay, nhựa cao cấp dẻo dai khó gãy. Trẻ em hay người lớn chơi đều mê.',
  'Chất lượng âm thanh Surround HD rõ từng tiếng hô biến hình đặc trưng.',
  'Anh chủ shop nhiệt tình hỗ trợ hướng dẫn lắp ráp qua Zalo rất tận tâm.',
  'Bộ này hiếm lắm mà săn được ở TIENDAT SHOP giá tốt thế này đúng là duyên số!',
  'Sơn mạ bóng chuẩn Nhật, không sợ bong tróc theo thời gian. Mua làm quà sinh nhật ai cũng thích.',
  'Đã check series code đàng hoàng chuẩn chính hãng 100%. Sẽ ủng hộ shop dài dài!',
  'Thiết kế đầm tay, trọng lượng chuẩn. Bật switch lên nghe tiếng Henshin phê ngất ngây.',
  'Giao hàng bưu điện bọc thùng xốp cứng cáp, góc hộp sắc nét mượt mà.',
  'Đỉnh cao sưu tầm Tokusatsu năm 2026! Cảm ơn TIENDATSHF đã mang hàng hot về sớm.'
];

const QA_QUESTIONS_TEMPLATE = [
  { q: 'Sản phẩm này là hàng New Seal hay 2nd ạ?', a: 'Chào bạn! Sản phẩm mới 100% New Seal nguyên hộp chính hãng từ Bandai Japan nhé.' },
  { q: 'Đai / Mô hình này có sẵn pin bên trong không shop?', a: 'TIENDAT SHOP luôn tặng kèm pin AAA/LR44 cao cấp sẵn trong hộp cho bạn test ngay nhé!' },
  { q: 'Shop có giao hàng hỏa tốc trong ngày tại TP.HCM hoặc Hà Nội không?', a: 'Có bạn nhé! Shop hỗ trợ ship hỏa tốc Grab/Lalamove nhận hàng chỉ trong 1-2 giờ.' },
  { q: 'Sản phẩm có đi kèm thẻ bảo hành chính hãng không ạ?', a: 'Tất cả sản phẩm đều đi kèm tem bảo hành 1 đổi 1 trong 30 ngày từ TIENDATSHF.' },
  { q: 'Kích thước dây đai có vừa với người lớn không shop?', a: 'Dây đai có nấc điều chỉnh rộng rãi, người lớn đeo thoải mái hoặc dùng thêm dây nối extended belt ạ.' },
  { q: 'Shop đóng gói gửi đi xa có bị móp hộp không ạ?', a: 'Shop luôn đóng bọc 3 lớp chống sốc bóng nổ + thùng carton 5 lớp chuyên dụng, đảm bảo hộp về tay láng mịn ạ.' },
  { q: 'Âm thanh và đèn LED của sản phẩm có bảo hành không ạ?', a: 'Dạ có ạ, bảo hành linh kiện mạch điện tử âm thanh & LED 6 tháng tận tâm tại Showroom.' },
  { q: 'Sản phẩm này có kết hợp được với các item phụ kiện khác không ạ?', a: 'Có ạ, sản phẩm tương thích chuẩn 100% với toàn bộ các item trong cùng Series Bandai.' },
  { q: 'Shop có hỗ trợ trả góp qua thẻ tín dụng hoặc Fundiin không ạ?', a: 'Dạ có ạ! Shop hỗ trợ trả góp 0% qua thẻ tín dụng và qua app Fundiin/Kredivo nhé.' },
  { q: 'Em ở tỉnh lẻ thì thời gian nhận hàng khoảng bao nhiêu ngày ạ?', a: 'Gửi COD tỉnh khoảng 2 - 3 ngày làm việc là bạn nhận được hàng ạ.' },
  { q: 'Có được kiểm tra hàng trước khi thanh toán cho shipper không ạ?', a: 'Dạ được kiểm tra ngoại quan hộp trước khi thanh toán hoàn toàn yên tâm ạ!' },
  { q: 'Mô hình này có bị lỏng khớp hay dễ rơi phụ kiện không ạ?', a: 'Dạ hàng Bandai Japan khâu kiểm định rất nghiêm ngặt, khớp cực kỳ chắc chắn ạ.' },
  { q: 'Shop có nhận tìm săn order các bản đai hiếm hiếm đời cũ không ạ?', a: 'TIENDAT SHOP nhận order săn tất cả các mẫu CSM, DX, SHF đời cổ từ Nhật Bản ạ.' },
  { q: 'Tủ trưng bày mica LED cho mẫu này shop có bán luôn không?', a: 'Shop có sẵn tủ mica nguyên khối có sẵn đèn LED rực rỡ thiết kế riêng cho mẫu này ạ.' },
  { q: 'Chất liệu sản phẩm có an toàn cho trẻ em chơi không ạ?', a: 'Nhựa ABS/PVC đạt tiêu chuẩn chất lượng an toàn khắt khe của Nhật Bản ạ.' },
  { q: 'Nếu bị lỗi kỹ thuật nhà sản xuất thì đổi trả như thế nào ạ?', a: 'Shop đổi mới 100% lập tức trong 7 ngày đầu nếu có lỗi nhà sản xuất ạ.' },
  { q: 'Sản phẩm này phát hành năm nào vậy shop?', a: 'Bạn xem chi tiết trong phần Thông Số Kỹ Thuật bên trên ạ, hàng đợt sản xuất mới nhất.' },
  { q: 'Có tặng kèm quà lưu niệm hay sticker Tokusatsu không shop?', a: 'Shop tặng kèm bộ Sticker Kamen Rider mạ vàng độc quyền TIENDATSHF cho mọi đơn hàng ạ!' },
  { q: 'Sản phẩm này có âm thanh thoại của diễn viên trong phim không?', a: 'Dạ có tích hợp đầy đủ Voice diễn viên và nhạc nền BGM biến hình cực đỉnh ạ!' },
  { q: 'Shop mở cửa tới mấy giờ để em qua xem trực tiếp tại Showroom ạ?', a: 'Showroom TIENDATSHF mở cửa từ 8:00 đến 22:00 tất cả các ngày trong tuần ạ.' },
  { q: 'Bộ này nặng khoảng bao nhiêu gram ạ?', a: 'Trọng lượng cả đóng hộp khoảng 800g - 1.5kg tùy mẫu ạ.' },
  { q: 'Có hướng dẫn sử dụng tiếng Việt kèm theo không ạ?', a: 'Dạ shop gửi kèm tờ hướng dẫn việt hóa + video hướng dẫn chơi chi tiết qua QR code ạ!' },
  { q: 'Sản phẩm có hạn chế số lượng mua mỗi khách không ạ?', a: 'Mỗi khách hàng mua tối đa 2 bộ để đảm bảo công bằng cho cộng đồng Collector ạ.' },
  { q: 'Sơn trên sản phẩm có dễ bị bong tróc theo thời gian không ạ?', a: 'Sơn mạ công nghệ cao của Bandai rất bền màu, bạn chú ý tránh nắng trực tiếp là giữ bền lâu năm ạ.' },
  { q: 'Sản phẩm này có bao gồm sách HDSD chính hãng Bandai không ạ?', a: 'Đầy đủ sách HDSD in màu sắc nét chính hãng nguyên bản Bandai Japan ạ!' }
];

function generate25Reviews(prodId: string) {
  return REVIEW_COMMENTS_TEMPLATE.map((comment, index) => {
    const day = String(28 - (index % 25)).padStart(2, '0');
    return {
      id: \`rev-\${prodId}-\${index + 1}\`,
      userName: REVIEW_USER_NAMES[index % REVIEW_USER_NAMES.length],
      rating: index % 7 === 0 ? 4 : 5,
      date: \`\${day}/07/2026\`,
      comment: comment,
      verifiedPurchase: true
    };
  });
}

function generate25QAs(prodId: string) {
  return QA_QUESTIONS_TEMPLATE.map((qa, index) => {
    const day = String(28 - (index % 25)).padStart(2, '0');
    return {
      id: \`qa-\${prodId}-\${index + 1}\`,
      question: qa.q,
      askedBy: REVIEW_USER_NAMES[(index + 3) % REVIEW_USER_NAMES.length],
      answer: qa.a,
      answeredBy: 'TIENDAT SHOP Technical Team',
      date: \`\${day}/07/2026\`
    };
  });
}

const RAW_PRODUCTS: Product[] = ${JSON.stringify(formattedProducts, null, 2)};

export const INITIAL_PRODUCTS: Product[] = RAW_PRODUCTS.map((p) => {
  return {
    ...p,
    reviews: generate25Reviews(p.id),
    qaList: generate25QAs(p.id),
    reviewCount: Math.max(p.reviewCount || 0, 25)
  };
});
`;

fs.writeFileSync(path.join(cwd, 'src/data/products.ts'), fileContent, 'utf8');
console.log('Rebuilt clean src/data/products.ts successfully!');
