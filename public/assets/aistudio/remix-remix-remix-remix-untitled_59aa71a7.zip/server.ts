import express from 'express';
import http from 'http';
import dotenv from 'dotenv';
import { GoogleGenAI } from '@google/genai';
import { createServer as createViteServer } from 'vite';
import path from 'path';
import { fileURLToPath } from 'url';

dotenv.config();

const __filename = fileURLToPath(import.meta.url);
const __dirname = path.dirname(__filename);

const app = express();
const server = http.createServer(app);
const PORT = Number(process.env.PORT) || 3000;

app.use(express.json({ limit: '50mb' }));
app.use(express.urlencoded({ extended: true, limit: '50mb' }));

// In-memory persistent state for dedicated Live Product Session
interface LiveFileRecord {
  id: string;
  name: string;
  mimeType: string;
  buffer: Buffer;
  size: number;
  uploadedAt: string;
}

const liveFiles = new Map<string, LiveFileRecord>();
const bannedUserIds = new Set<string>();
const kickedTokens = new Set<string>();

interface LiveChatMsg {
  id: string;
  senderId: string;
  senderName: string;
  senderAvatar: string;
  senderBadge?: string;
  text: string;
  createdAt: string;
  links?: Array<{
    url: string;
    title: string;
    description: string;
    image?: string;
    domain: string;
  }>;
  file?: {
    id: string;
    name: string;
    size: number;
    mimeType: string;
    url: string;
  };
  isAdmin?: boolean;
  isHidden?: boolean;
}

interface LiveRoomData {
  id: string;
  title: string;
  hostId: string;
  hostName: string;
  hostAvatar: string;
  hostRole: string;
  hostBadge: string;
  isOfficial?: boolean;
  category: string;
  status: 'live' | 'ended';
  startedAt: string;
  pinnedProductId?: string;
  thumbnail: string;
  viewerCount: number;
  isChatLocked?: boolean;
  totalOrders?: number;
  totalRevenue?: number;
  productStocks?: Record<string, number>;
  flashSale?: {
    active: boolean;
    code: string;
    discountText: string;
    percent: number;
    maxDiscount: number;
    expiresAt: string;
    durationSeconds: number;
  };
  videoConfig: {
    resolution: '1080p' | '720p';
    fps: 30 | 60;
    bitrateMbps: number;
    svcEnabled: boolean;
    stabilization: boolean;
    autofocus: boolean;
  };
}

// Single Official Live Channel: Danh Nguyễn (Admin Store) - ZERO FAKE CHANNELS
let liveRooms: LiveRoomData[] = [
  {
    id: 'room_npt_official',
    title: '🔴 SHOWCASE CHÍNH THỨC: TEST ĐAI DX HENSHIN BELT & CAPSEM BANDAI JAPAN 2026',
    hostId: 'admin_danh_nguyen',
    hostName: 'Danh Nguyễn (Admin Store)',
    hostAvatar: '/Logo & Thương Hiệu (Brand Logo)/dreamina-2026-07-29-3008-A minimalist stencil-style logo of an oc....png',
    hostRole: 'Chủ Cửa Hàng & Kỹ Thuật Viên Bandai',
    hostBadge: '👑 ADMIN STORE',
    isOfficial: true,
    category: 'Đai Biến Hình DX & CSM',
    status: 'ended',
    startedAt: new Date(Date.now() - 25 * 60 * 1000).toISOString(),
    pinnedProductId: 'p1', // Kamen Rider Zeztz DX Henshin Belt Lord Invoker
    thumbnail: '/Ảnh Showroom & Cửa Hàng/20240708_161850.jpg',
    viewerCount: 0,
    flashSale: {
      active: true,
      code: 'LIVEVIP50',
      discountText: 'Giảm 15% Tối Đa 250.000đ',
      percent: 15,
      maxDiscount: 250000,
      expiresAt: new Date(Date.now() + 5 * 60 * 1000).toISOString(),
      durationSeconds: 300,
    },
    videoConfig: {
      resolution: '1080p',
      fps: 60,
      bitrateMbps: 4.0,
      svcEnabled: true,
      stabilization: true,
      autofocus: true,
    }
  }
];

// Per-room Chat Messages Store - 100% REAL ACCOUNTS, ZERO FAKE BOT MESSAGES
const roomChatMap = new Map<string, LiveChatMsg[]>();

// Initialize empty real chat lists for official room
liveRooms.forEach(room => {
  roomChatMap.set(room.id, []);
});

// Customer Account & IP Management
interface CustomerAccountRecord {
  id: string;
  name: string;
  email: string;
  phone?: string;
  address?: string;
  ip: string;
  userAgent?: string;
  registeredAt: string;
  lastActiveAt?: string;
  isBlocked: boolean;
  blockReason?: string;
  isCloneSuspect?: boolean;
  orderCount?: number;
}

const bannedIps = new Set<string>();

const customerAccounts: CustomerAccountRecord[] = [
  {
    id: 'cust_1',
    name: 'Trần Nhật Hoàng',
    email: 'hoang.rider99@gmail.com',
    phone: '0912345678',
    address: '72 Lê Lợi, P. Bến Nghé, Quận 1, TP. HCM',
    ip: '113.161.42.18',
    registeredAt: '24/10/2026 14:20',
    lastActiveAt: '24/10/2026 19:40',
    isBlocked: false,
    isCloneSuspect: false,
    orderCount: 3
  },
  {
    id: 'cust_2',
    name: 'Lê Quốc Bảo',
    email: 'quocbao.tokusatsu@gmail.com',
    phone: '0987654321',
    address: '45 Võ Văn Tần, P. 6, Quận 3, TP. HCM',
    ip: '14.169.85.12',
    registeredAt: '24/10/2026 16:45',
    lastActiveAt: '24/10/2026 18:30',
    isBlocked: false,
    isCloneSuspect: false,
    orderCount: 1
  },
  {
    id: 'cust_3',
    name: 'Tài Khoản Clone Nghi Vấn',
    email: 'clone.test1@gmail.com',
    phone: '0900000001',
    address: 'Chưa cập nhật',
    ip: '113.161.42.18', // Trùng IP với cust_1
    registeredAt: '24/10/2026 17:05',
    lastActiveAt: '24/10/2026 17:05',
    isBlocked: false,
    isCloneSuspect: true,
    blockReason: 'Cảnh báo: Trùng IP với tài khoản [Trần Nhật Hoàng]',
    orderCount: 0
  }
];

// Orders Store & Bank Transfer Records
interface ServerOrderRecord {
  id: string;
  date: string;
  time: string;
  customerName: string;
  customerAvatar?: string;
  customerEmail: string;
  customerPhone: string;
  customerIp: string;
  shippingAddress: string;
  items: Array<{
    productId: string;
    productName: string;
    productImage: string;
    price: number;
    quantity: number;
    serialKey: string;
  }>;
  subtotal: number;
  discountAmount: number;
  pointsDiscount: number;
  shippingFee: number;
  total: number;
  paymentMethod: 'BANK' | 'COD' | 'VNPAY' | 'MOMO';
  bankTransferDetails?: {
    bankName: string;
    accountNumber: string;
    accountHolder: string;
    transferContent: string;
    amount: number;
    senderBank?: string;
    senderAccountNumber?: string;
    senderAccountName?: string;
    transferReference?: string;
    transferredAt?: string;
    proofImage?: string;
  };
  couponCode?: string;
  pointsEarned: number;
  status: 'Chờ xác nhận' | 'Đang xử lý' | 'Đang giao hàng' | 'Đã giao thành công' | 'Đã hủy';
}

let ordersStore: ServerOrderRecord[] = [
  {
    id: 'RD-894120',
    date: '24/10/2026',
    time: '18:15',
    customerName: 'Trần Nhật Hoàng',
    customerAvatar: '',
    customerEmail: 'hoang.rider99@gmail.com',
    customerPhone: '0912345678',
    customerIp: '113.161.42.18',
    shippingAddress: '72 Lê Lợi, P. Bến Nghé, Quận 1, TP. HCM',
    items: [
      {
        productId: 'p1',
        productName: 'Kamen Rider Zeztz DX Henshin Belt Lord Invoker',
        productImage: '/Ảnh Sản Phẩm/dx/Kamen Rider Zeztz DX Henshin Belt Lord Invoker1.jpg',
        price: 2850000,
        quantity: 1,
        serialKey: 'BANDAI-ZEZTZ-9921'
      }
    ],
    subtotal: 2850000,
    discountAmount: 250000,
    pointsDiscount: 0,
    shippingFee: 0,
    total: 2600000,
    paymentMethod: 'BANK',
    bankTransferDetails: {
      bankName: 'MB Bank (Quân Đội)',
      accountNumber: '0988776655',
      accountHolder: 'DANH NGUYEN',
      transferContent: 'DH RD-894120 0912345678',
      amount: 2600000,
      senderBank: 'Vietcombank',
      senderAccountNumber: '1019928374',
      senderAccountName: 'TRAN NHAT HOANG',
      transferReference: 'FT26298104829',
      transferredAt: '24/10/2026 18:16:42'
    },
    couponCode: 'LIVEVIP50',
    pointsEarned: 260,
    status: 'Chờ xác nhận'
  },
  {
    id: 'RD-621849',
    date: '24/10/2026',
    time: '17:30',
    customerName: 'Lê Quốc Bảo',
    customerAvatar: '',
    customerEmail: 'quocbao.tokusatsu@gmail.com',
    customerPhone: '0987654321',
    customerIp: '14.169.85.12',
    shippingAddress: '45 Võ Văn Tần, P. 6, Quận 3, TP. HCM',
    items: [
      {
        productId: 'p4',
        productName: 'Mô Hình S.H.Figuarts Kamen Rider Gavv Poppingummy Form',
        productImage: '/Ảnh Sản Phẩm/shf/[Chính Hãng] SHF Kamen Rider Gavv Poppingummy Form1.jpg',
        price: 1850000,
        quantity: 1,
        serialKey: 'BANDAI-SHF-8412'
      }
    ],
    subtotal: 1850000,
    discountAmount: 0,
    pointsDiscount: 0,
    shippingFee: 0,
    total: 1850000,
    paymentMethod: 'BANK',
    bankTransferDetails: {
      bankName: 'MB Bank (Quân Đội)',
      accountNumber: '0988776655',
      accountHolder: 'DANH NGUYEN',
      transferContent: 'DH RD-621849 0987654321',
      amount: 1850000,
      senderBank: 'Techcombank',
      senderAccountNumber: '1903829104',
      senderAccountName: 'LE QUOC BAO',
      transferReference: 'TCB261024982',
      transferredAt: '24/10/2026 17:31:05'
    },
    pointsEarned: 185,
    status: 'Đang xử lý'
  }
];

function getClientIp(req: express.Request): string {
  const forwarded = req.headers['x-forwarded-for'];
  if (typeof forwarded === 'string') {
    return forwarded.split(',')[0].trim();
  }
  if (Array.isArray(forwarded) && forwarded.length > 0) {
    return forwarded[0].trim();
  }
  const clientReported = (req.body?.clientReportedIp || req.query?.clientReportedIp) as string;
  if (typeof clientReported === 'string' && clientReported.trim()) {
    return clientReported.trim();
  }
  const rawIp = req.socket.remoteAddress || req.ip || '127.0.0.1';
  return rawIp.replace(/^.*:/, '') || '127.0.0.1';
}

let purchaseEvents: Array<{
  id: string;
  customerName: string;
  productName: string;
  productImage: string;
  time: string;
}> = [
  {
    id: 'pur_1',
    customerName: 'Hoàng Minh Quân',
    productName: 'Kamen Rider Zeztz DX Henshin Belt Lord Invoker',
    productImage: '/Ảnh Sản Phẩm/dx/Kamen Rider Zeztz DX Henshin Belt Lord Invoker1.jpg',
    time: 'Vừa xong'
  },
  {
    id: 'pur_2',
    customerName: 'Đặng Tuấn Kiệt',
    productName: 'Mô Hình S.H.Figuarts Kamen Rider Gavv Poppingummy Form',
    productImage: '/Ảnh Sản Phẩm/shf/[Chính Hãng] SHF Kamen Rider Gavv Poppingummy Form1.jpg',
    time: '1 phút trước'
  }
];

// Helper to extract links and build rich preview metadata
function extractLinksWithPreview(text: string) {
  const urlRegex = /(https?:\/\/[^\s]+)/g;
  const matches = text.match(urlRegex);
  if (!matches || matches.length === 0) return undefined;

  return matches.slice(0, 2).map(url => {
    let domain = 'web';
    try {
      const parsed = new URL(url);
      domain = parsed.hostname;
    } catch {}

    let title = `Liên kết: ${domain}`;
    let description = `Nhấp để mở trang web an toàn (${url})`;
    let image: string | undefined = undefined;

    if (url.includes('bandai') || url.includes('toy')) {
      title = 'Bandai Spirits Official - Khám phá đồ chơi Kamen Rider Nhật Bản';
      description = 'Thông số kỹ thuật chính hãng, âm thanh Henshin bản quyền Toei & Bandai.';
      image = '/BIỂU TƯỢNG DANH MỤC SẢN PHẨM/dlyjpm8-ea90294c-de09-4bc2-8718-6b49acbf082e.png';
    } else if (url.includes('npt') || url.includes('store')) {
      title = 'NPTTEAMSTORE - Cửa hàng Tokusatsu Bandai Japan Uy Tín';
      description = 'Đầy đủ đai biến hình DX, CSM, S.H.Figuarts new seal bảo hành 12 tháng.';
      image = '/Logo & Thương Hiệu (Brand Logo)/dreamina-2026-07-29-3008-A minimalist stencil-style logo of an oc....png';
    } else if (url.includes('youtube') || url.includes('youtu.be')) {
      title = 'Video Review & Đập Hộp Chi Tiết (YouTube)';
      description = 'Xem video trải nghiệm thực tế hiệu ứng âm thanh và đèn LED biến hình.';
    }

    return { url, title, description, image, domain };
  });
}

// -------------------------------------------------------------
// A. ADMIN AUTHENTICATION (DANH NGUYỄN / DANH2009)
// -------------------------------------------------------------
app.post('/api/admin/login', (req, res) => {
  const { username, password } = req.body;
  if (!username || !password) {
    return res.status(400).json({ error: 'Vui lòng nhập đầy đủ tài khoản và mật khẩu Quản Lý' });
  }

  // Normalize: remove accents, trim, lowercase
  const normUser = String(username).trim().toLowerCase().normalize('NFD').replace(/[\u0300-\u036f]/g, '');
  const isUserValid = normUser === 'danh nguyen';
  const isPassValid = String(password).trim() === 'danh2009';

  if (!isUserValid || !isPassValid) {
    return res.status(401).json({ 
      error: 'Tài khoản hoặc mật khẩu Quản Lý không chính xác! Vui lòng kiểm tra lại.' 
    });
  }

  res.json({
    success: true,
    user: {
      id: 'admin_danh_nguyen',
      name: 'Danh Nguyễn',
      role: 'admin',
      badge: '👑 QUẢN TRỊ VIÊN STORE'
    },
    token: 'admin_token_' + Date.now()
  });
});

// -------------------------------------------------------------
// B. CLIENT IP CHECK & CUSTOMER ACCOUNT TRACKING
// -------------------------------------------------------------
app.get('/api/client/ip', (req, res) => {
  const ip = getClientIp(req);
  const isBlocked = bannedIps.has(ip);
  res.json({ ip, isBlocked });
});

// Web Khách registers an account -> sends data & client IP to Web Quản Lý
app.post('/api/customers/register', (req, res) => {
  const { name, email, phone, address, userAgent } = req.body;
  const ip = getClientIp(req);

  if (bannedIps.has(ip)) {
    return res.status(403).json({
      error: `Địa chỉ IP của bạn [${ip}] đã bị Quản Trị Viên chặn do nghi vấn vi phạm hoặc tài khoản clone!`,
      isIpBlocked: true,
      ip
    });
  }

  if (!name || !email) {
    return res.status(400).json({ error: 'Vui lòng cung cấp đầy đủ họ tên và email' });
  }

  // Detect clone accounts sharing the same IP
  const existingAccountsWithSameIp = customerAccounts.filter(c => c.ip === ip);
  const isCloneSuspect = existingAccountsWithSameIp.length > 0;

  const newCustomer: CustomerAccountRecord = {
    id: 'cust_' + Date.now(),
    name: name.trim(),
    email: email.trim().toLowerCase(),
    phone: phone ? phone.trim() : '',
    address: address ? address.trim() : 'Việt Nam',
    ip,
    userAgent: userAgent || req.headers['user-agent'] || 'Web Khách Device',
    registeredAt: new Date().toLocaleString('vi-VN'),
    lastActiveAt: new Date().toLocaleString('vi-VN'),
    isBlocked: false,
    isCloneSuspect,
    blockReason: isCloneSuspect 
      ? `⚠️ Trùng IP [${ip}] với tài khoản [${existingAccountsWithSameIp[0].name}]` 
      : undefined,
    orderCount: 0
  };

  customerAccounts.unshift(newCustomer);

  res.json({
    success: true,
    customer: newCustomer,
    ip,
    isCloneSuspect,
    message: 'Đăng ký tài khoản thành công! Dữ liệu đã được ghi nhận trên Web Quản Lý.'
  });
});

// Web Khách login -> checks IP ban
app.post('/api/customers/login', (req, res) => {
  const { email } = req.body;
  const ip = getClientIp(req);

  if (bannedIps.has(ip)) {
    return res.status(403).json({
      error: `Địa chỉ IP của bạn [${ip}] đã bị Quản Trị Viên chặn!`,
      isIpBlocked: true,
      ip
    });
  }

  const found = customerAccounts.find(c => c.email === (email || '').trim().toLowerCase());
  if (found) {
    found.lastActiveAt = new Date().toLocaleString('vi-VN');
    if (found.isBlocked) {
      return res.status(403).json({
        error: `Tài khoản của bạn đã bị khóa bởi Quản trị viên. Lý do: ${found.blockReason || 'Vi phạm chính sách'}`,
        isBlocked: true
      });
    }
  }

  res.json({ success: true, ip, customer: found });
});

// Web Quản Lý: Get all customers & IP stats
app.get('/api/admin/customers', (_req, res) => {
  res.json({
    customers: customerAccounts,
    bannedIps: Array.from(bannedIps),
    totalCustomers: customerAccounts.length,
    totalBannedIps: bannedIps.size
  });
});

// Web Quản Lý: Block IP (Chặn IP xấu/clone)
app.post('/api/admin/customers/block-ip', (req, res) => {
  const { ip, customerId, reason } = req.body;
  if (!ip) return res.status(400).json({ error: 'Thiếu địa chỉ IP' });

  const cleanIp = String(ip).trim();
  bannedIps.add(cleanIp);

  // Update customer records with this IP
  customerAccounts.forEach(c => {
    if (c.ip === cleanIp || (customerId && c.id === customerId)) {
      c.isBlocked = true;
      c.blockReason = reason || 'Quản trị viên Danh Nguyễn đã chặn IP này do nghi vấn tài khoản xấu/clone';
    }
  });

  res.json({
    success: true,
    bannedIps: Array.from(bannedIps),
    message: `Đã chặn thành công IP: ${cleanIp}`
  });
});

// Web Quản Lý: Unblock IP (Mở chặn IP)
app.post('/api/admin/customers/unblock-ip', (req, res) => {
  const { ip, customerId } = req.body;
  if (!ip) return res.status(400).json({ error: 'Thiếu địa chỉ IP' });

  const cleanIp = String(ip).trim();
  bannedIps.delete(cleanIp);

  customerAccounts.forEach(c => {
    if (c.ip === cleanIp || (customerId && c.id === customerId)) {
      c.isBlocked = false;
      c.blockReason = undefined;
    }
  });

  res.json({
    success: true,
    bannedIps: Array.from(bannedIps),
    message: `Đã mở chặn thành công cho IP: ${cleanIp}`
  });
});

// Web Quản Lý: Delete Customer Account
app.delete('/api/admin/customers/:id', (req, res) => {
  const idx = customerAccounts.findIndex(c => c.id === req.params.id);
  if (idx !== -1) {
    const deleted = customerAccounts.splice(idx, 1)[0];
    return res.json({ success: true, deleted });
  }
  res.status(404).json({ error: 'Không tìm thấy tài khoản khách hàng' });
});

// -------------------------------------------------------------
// C. ORDERS & BANK TRANSFER MANAGEMENT (WITH DELETE ORDER)
// -------------------------------------------------------------
app.get('/api/orders', (_req, res) => {
  res.json({ orders: ordersStore });
});

app.get('/api/admin/orders', (_req, res) => {
  res.json({ orders: ordersStore, totalOrders: ordersStore.length });
});

// Web Khách places order -> recorded on server with customer IP & bank details
app.post('/api/orders', (req, res) => {
  const ip = getClientIp(req);

  if (bannedIps.has(ip)) {
    return res.status(403).json({
      error: `Địa chỉ IP [${ip}] của bạn đã bị Web Quản Lý chặn. Không thể đặt hàng!`,
      isIpBlocked: true
    });
  }

  const orderData = req.body;
  if (!orderData || !orderData.id) {
    return res.status(400).json({ error: 'Dữ liệu đơn hàng không hợp lệ' });
  }

  const newOrder: ServerOrderRecord = {
    ...orderData,
    customerIp: ip
  };

  ordersStore.unshift(newOrder);

  // Update customer order count
  const cust = customerAccounts.find(c => c.email === newOrder.customerEmail || c.ip === ip);
  if (cust) {
    cust.orderCount = (cust.orderCount || 0) + 1;
    cust.lastActiveAt = new Date().toLocaleString('vi-VN');
  }

  res.json({ success: true, order: newOrder });
});

// Update Order Status (Admin)
app.patch('/api/orders/:orderId/status', (req, res) => {
  const { status } = req.body;
  const order = ordersStore.find(o => o.id === req.params.orderId);
  if (!order) return res.status(404).json({ error: 'Không tìm thấy đơn hàng' });

  order.status = status;
  res.json({ success: true, order });
});

// Web Quản Lý: XÓA ĐƠN HÀNG (Delete Order Functionality)
app.delete('/api/orders/:orderId', (req, res) => {
  const { orderId } = req.params;
  const idx = ordersStore.findIndex(o => o.id === orderId);
  if (idx === -1) {
    return res.status(404).json({ error: 'Không tìm thấy đơn hàng cần xóa' });
  }

  const deletedOrder = ordersStore.splice(idx, 1)[0];
  res.json({
    success: true,
    message: `Đã xóa vĩnh viễn đơn hàng #${orderId}`,
    deletedOrder
  });
});

// -------------------------------------------------------------
// D. LIVESTREAM CHANNELS (ADMIN EXCLUSIVE BROADCASTING)
// -------------------------------------------------------------
// 1. Get All Live Rooms / Accounts Broadcasting
app.get('/api/live/rooms', (_req, res) => {
  const activeRooms = liveRooms.filter(r => r.status === 'live');
  res.json({ rooms: activeRooms });
});

// Create / Start Live Room (Admin Danh Nguyễn Exclusive - Web Khách cannot live)
app.post('/api/live/rooms', (req, res) => {
  const { title, category, pinnedProductId, isAdmin } = req.body;
  
  if (!isAdmin) {
    return res.status(403).json({
      error: 'Quyền hạn bị từ chối: Web Khách không thể phát Live! Chỉ Web Quản Lý (Admin Danh Nguyễn) mới có quyền phát sóng.'
    });
  }

  if (!title) {
    return res.status(400).json({ error: 'Tiêu đề buổi live không được để trống' });
  }

  const newRoomId = 'room_npt_' + Date.now().toString(36);
  const newRoom: LiveRoomData = {
    id: newRoomId,
    title,
    hostId: 'admin_danh_nguyen',
    hostName: 'Danh Nguyễn (Admin Store)',
    hostAvatar: '/Logo & Thương Hiệu (Brand Logo)/dreamina-2026-07-29-3008-A minimalist stencil-style logo of an oc....png',
    hostRole: 'Chủ Cửa Hàng & Kỹ Thuật Viên Bandai',
    hostBadge: '👑 ADMIN STORE',
    isOfficial: true,
    category: category || 'Đai Biến Hình DX & CSM',
    status: 'live',
    startedAt: new Date().toISOString(),
    pinnedProductId: pinnedProductId || 'p1',
    thumbnail: '/Ảnh Showroom & Cửa Hàng/20240708_161850.jpg',
    viewerCount: 156,
    videoConfig: {
      resolution: '1080p',
      fps: 60,
      bitrateMbps: 4.0,
      svcEnabled: true,
      stabilization: true,
      autofocus: true,
    }
  };

  liveRooms.unshift(newRoom);
  roomChatMap.set(newRoomId, []);

  res.json({ success: true, room: newRoom });
});

// Get Specific Room Detail
app.get('/api/live/rooms/:roomId', (req, res) => {
  const room = liveRooms.find(r => r.id === req.params.roomId);
  if (!room) {
    return res.status(404).json({ error: 'Không tìm thấy phòng live' });
  }
  res.json({ room });
});

// Backward compatibility: /api/live/session returns first room
app.get('/api/live/session', (_req, res) => {
  const primaryRoom = liveRooms[0];
  res.json({
    ...primaryRoom,
    streamerName: primaryRoom.hostName,
    streamerRole: primaryRoom.hostRole,
    bannedUsersCount: bannedUserIds.size,
    serverTime: new Date().toISOString()
  });
});

// Update Video Config for a room
app.post('/api/live/rooms/:roomId/config', (req, res) => {
  const room = liveRooms.find(r => r.id === req.params.roomId);
  if (!room) return res.status(404).json({ error: 'Không tìm thấy phòng live' });

  const { resolution, fps, bitrateMbps, stabilization, autofocus, svcEnabled } = req.body;
  if (resolution) room.videoConfig.resolution = resolution;
  if (fps) room.videoConfig.fps = Number(fps) === 60 ? 60 : 30;
  if (bitrateMbps) room.videoConfig.bitrateMbps = Number(bitrateMbps);
  if (typeof stabilization === 'boolean') room.videoConfig.stabilization = stabilization;
  if (typeof autofocus === 'boolean') room.videoConfig.autofocus = autofocus;
  if (typeof svcEnabled === 'boolean') room.videoConfig.svcEnabled = svcEnabled;

  res.json({ success: true, config: room.videoConfig });
});

// End Live Room (Streamer Exclusive)
app.post('/api/live/rooms/:roomId/end', (req, res) => {
  const room = liveRooms.find(r => r.id === req.params.roomId);
  if (!room) return res.status(404).json({ error: 'Không tìm thấy phòng live' });
  room.status = 'ended';

  // System notification in room chat
  const msgs = roomChatMap.get(room.id) || [];
  msgs.push({
    id: 'sys_ended_' + Date.now(),
    senderId: 'system',
    senderName: 'Hệ Thống LiveKit',
    senderAvatar: '/Logo & Thương Hiệu (Brand Logo)/dreamina-2026-07-29-3008-A minimalist stencil-style logo of an oc....png',
    senderBadge: 'BQT',
    text: '🔴 Buổi phát sóng này đã chính thức kết thúc. Xin chân thành cảm ơn quý khán giả đã đồng hành cùng NPTTEAMSTORE!',
    createdAt: new Date().toLocaleTimeString('vi-VN', { hour: '2-digit', minute: '2-digit' }),
    isAdmin: true
  });
  roomChatMap.set(room.id, msgs);

  res.json({ success: true, room });
});

// Reopen / Reset Official Showcase Room if all rooms were closed
app.post('/api/live/rooms/reset-official', (_req, res) => {
  const official = liveRooms.find(r => r.id === 'room_npt_official');
  if (official) {
    official.status = 'live';
    official.startedAt = new Date().toISOString();
  } else {
    liveRooms.unshift({
      id: 'room_npt_official',
      title: '🔴 SHOWCASE CHÍNH THỨC: TEST ĐAI DX HENSHIN BELT & CAPSEM BANDAI JAPAN 2026',
      hostId: 'host_npt_official',
      hostName: 'NPTTEAMSTORE Official',
      hostAvatar: '/Logo & Thương Hiệu (Brand Logo)/dreamina-2026-07-29-3008-A minimalist stencil-style logo of an oc....png',
      hostRole: 'Kênh Phân Phối Bandai Japan Chính Thức',
      hostBadge: '👑 OFFICIAL',
      isOfficial: true,
      category: 'Đai Biến Hình DX & CSM',
      status: 'live',
      startedAt: new Date().toISOString(),
      pinnedProductId: 'p1',
      thumbnail: '/Ảnh Showroom & Cửa Hàng/20240708_161850.jpg',
      viewerCount: 128,
      videoConfig: {
        resolution: '1080p',
        fps: 60,
        bitrateMbps: 4.0,
        svcEnabled: true,
        stabilization: true,
        autofocus: true,
      }
    });
  }
  const activeRooms = liveRooms.filter(r => r.status === 'live');
  res.json({ success: true, rooms: activeRooms });
});

// 2. Real Messages per Room (ZERO FAKE ACCOUNTS)
app.get('/api/live/rooms/:roomId/messages', (req, res) => {
  const userId = req.query.userId as string;
  if (userId && bannedUserIds.has(userId)) {
    return res.status(403).json({ error: 'Tài khoản của bạn đã bị cấm khỏi phòng Live!', isBanned: true });
  }

  const msgs = roomChatMap.get(req.params.roomId) || [];
  const visibleMessages = msgs.filter(m => !m.isHidden);
  res.json({ messages: visibleMessages });
});

// Post Message to Room
app.post('/api/live/rooms/:roomId/messages', (req, res) => {
  const { senderId, senderName, senderAvatar, senderBadge, text, file, isAdmin } = req.body;
  const roomId = req.params.roomId;
  const room = liveRooms.find(r => r.id === roomId);

  const clientIp = getClientIp(req);
  if (bannedIps.has(clientIp)) {
    return res.status(403).json({ error: 'Địa chỉ IP của bạn đã bị Quản Trị Viên chặn bình luận!', isIpBlocked: true });
  }

  if (senderId && bannedUserIds.has(senderId)) {
    return res.status(403).json({ error: 'Bạn đã bị cấm chat trên livestream!' });
  }

  // Streamer Exclusive: Chat lock enforcement for viewers
  if (room?.isChatLocked && !isAdmin) {
    return res.status(423).json({ error: 'Streamer đang tạm khóa bình luận phòng live để tập trung giới thiệu sản phẩm!' });
  }

  if (!text && !file) {
    return res.status(400).json({ error: 'Tin nhắn hoặc tệp tin không được để trống' });
  }

  const links = text ? extractLinksWithPreview(text) : undefined;
  const now = new Date().toLocaleTimeString('vi-VN', { hour: '2-digit', minute: '2-digit' });

  const newMsg: LiveChatMsg = {
    id: 'msg_' + Date.now() + '_' + Math.random().toString(36).substring(2, 7),
    senderId: senderId || 'anon',
    senderName: senderName || 'Khán giả',
    senderAvatar: senderAvatar || '/BIỂU TƯỢNG DANH MỤC SẢN PHẨM/dlyjpm8-ea90294c-de09-4bc2-8718-6b49acbf082e.png',
    senderBadge: isAdmin ? '👑 BQT' : senderBadge,
    isAdmin: !!isAdmin,
    text: text || '',
    createdAt: now,
    links,
    file
  };

  const msgs = roomChatMap.get(roomId) || [];
  msgs.push(newMsg);
  if (msgs.length > 200) {
    roomChatMap.set(roomId, msgs.slice(-200));
  } else {
    roomChatMap.set(roomId, msgs);
  }

  res.json({ success: true, message: newMsg });
});

// Streamer Exclusive: Toggle Lock / Unlock Chat in Room
app.post('/api/live/rooms/:roomId/lock-chat', (req, res) => {
  const room = liveRooms.find(r => r.id === req.params.roomId);
  if (!room) return res.status(404).json({ error: 'Không tìm thấy phòng live' });

  const { isLocked } = req.body;
  room.isChatLocked = typeof isLocked === 'boolean' ? isLocked : !room.isChatLocked;

  // System notification in chat
  const msgs = roomChatMap.get(room.id) || [];
  msgs.push({
    id: 'sys_' + Date.now(),
    senderId: 'system',
    senderName: 'Hệ Thống',
    senderAvatar: '/Logo & Thương Hiệu (Brand Logo)/dreamina-2026-07-29-3008-A minimalist stencil-style logo of an oc....png',
    senderBadge: 'BQT',
    text: room.isChatLocked 
      ? '🔒 Streamer đã tạm khóa bình luận phòng live để tập trung giới thiệu sản phẩm.' 
      : '🔓 Streamer đã mở lại tính năng bình luận cho tất cả khán giả.',
    createdAt: new Date().toLocaleTimeString('vi-VN', { hour: '2-digit', minute: '2-digit' }),
    isAdmin: true
  });
  roomChatMap.set(room.id, msgs);

  res.json({ success: true, isChatLocked: room.isChatLocked });
});

// Streamer Exclusive: Update Live Product Stock
app.post('/api/live/rooms/:roomId/update-stock', (req, res) => {
  const room = liveRooms.find(r => r.id === req.params.roomId);
  if (!room) return res.status(404).json({ error: 'Không tìm thấy phòng live' });

  const { productId, newStock } = req.body;
  if (!room.productStocks) room.productStocks = {};
  room.productStocks[productId] = Math.max(0, Number(newStock) || 0);

  res.json({ success: true, productStocks: room.productStocks });
});

// Backward compatibility: /api/live/messages maps to first room
app.get('/api/live/messages', (req, res) => {
  const primaryRoomId = liveRooms[0]?.id || 'room_npt_official';
  const msgs = roomChatMap.get(primaryRoomId) || [];
  const visibleMessages = msgs.filter(m => !m.isHidden);
  res.json({ messages: visibleMessages });
});

app.post('/api/live/messages', (req, res) => {
  const primaryRoomId = liveRooms[0]?.id || 'room_npt_official';
  const { senderId, senderName, senderAvatar, senderBadge, text, file, isAdmin } = req.body;

  if (senderId && bannedUserIds.has(senderId)) {
    return res.status(403).json({ error: 'Bạn đã bị cấm chat trên livestream!' });
  }

  if (!text && !file) {
    return res.status(400).json({ error: 'Tin nhắn hoặc tệp tin không được để trống' });
  }

  const links = text ? extractLinksWithPreview(text) : undefined;
  const now = new Date().toLocaleTimeString('vi-VN', { hour: '2-digit', minute: '2-digit' });

  const newMsg: LiveChatMsg = {
    id: 'msg_' + Date.now() + '_' + Math.random().toString(36).substring(2, 7),
    senderId: senderId || 'anon',
    senderName: senderName || 'Khán giả',
    senderAvatar: senderAvatar || '/BIỂU TƯỢNG DANH MỤC SẢN PHẨM/dlyjpm8-ea90294c-de09-4bc2-8718-6b49acbf082e.png',
    senderBadge: isAdmin ? '👑 BQT' : senderBadge,
    isAdmin: !!isAdmin,
    text: text || '',
    createdAt: now,
    links,
    file
  };

  const msgs = roomChatMap.get(primaryRoomId) || [];
  msgs.push(newMsg);
  roomChatMap.set(primaryRoomId, msgs.slice(-200));

  res.json({ success: true, message: newMsg });
});

// 3. File / Image Upload for Chat
app.post('/api/live/upload', (req, res) => {
  try {
    const { fileName, mimeType, base64Data } = req.body;
    if (!fileName || !base64Data) {
      return res.status(400).json({ error: 'Thiếu thông tin tệp tin cần upload' });
    }

    const cleanBase64 = base64Data.replace(/^data:.*?;base64,/, '');
    const buffer = Buffer.from(cleanBase64, 'base64');
    const fileId = 'file_' + Date.now() + '_' + Math.random().toString(36).substring(2, 8);

    const record: LiveFileRecord = {
      id: fileId,
      name: fileName,
      mimeType: mimeType || 'application/octet-stream',
      buffer,
      size: buffer.length,
      uploadedAt: new Date().toISOString()
    };

    liveFiles.set(fileId, record);

    res.json({
      success: true,
      file: {
        id: fileId,
        name: fileName,
        size: buffer.length,
        mimeType: record.mimeType,
        url: `/api/live/files/${fileId}`
      }
    });
  } catch (err: any) {
    console.error('File upload error:', err);
    res.status(500).json({ error: 'Không thể xử lý tệp tin tải lên' });
  }
});

// Serve uploaded file with HTML5 download headers
app.get('/api/live/files/:id', (req, res) => {
  const file = liveFiles.get(req.params.id);
  if (!file) {
    return res.status(404).json({ error: 'Tệp không tồn tại hoặc đã hết hạn' });
  }

  res.setHeader('Content-Type', file.mimeType);
  res.setHeader('Content-Length', file.size);
  res.setHeader('Content-Disposition', `inline; filename="${encodeURIComponent(file.name)}"`);
  res.send(file.buffer);
});

// 4. Pin / Unpin Product on Live
app.post('/api/live/pin-product', (req, res) => {
  const { productId, roomId } = req.body;
  const targetRoom = liveRooms.find(r => r.id === roomId) || liveRooms[0];
  if (targetRoom) {
    targetRoom.pinnedProductId = productId || '';
  }
  res.json({ success: true, pinnedProductId: targetRoom?.pinnedProductId });
});

// 5. Flash Sale Trigger & Countdown
app.post('/api/live/flash-sale', (req, res) => {
  const { code, discountText, percent, maxDiscount, durationSeconds = 300, roomId } = req.body;
  const targetRoom = liveRooms.find(r => r.id === roomId) || liveRooms[0];
  if (targetRoom) {
    targetRoom.flashSale = {
      active: true,
      code: code || 'LIVEFLASH50',
      discountText: discountText || 'Giảm ngay 20% cho đơn hàng Live',
      percent: percent || 20,
      maxDiscount: maxDiscount || 300000,
      expiresAt: new Date(Date.now() + durationSeconds * 1000).toISOString(),
      durationSeconds
    };
  }
  res.json({ success: true, flashSale: targetRoom?.flashSale });
});

// 6. Purchase Event Ticker
app.get('/api/live/purchases', (_req, res) => {
  res.json({ purchases: purchaseEvents.slice(-10) });
});

app.post('/api/live/purchase', (req, res) => {
  const { customerName, productName, productImage, roomId, productPrice, productId } = req.body;
  if (!customerName || !productName) {
    return res.status(400).json({ error: 'Thiếu thông tin người mua' });
  }

  const targetRoom = liveRooms.find(r => r.id === roomId) || liveRooms[0];
  const priceNum = Number(productPrice) || 2850000;
  if (targetRoom) {
    targetRoom.totalOrders = (targetRoom.totalOrders || 0) + 1;
    targetRoom.totalRevenue = (targetRoom.totalRevenue || 0) + priceNum;
    if (productId && targetRoom.productStocks && targetRoom.productStocks[productId] > 0) {
      targetRoom.productStocks[productId] -= 1;
    }
  }

  const newPurchase = {
    id: 'pur_' + Date.now(),
    customerName,
    productName,
    productImage: productImage || '/Ảnh Sản Phẩm/dx/Kamen Rider Zeztz DX Henshin Belt Lord Invoker1.jpg',
    time: 'Vừa xong'
  };

  purchaseEvents.unshift(newPurchase);
  if (purchaseEvents.length > 30) purchaseEvents = purchaseEvents.slice(0, 30);

  res.json({ 
    success: true, 
    purchase: newPurchase,
    totalOrders: targetRoom?.totalOrders,
    totalRevenue: targetRoom?.totalRevenue,
    productStocks: targetRoom?.productStocks
  });
});

// 7. Viewer Moderation (Kick / Block / Ban / Hide Message)
app.post('/api/live/moderate/kick', (req, res) => {
  const { userId, userToken, reason, roomId } = req.body;
  if (userToken) kickedTokens.add(userToken);
  if (userId) kickedTokens.add(userId);

  const targetRoomId = roomId || liveRooms[0]?.id || 'room_npt_official';
  const msgs = roomChatMap.get(targetRoomId) || [];

  // Add system note to this room's real log
  msgs.push({
    id: 'sys_' + Date.now(),
    senderId: 'system',
    senderName: 'Hệ Thống Kiểm Duyệt',
    senderAvatar: '/Logo & Thương Hiệu (Brand Logo)/dreamina-2026-07-29-3008-A minimalist stencil-style logo of an oc....png',
    senderBadge: 'BOT',
    text: `⚠️ Quản trị viên đã đá người dùng [${userId || 'ẩn danh'}] ra khỏi phòng livestream. Lý do: ${reason || 'Vi phạm nội quy'}`,
    createdAt: new Date().toLocaleTimeString('vi-VN', { hour: '2-digit', minute: '2-digit' }),
    isAdmin: true
  });
  roomChatMap.set(targetRoomId, msgs);

  res.json({ success: true, message: `Đã kick người dùng ${userId || userToken}` });
});

app.post('/api/live/moderate/ban', (req, res) => {
  const { userId, reason, roomId } = req.body;
  if (!userId) return res.status(400).json({ error: 'Thiếu userId' });

  bannedUserIds.add(userId);

  // Hide their past messages in all rooms
  roomChatMap.forEach(msgs => {
    msgs.forEach(m => {
      if (m.senderId === userId) m.isHidden = true;
    });
  });

  const targetRoomId = roomId || liveRooms[0]?.id || 'room_npt_official';
  const msgs = roomChatMap.get(targetRoomId) || [];

  msgs.push({
    id: 'sys_ban_' + Date.now(),
    senderId: 'system',
    senderName: 'Hệ Thống Kiểm Duyệt',
    senderAvatar: '/Logo & Thương Hiệu (Brand Logo)/dreamina-2026-07-29-3008-A minimalist stencil-style logo of an oc....png',
    senderBadge: 'BANNED',
    text: `🚫 Người dùng [${userId}] đã bị CẤM vĩnh viễn khỏi phòng live do: ${reason || 'Spam / Ngôn từ không phù hợp'}!`,
    createdAt: new Date().toLocaleTimeString('vi-VN', { hour: '2-digit', minute: '2-digit' }),
    isAdmin: true
  });
  roomChatMap.set(targetRoomId, msgs);

  res.json({ success: true, bannedUserIds: Array.from(bannedUserIds) });
});

app.post('/api/live/moderate/hide-message', (req, res) => {
  const { messageId } = req.body;
  roomChatMap.forEach(msgs => {
    const msg = msgs.find(m => m.id === messageId);
    if (msg) msg.isHidden = true;
  });
  res.json({ success: true, hiddenId: messageId });
});

// Check moderation status for a client
app.get('/api/live/moderate/status/:userId', (req, res) => {
  const { userId } = req.params;
  const isBanned = bannedUserIds.has(userId);
  const isKicked = kickedTokens.has(userId);
  res.json({ isBanned, isKicked });
});

async function startServer() {
  const isProd = process.env.NODE_ENV === 'production';
  const isHmrDisabled = process.env.DISABLE_HMR === 'true';

  if (!isProd) {
    const vite = await createViteServer({
      server: {
        middlewareMode: true,
        hmr: false,
      },
      appType: 'spa',
    });
    app.use(vite.middlewares);
  } else {
    app.use(express.static(path.resolve(__dirname, 'dist')));
    app.get('*', (_req, res) => {
      res.sendFile(path.resolve(__dirname, 'dist', 'index.html'));
    });
  }

  server.listen(PORT, '0.0.0.0', () => {
    console.log(`🚀 NPTTEAMSTORE Full-stack server running on port ${PORT}`);
  });
}

startServer();
