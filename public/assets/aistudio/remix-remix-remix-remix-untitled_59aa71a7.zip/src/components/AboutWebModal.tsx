import React from 'react';

interface AboutWebModalProps {
  isOpen: boolean;
  onClose: () => void;
}

export const AboutWebModal: React.FC<AboutWebModalProps> = ({ isOpen, onClose }) => {
  if (!isOpen) return null;

  const riderLogos = [
    { name: 'Kamen Rider Revice Logo', src: '/BIỂU TƯỢNG DANH MỤC SẢN PHẨM/kamen_rider_revice_logo_by_driftingcar_dghk15w-pre.png' },
    { name: 'Kamen Rider Saber Logo', src: '/BIỂU TƯỢNG DANH MỤC SẢN PHẨM/kamen_rider_saber_logo_by_driftingcar_dgh9vay-pre.png' },
    { name: 'Kamen Rider Kiva Logo', src: '/BIỂU TƯỢNG DANH MỤC SẢN PHẨM/kamen_rider_kiva_logo_by_driftingcar_dg7tj5z-pre.png' },
    { name: 'Kamen Rider Knight Logo', src: '/BIỂU TƯỢNG DANH MỤC SẢN PHẨM/kamen_rider_knight_logo_by_driftingcar_dg73k3x-414w-2x.png' },
    { name: 'Kamen Rider Femme Logo', src: '/BIỂU TƯỢNG DANH MỤC SẢN PHẨM/kamen_rider_femme_logo_by_driftingcar_dg73lkh-pre.png' },
  ];

  return (
    <div className="fixed inset-0 z-[100] bg-black/80 backdrop-blur-md flex items-center justify-center p-4 overflow-y-auto animate-fadeIn">
      <div 
        className="relative w-full max-w-4xl bg-gradient-to-b from-[#181524] via-[#0D0B12] to-[#08070C] border-2 border-[#C9A84C] rounded-3xl p-6 sm:p-8 shadow-[0_0_50px_rgba(201,168,76,0.35)] text-[#F5F2EB] my-8 overflow-hidden gold-silver-border"
        onClick={(e) => e.stopPropagation()}
      >
        {/* Decorative Gold Light Burst */}
        <div className="absolute top-0 right-0 w-96 h-96 bg-[#C9A84C]/10 rounded-full blur-3xl pointer-events-none"></div>
        <div className="absolute bottom-0 left-0 w-80 h-80 bg-[#8B1E1E]/20 rounded-full blur-3xl pointer-events-none"></div>

        {/* Close Button */}
        <button
          onClick={onClose}
          className="absolute top-4 right-4 w-10 h-10 rounded-full bg-[#1A1A1A] hover:bg-[#8B1E1E] text-gray-400 hover:text-white border border-[#2A2A2A] hover:border-[#C9A84C] flex items-center justify-center transition duration-300 z-10 shadow-lg"
          title="Đóng cửa sổ"
        >
          <i className="fa-solid fa-xmark text-lg"></i>
        </button>

        {/* Header Title Section */}
        <div className="text-center space-y-3 pb-6 border-b border-[#C9A84C]/30 relative z-10">
          <div className="inline-flex items-center gap-2 bg-[#C9A84C]/10 border border-[#C9A84C]/50 px-4 py-1 rounded-full text-[#C9A84C] text-xs font-black uppercase tracking-widest">
            <i className="fa-solid fa-crown text-amber-300"></i> GIỚI THIỆU & TIỂU SỬ THƯƠNG HIỆU
          </div>

          <div className="flex flex-col items-center justify-center gap-2">
            <div className="w-20 h-20 bg-[#070c1e] rounded-2xl p-2 border-2 border-cyan-400 shadow-[0_0_20px_rgba(0,255,255,0.6)] flex items-center justify-center">
              <img 
                src="/Logo & Thương Hiệu (Brand Logo)/dreamina-2026-07-29-3008-A minimalist stencil-style logo of an oc....png" 
                alt="NPTTEAMSTORE Official" 
                className="w-full h-full object-contain filter drop-shadow-[0_0_10px_rgba(0,255,255,0.8)]"
                onError={(e) => { e.currentTarget.style.display = 'none'; }}
              />
            </div>
            <h2 className="font-serif-title text-2xl sm:text-4xl font-black tracking-wider text-white uppercase text-pop">
              NPTTEAM<span className="gold-gradient-text">STORE</span>
            </h2>
            <p className="text-xs sm:text-sm text-slate-200 font-medium max-w-xl">
              Thương Hiệu Cung Cấp Mô Hình & Đai Lưng Henshin Tokusatsu Bandai Japan Chính Hãng Số 1 Việt Nam
            </p>
          </div>
        </div>

        {/* Scrollable Content Body */}
        <div className="mt-6 space-y-8 max-h-[60vh] overflow-y-auto pr-2 custom-scrollbar text-xs sm:text-sm leading-relaxed text-gray-300">
          
          {/* Creator Profile Box - Arranged neatly with King, Vice Leader, Cheerleaders */}
          <div className="bg-gradient-to-r from-[#1c1404] via-[#0f111c] to-[#070b14] border-2 border-amber-400/80 rounded-2xl p-5 shadow-xl space-y-4">
            <div className="flex flex-col sm:flex-row items-center gap-4">
              {/* Leader Photo with Tight-fit Gold Border and King Crown */}
              <div className="relative shrink-0">
                <div className="absolute -top-3 -left-2 z-20 flex items-center justify-center bg-gradient-to-r from-amber-400 to-yellow-300 text-black p-1 rounded-full shadow-lg border-2 border-yellow-200">
                  <span className="text-base leading-none">👑</span>
                </div>
                <div className="w-20 h-20 rounded-2xl overflow-hidden bg-[#060a18] p-0.5 border-2 border-amber-400 shadow-[0_0_15px_rgba(245,158,11,0.6)]">
                  <img 
                    src="/Ảnh Sản Phẩm/teamnpt/Đoàn Tiến Đạt.jpg" 
                    alt="Đoàn Tiến Đạt - Trưởng Nhóm" 
                    className="w-full h-full object-cover rounded-[14px]"
                    onError={(e) => {
                      e.currentTarget.src = '/Logo & Thương Hiệu (Brand Logo)/dreamina-2026-07-29-3008-A minimalist stencil-style logo of an oc....png';
                    }}
                  />
                </div>
              </div>

              <div className="space-y-1 text-center sm:text-left flex-grow">
                <div className="flex items-center justify-center sm:justify-start gap-2 flex-wrap">
                  <span className="bg-gradient-to-r from-amber-400 to-yellow-400 text-black text-[9px] font-black px-2.5 py-0.5 rounded-full uppercase shadow">
                    👑 TRƯỞNG NHÓM SÁNG LẬP
                  </span>
                  <span className="bg-amber-400/20 border border-amber-400/60 text-amber-300 text-[9px] font-black px-2.5 py-0.5 rounded-full">
                    KIẾN TRÚC SƯ HỆ THỐNG
                  </span>
                </div>
                <h3 className="font-serif-title text-base sm:text-lg font-black text-white text-pop flex items-center justify-center sm:justify-start gap-1.5">
                  Đoàn Tiến Đạt <span className="text-amber-400">👑</span>
                </h3>
                <p className="text-xs text-slate-200">
                  Sáng lập nền tảng, thiết kế trải nghiệm người dùng và điều phối toàn diện hệ sinh thái NPTTEAMSTORE.
                </p>
              </div>
            </div>

            {/* Sub-row: Vice Leader & Board of Directors */}
            <div className="grid grid-cols-1 sm:grid-cols-2 gap-3 pt-3 border-t border-white/10 text-xs">
              {/* Vice Leader */}
              <div className="bg-[#0b1022] border-2 border-slate-300/70 rounded-xl p-3 flex items-center gap-3">
                <div className="relative shrink-0">
                  <div className="w-12 h-12 rounded-xl overflow-hidden bg-[#060a18] p-0.5 border-2 border-slate-200 shadow-[0_0_12px_rgba(226,232,240,0.4)]">
                    <img 
                      src="/Ảnh Sản Phẩm/teamnpt/Vũ Tạ Hữu Luân.jpg" 
                      alt="Vũ Tạ Hữu Luân" 
                      className="w-full h-full object-cover rounded-[8px]"
                    />
                  </div>
                  <div className="absolute -top-1.5 -left-1.5 w-5 h-5 rounded-full bg-slate-900 border border-slate-300 flex items-center justify-center text-[10px]">
                    ⚔️
                  </div>
                </div>
                <div className="min-w-0">
                  <span className="inline-block text-[8px] font-black uppercase px-2 py-0.5 rounded-full bg-slate-200 text-slate-950 font-bold mb-0.5">
                    ⚔️ PHÓ NHÓM ĐIỀU HÀNH
                  </span>
                  <h4 className="font-bold text-white text-xs truncate">Vũ Tạ Hữu Luân</h4>
                  <p className="text-[10px] text-slate-300">Cố vấn chiến lược & Quan hệ đối tác</p>
                </div>
              </div>

              {/* Board of Administrators */}
              <div className="bg-[#0a1428] border-2 border-cyan-500/50 rounded-xl p-3 flex items-center gap-3">
                <div className="w-12 h-12 rounded-xl bg-cyan-950/60 border border-cyan-400/60 flex items-center justify-center text-xl shrink-0 text-cyan-300">
                  🛡️
                </div>
                <div className="min-w-0">
                  <span className="inline-block text-[8px] font-black uppercase px-2 py-0.5 rounded-full bg-cyan-500/20 text-cyan-300 border border-cyan-400/40 mb-0.5">
                    BAN QUẢN TRỊ ĐỒNG SÁNG LẬP
                  </span>
                  <h4 className="font-bold text-white text-xs truncate">Hoàng Trọng Hiệp, Nguyễn Thành Danh, Vũ Thanh Bình</h4>
                  <p className="text-[10px] text-slate-300">Vận hành kho vận, kiểm định chất lượng & cộng đồng</p>
                </div>
              </div>
            </div>
          </div>

          {/* Showroom Photo Section - Tight-fitting crisp frame */}
          <div className="space-y-3">
            <h3 className="font-serif-title text-base sm:text-lg font-black text-[#F5F2EB] flex items-center gap-2 border-b border-[#2A2A2A] pb-2">
              <i className="fa-solid fa-store text-amber-400"></i>
              <span className="gold-gradient-text uppercase">KHÔNG GIAN SHOWROOM CỘNG ĐỒNG TOKUSATSU</span>
            </h3>
            <div className="relative rounded-2xl overflow-hidden border-2 border-amber-400/70 p-1 bg-[#060b18] shadow-2xl group">
              <div className="relative h-56 sm:h-72 rounded-xl overflow-hidden bg-black">
                <img 
                  src="/Ảnh Showroom & Cửa Hàng/20240708_161850.jpg" 
                  alt="Không gian Showroom NPTTEAMSTORE Trưng Bày Mô Hình" 
                  className="w-full h-full object-cover group-hover:scale-105 transition duration-700"
                />
                <div className="absolute inset-0 bg-gradient-to-t from-black via-black/30 to-transparent p-4 flex flex-col justify-end">
                  <span className="bg-rose-600 text-white font-black text-[10px] px-3 py-1 rounded-full uppercase w-fit mb-1 border border-amber-400 shadow">
                    Showroom Thực Tế 100%
                  </span>
                  <p className="font-bold text-white text-sm">Trưng bày hơn 500+ bộ đai DX, CSM và mô hình S.H.Figuarts độc bản</p>
                  <p className="text-xs text-slate-300">Địa chỉ: 123 Đường Henshin, Phường Tokusatsu, Quận 1, TP. Hồ Chí Minh</p>
                </div>
              </div>
            </div>
          </div>

          {/* Rider Logos Gallery - Tight-fitting borders around logos */}
          <div className="space-y-3">
            <h3 className="font-serif-title text-base sm:text-lg font-black text-[#F5F2EB] flex items-center gap-2 border-b border-[#2A2A2A] pb-2">
              <i className="fa-solid fa-dragon text-amber-400"></i>
              <span className="gold-gradient-text uppercase">BẢO TÀNG BIỂU TƯỢNG RIDER CHÍNH THỨC</span>
            </h3>
            <div className="grid grid-cols-2 sm:grid-cols-5 gap-3">
              {riderLogos.map((logo, index) => (
                <div key={index} className="bg-[#060a16] border-2 border-amber-400/40 hover:border-amber-400 rounded-xl p-2 flex flex-col items-center justify-center gap-1.5 transition group shadow-sm">
                  <div className="w-full h-12 bg-[#030610] rounded-lg p-1 border border-white/10 flex items-center justify-center">
                    <img src={logo.src} alt={logo.name} className="max-w-full max-h-full object-contain filter group-hover:scale-105 transition duration-300" />
                  </div>
                  <span className="text-[10px] text-slate-300 font-bold text-center line-clamp-1">{logo.name}</span>
                </div>
              ))}
            </div>
          </div>

          {/* Biography / History Timeline */}
          <div className="space-y-4">
            <h3 className="font-serif-title text-base sm:text-lg font-black text-[#F5F2EB] flex items-center gap-2 border-b border-[#2A2A2A] pb-2">
              <i className="fa-solid fa-timeline text-[#C9A84C]"></i>
              <span className="gold-gradient-text uppercase">LỊCH SỬ HÌNH THÀNH & TIỂU SỬ WEBSITE</span>
            </h3>

            <div className="space-y-4 relative before:absolute before:left-3.5 before:top-2 before:bottom-2 before:w-0.5 before:bg-gradient-to-b before:from-[#C9A84C] before:via-[#8B1E1E] before:to-[#2A2A2A] pl-8">
              
              {/* Milestone 1 */}
              <div className="relative space-y-1">
                <div className="absolute -left-8 top-1 w-4 h-4 rounded-full bg-[#C9A84C] border-2 border-[#0A0A0A] shadow-[0_0_10px_rgba(201,168,76,0.8)]"></div>
                <div className="flex items-center gap-2">
                  <span className="font-serif-title font-black text-xs text-[#C9A84C] bg-[#C9A84C]/10 border border-[#C9A84C]/30 px-2 py-0.5 rounded">NĂM 2018</span>
                  <h4 className="font-bold text-white text-sm">Khởi Nguồn Từ Đam Mê Tokusatsu</h4>
                </div>
                <p className="text-xs text-gray-300">
                  NPTTEAMSTORE ban đầu được khởi xướng bởi Team NPT như một nhóm giao lưu sưu tầm mô hình S.H.Figuarts & DX Henshin Belt nhỏ lẻ tại TP. Hồ Chí Minh. Ban quản trị đặt nền móng với tiêu chí: "Chỉ cung cấp hàng thật, bảo tồn văn hóa Kamen Rider".
                </p>
              </div>

              {/* Milestone 2 */}
              <div className="relative space-y-1">
                <div className="absolute -left-8 top-1 w-4 h-4 rounded-full bg-[#8B1E1E] border-2 border-[#0A0A0A] shadow-[0_0_10px_rgba(139,30,30,0.8)]"></div>
                <div className="flex items-center gap-2">
                  <span className="font-serif-title font-black text-xs text-rose-400 bg-rose-900/30 border border-rose-500/30 px-2 py-0.5 rounded">NĂM 2021</span>
                  <h4 className="font-bold text-white text-sm">Trở Thành Đơn Vị Nhập Khẩu Bandai Japan Trực Tiếp</h4>
                </div>
                <p className="text-xs text-gray-300">
                  Chính thức hợp tác nhập khẩu chính ngạch từ Nhật Bản cho các dòng đai lưng cao cấp CSM (Complete Selection Modification), Premium Bandai và Super Sentai Mecha. Mở rộng showroom trưng bày trên 500+ sản phẩm độc bản.
                </p>
              </div>

              {/* Milestone 3 */}
              <div className="relative space-y-1">
                <div className="absolute -left-8 top-1 w-4 h-4 rounded-full bg-cyan-400 border-2 border-[#0A0A0A] shadow-[0_0_10px_rgba(0,255,255,0.8)]"></div>
                <div className="flex items-center gap-2">
                  <span className="font-serif-title font-black text-xs text-cyan-300 bg-cyan-500/20 border border-cyan-400/40 px-2 py-0.5 rounded">NĂM 2024 - 2026</span>
                  <h4 className="font-bold text-white text-sm">Nâng Cấp Nền Tảng Thương Mại Điện Tử NPTTEAMSTORE</h4>
                </div>
                <p className="text-xs text-gray-300">
                  Ra mắt website NPTTEAMSTORE phiên bản 4.0 với giao diện Tokusatsu sang trọng, tính năng Live Stream 4K Max Audio, Tra cứu đơn hàng tự động, Bảng So Sánh & Yêu Thích mô hình linh hoạt cùng hệ thống Rider Points đổi quà VIP.
                </p>
              </div>

            </div>
          </div>

          {/* Core Commitments Grid */}
          <div className="space-y-3">
            <h3 className="font-serif-title text-base sm:text-lg font-black text-white flex items-center gap-2 border-b border-cyan-500/30 pb-2 text-pop">
              <i className="fa-solid fa-shield-cat text-cyan-400"></i>
              <span className="gold-gradient-text uppercase">4 CAM KẾT VÀNG TẠI NPTTEAMSTORE</span>
            </h3>

            <div className="grid grid-cols-1 sm:grid-cols-2 gap-3.5">
              <div className="bg-[#121018] p-3.5 rounded-xl border border-cyan-500/40 flex items-start gap-3">
                <div className="w-8 h-8 rounded-lg bg-cyan-400 text-[#0A0A0A] font-black flex items-center justify-center shrink-0">
                  <i className="fa-solid fa-check"></i>
                </div>
                <div>
                  <h5 className="font-bold text-white text-xs">100% Bandai Japan Chính Hãng</h5>
                  <p className="text-[11px] text-gray-400">Cam kết đền tiền 300% nếu phát hiện hàng nhái hay bootleg.</p>
                </div>
              </div>

              <div className="bg-[#121018] p-3.5 rounded-xl border border-cyan-500/40 flex items-start gap-3">
                <div className="w-8 h-8 rounded-lg bg-[#8B1E1E] text-white font-black flex items-center justify-center shrink-0">
                  <i className="fa-solid fa-screwdriver-wrench"></i>
                </div>
                <div>
                  <h5 className="font-bold text-white text-xs">Bảo Hành Âm Thanh & Đai Lưng</h5>
                  <p className="text-[11px] text-gray-400">Hỗ trợ sửa chữa chip âm thanh, thay thế phụ kiện miễn phí.</p>
                </div>
              </div>

              <div className="bg-[#121018] p-3.5 rounded-xl border border-cyan-500/40 flex items-start gap-3">
                <div className="w-8 h-8 rounded-lg bg-emerald-600 text-white font-black flex items-center justify-center shrink-0">
                  <i className="fa-solid fa-truck-fast"></i>
                </div>
                <div>
                  <h5 className="font-bold text-white text-xs">Giao Hàng Hỏa Tốc 2H</h5>
                  <p className="text-[11px] text-gray-400">Đóng gói xốp nổ chống đập box 3 lớp cho Collector kỹ tính.</p>
                </div>
              </div>

              <div className="bg-[#121018] p-3.5 rounded-xl border border-cyan-500/40 flex items-start gap-3">
                <div className="w-8 h-8 rounded-lg bg-amber-500 text-[#0A0A0A] font-black flex items-center justify-center shrink-0">
                  <i className="fa-solid fa-headset"></i>
                </div>
                <div>
                  <h5 className="font-bold text-white text-xs">Tư Vấn Wota Chuyên Sâu 24/7</h5>
                  <p className="text-[11px] text-gray-400">Đội ngũ am hiểu sâu sắc từng form kỉ nguyên Showa, Heisei & Reiwa.</p>
                </div>
              </div>
            </div>
          </div>

          {/* Contact & Showroom */}
          <div className="bg-[#0A0A0A] p-4 rounded-2xl border border-cyan-500/40 flex flex-col sm:flex-row items-center justify-between gap-4 text-xs">
            <div className="space-y-1 text-center sm:text-left">
              <p className="font-bold text-white flex items-center gap-1.5 justify-center sm:justify-start">
                <i className="fa-solid fa-location-dot text-cyan-400"></i>
                Showroom NPTTEAMSTORE: <span className="text-gray-200 font-normal">123 Đường Henshin, Phường Tokusatsu, Q.1, TP.HCM</span>
              </p>
              <p className="text-gray-300 flex items-center gap-1.5 justify-center sm:justify-start">
                <i className="fa-solid fa-phone text-cyan-400"></i>
                Hotline / Zalo Order: <strong className="text-cyan-300">0988.888.888</strong> (NPTTEAMSTORE)
              </p>
            </div>
            <button
              onClick={onClose}
              className="px-6 py-2.5 bg-gradient-to-r from-[#C9A84C] to-[#8B1E1E] text-white font-extrabold text-xs rounded-xl shadow-lg hover:brightness-110 transition shrink-0"
            >
              ⚡ Đã Hiểu - Khám Phá Store ngay
            </button>
          </div>

        </div>
      </div>
    </div>
  );
};
