import React, { useState, useEffect } from 'react';
import { User } from '../types';

interface AuthModalProps {
  isOpen: boolean;
  mode?: 'login' | 'register';
  onClose: () => void;
  onLoginSuccess: (user: User) => void;
  showToast: (msg: string, type?: 'success' | 'error' | 'info') => void;
}

export const AuthModal: React.FC<AuthModalProps> = ({
  isOpen,
  mode = 'login',
  onClose,
  onLoginSuccess,
  showToast
}) => {
  const [tab, setTab] = useState<'login' | 'register' | 'forgot'>(mode);
  const [email, setEmail] = useState('');
  const [password, setPassword] = useState('');
  const [name, setName] = useState('');
  const [phone, setPhone] = useState('');
  const [clientIp, setClientIp] = useState<string>('Đang nhận diện...');
  const [isIpBlocked, setIsIpBlocked] = useState(false);
  const [isSubmitting, setIsSubmitting] = useState(false);

  useEffect(() => {
    if (isOpen) {
      // Fetch Client IP
      fetch('/api/client/ip')
        .then(r => r.json())
        .then(d => {
          setClientIp(d.ip || '127.0.0.1');
          setIsIpBlocked(Boolean(d.isBlocked));
        })
        .catch(() => setClientIp('127.0.0.1'));
    }
  }, [isOpen]);

  if (!isOpen) return null;

  const handleLoginSubmit = async (e: React.FormEvent) => {
    e.preventDefault();
    if (!email || !password) return;

    if (isIpBlocked) {
      showToast('🚫 Địa chỉ IP của bạn đã bị Web Quản Lý chặn do vi phạm hoặc nghi vấn clone!', 'error');
      return;
    }

    setIsSubmitting(true);

    try {
      if (tab === 'register') {
        const res = await fetch('/api/customers/register', {
          method: 'POST',
          headers: { 'Content-Type': 'application/json' },
          body: JSON.stringify({
            name: name || email.split('@')[0],
            email,
            phone,
            clientReportedIp: clientIp
          })
        });

        const data = await res.json();
        if (res.status === 403 || data.isIpBlocked) {
          setIsIpBlocked(true);
          showToast(`🚫 ${data.error || 'Địa chỉ IP của bạn đã bị Web Quản Lý chặn!'}`, 'error');
          setIsSubmitting(false);
          return;
        }

        if (data.isCloneSuspect) {
          showToast('⚠️ Ghi chú: Hệ thống phát hiện IP này đã có tài khoản khác đăng ký.', 'info');
        }

        const newUser: User = {
          id: data.customer?.id || ('u-' + Date.now()),
          name: name || email.split('@')[0],
          email: email,
          phone: phone,
          role: 'user',
          riderPoints: 50,
          tierRank: 'Novice Rider',
          referralCode: 'RIDER-' + Math.random().toString(36).substr(2, 5).toUpperCase(),
          wishlist: []
        };

        onLoginSuccess(newUser);
        onClose();
        showToast(`🎉 Tạo tài khoản thành công! Dữ liệu & IP [${data.ip || clientIp}] đã gửi về Web Quản Lý.`, 'success');

      } else {
        // Login check
        const res = await fetch('/api/customers/login', {
          method: 'POST',
          headers: { 'Content-Type': 'application/json' },
          body: JSON.stringify({ email, clientReportedIp: clientIp })
        });

        const data = await res.json();
        if (res.status === 403 || data.isIpBlocked || data.isBlocked) {
          setIsIpBlocked(true);
          showToast(`🚫 ${data.error || 'Tài khoản hoặc IP của bạn đã bị chặn!'}`, 'error');
          setIsSubmitting(false);
          return;
        }

        const user: User = {
          id: data.customer?.id || ('u-' + Date.now()),
          name: data.customer?.name || name || email.split('@')[0] || 'Collector Rider',
          email: email,
          phone: data.customer?.phone || phone,
          role: email.includes('admin') ? 'admin' : 'user',
          riderPoints: 100,
          tierRank: 'Novice Rider',
          referralCode: 'RIDER-' + Math.random().toString(36).substr(2, 5).toUpperCase(),
          wishlist: []
        };

        onLoginSuccess(user);
        onClose();
        showToast(`🎉 Chào mừng ${user.name} đã đăng nhập!`, 'success');
      }
    } catch {
      // Local fallback
      const user: User = {
        id: 'u-' + Date.now(),
        name: name || email.split('@')[0] || 'Collector Rider',
        email: email,
        phone: phone,
        role: 'user',
        riderPoints: 50,
        tierRank: 'Novice Rider',
        referralCode: 'RIDER-NEW',
        wishlist: []
      };
      onLoginSuccess(user);
      onClose();
      showToast(`🎉 Đăng nhập thành công!`, 'success');
    } finally {
      setIsSubmitting(false);
    }
  };

  const handleSocialLogin = (provider: 'Google' | 'Facebook') => {
    const user: User = {
      id: 'u-' + Date.now(),
      name: `${provider} Rider Fan`,
      email: `rider.${provider.toLowerCase()}@gmail.com`,
      role: 'user',
      riderPoints: 0,
      tierRank: 'Novice Rider',
      referralCode: 'RIDER-NEW',
      wishlist: []
    };
    onLoginSuccess(user);
    onClose();
    showToast(`🎉 Đăng nhập qua ${provider} thành công!`, 'success');
  };

  return (
    <div className="fixed inset-0 z-50 flex items-center justify-center p-4 bg-[#0A0A0A]/85 backdrop-blur-md">
      <div className="bg-[#101728] border border-cyan-500/40 rounded-3xl w-full max-w-md p-6 relative shadow-2xl space-y-5 text-white ring-1 ring-cyan-400/20">
        <button 
          onClick={onClose}
          className="absolute top-4 right-4 text-slate-400 hover:text-white"
        >
          <i className="fa-solid fa-xmark text-base"></i>
        </button>

        {/* IP Tracking Notice Badge */}
        <div className="bg-[#0a0f1c] border border-cyan-500/30 rounded-xl p-2.5 flex items-center justify-between text-[11px]">
          <div className="flex items-center gap-1.5 text-slate-300">
            <i className="fa-solid fa-network-wired text-cyan-400"></i>
            <span>IP Thiết Bị:</span>
            <strong className="text-cyan-300 font-mono">{clientIp}</strong>
          </div>
          {isIpBlocked ? (
            <span className="text-rose-400 font-bold bg-rose-950/80 px-2 py-0.5 rounded text-[10px]">
              🚫 IP BỊ CHẶN
            </span>
          ) : (
            <span className="text-emerald-400 font-bold bg-emerald-950/80 px-2 py-0.5 rounded text-[10px]">
              ✓ Đã Kết Nối Quản Lý
            </span>
          )}
        </div>

        {/* Tab Switcher */}
        <div className="flex border-b border-slate-700 pb-3 gap-6 text-xs font-bold">
          <button 
            onClick={() => setTab('login')}
            className={`pb-1 transition cursor-pointer ${tab === 'login' ? 'text-cyan-400 border-b-2 border-cyan-400 font-black' : 'text-slate-400 hover:text-white'}`}
          >
            Đăng Nhập Khách
          </button>
          <button 
            onClick={() => setTab('register')}
            className={`pb-1 transition cursor-pointer ${tab === 'register' ? 'text-cyan-400 border-b-2 border-cyan-400 font-black' : 'text-slate-400 hover:text-white'}`}
          >
            Đăng Ký Tài Khoản Mới
          </button>
        </div>

        {/* Form Body */}
        <form onSubmit={handleLoginSubmit} className="space-y-3.5 text-xs">
          {tab === 'register' && (
            <>
              <div>
                <label className="block font-bold text-slate-300 uppercase text-[10px] mb-1">Họ và tên *</label>
                <input 
                  type="text"
                  required
                  value={name}
                  onChange={(e) => setName(e.target.value)}
                  placeholder="Ví dụ: Hoàng Long Rider..."
                  className="w-full bg-[#080d1a] border border-cyan-500/30 rounded-xl px-3.5 py-2 text-xs text-white focus:outline-none focus:border-cyan-400"
                />
              </div>

              <div>
                <label className="block font-bold text-slate-300 uppercase text-[10px] mb-1">Số điện thoại</label>
                <input 
                  type="tel"
                  value={phone}
                  onChange={(e) => setPhone(e.target.value)}
                  placeholder="0912..."
                  className="w-full bg-[#080d1a] border border-cyan-500/30 rounded-xl px-3.5 py-2 text-xs text-white focus:outline-none focus:border-cyan-400"
                />
              </div>
            </>
          )}

          <div>
            <label className="block font-bold text-slate-300 uppercase text-[10px] mb-1">Email tài khoản *</label>
            <input 
              type="email"
              required
              value={email}
              onChange={(e) => setEmail(e.target.value)}
              placeholder="email@vidu.com"
              className="w-full bg-[#080d1a] border border-cyan-500/30 rounded-xl px-3.5 py-2 text-xs text-white focus:outline-none focus:border-cyan-400"
            />
          </div>

          <div>
            <label className="block font-bold text-slate-300 uppercase text-[10px] mb-1">Mật khẩu *</label>
            <input 
              type="password"
              required
              value={password}
              onChange={(e) => setPassword(e.target.value)}
              placeholder="••••••••"
              className="w-full bg-[#080d1a] border border-cyan-500/30 rounded-xl px-3.5 py-2 text-xs text-white focus:outline-none focus:border-cyan-400"
            />
          </div>

          <button 
            type="submit"
            disabled={isSubmitting || isIpBlocked}
            className="w-full py-3 bg-gradient-to-r from-cyan-400 via-blue-500 to-indigo-600 text-black font-extrabold rounded-xl shadow-lg hover:brightness-110 transition cursor-pointer disabled:opacity-50"
          >
            {isSubmitting ? (
              <i className="fa-solid fa-spinner animate-spin"></i>
            ) : tab === 'login' ? (
              'Xác Nhận Đăng Nhập'
            ) : (
              'Tạo Tài Khoản & Gửi Dữ Liệu Về Quản Lý'
            )}
          </button>
        </form>

        {/* Social Auth Options */}
        <div className="space-y-3 pt-2 border-t border-slate-700 text-center">
          <p className="text-[10px] text-slate-400 uppercase tracking-wider font-bold">Hoặc kết nối nhanh qua</p>
          <div className="grid grid-cols-2 gap-3">
            <button 
              onClick={() => handleSocialLogin('Google')}
              className="py-2.5 bg-[#080d1a] hover:bg-[#121c38] border border-slate-700 rounded-xl font-bold text-xs text-slate-300 flex items-center justify-center gap-2 transition cursor-pointer"
            >
              <i className="fa-brands fa-google text-red-400"></i> Google
            </button>
            <button 
              onClick={() => handleSocialLogin('Facebook')}
              className="py-2.5 bg-[#080d1a] hover:bg-[#121c38] border border-slate-700 rounded-xl font-bold text-xs text-slate-300 flex items-center justify-center gap-2 transition cursor-pointer"
            >
              <i className="fa-brands fa-facebook text-blue-500"></i> Facebook
            </button>
          </div>
        </div>
      </div>
    </div>
  );
};
