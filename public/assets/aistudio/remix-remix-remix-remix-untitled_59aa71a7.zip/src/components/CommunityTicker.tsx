import React, { useState, useEffect } from 'react';
import { Order } from '../types';
import { generateCustomerAvatarSvgUrl } from '../utils/avatarGenerator';

interface CommunityTickerProps {
  latestOrder?: Order | null;
}

interface ActivityItem {
  name: string;
  action: string;
  item: string;
  time: string;
  avatar: string;
  badge: string;
  badgeColor: string;
  isCustomAvatar?: boolean;
}

const DEFAULT_ACTIVITIES: ActivityItem[] = [
  { 
    name: 'Hoàng Nam (TP.HCM)', 
    action: 'vừa đặt mua thành công', 
    item: 'DX Henshin Belt Gavv Set', 
    time: '1 phút trước', 
    avatar: generateCustomerAvatarSvgUrl({ maskId: 'gavv-gummy', colorId: 'crimson-ruby', initials: 'HN' }),
    badge: 'RIDER VIP',
    badgeColor: 'bg-cyan-500 text-slate-950',
    isCustomAvatar: true
  },
  { 
    name: 'Minh Tuấn (Hà Nội)', 
    action: 'vừa đấu giá thành công 8.900.000đ', 
    item: 'CSM Decadriver Ver.2 Gold Plate', 
    time: '3 phút trước', 
    avatar: generateCustomerAvatarSvgUrl({ maskId: 'decade-king', colorId: 'gold-bandai', initials: 'MT' }),
    badge: 'COLLECTOR',
    badgeColor: 'bg-[#00f5d4] text-slate-950',
    isCustomAvatar: true
  },
  { 
    name: 'Quốc Bảo (Đà Nẵng)', 
    action: 'vừa thanh toán đơn hàng hỏa tốc', 
    item: 'Combo DX Desire Driver + Magnum Shooter', 
    time: '5 phút trước', 
    avatar: generateCustomerAvatarSvgUrl({ maskId: 'geats-fox', colorId: 'crimson-ruby', initials: 'QB' }),
    badge: 'RIDER VIP',
    badgeColor: 'bg-cyan-500 text-slate-950',
    isCustomAvatar: true
  },
  { 
    name: 'Tấn Phát (Cần Thơ)', 
    action: 'vừa kích hoạt e-Warranty bảo hành', 
    item: 'CSM Kaixa Driver Complete Set', 
    time: '8 phút trước', 
    avatar: generateCustomerAvatarSvgUrl({ maskId: 'saber-dragon', colorId: 'dark-purple', initials: 'TP' }),
    badge: 'MEMBER',
    badgeColor: 'bg-blue-600 text-white',
    isCustomAvatar: true
  },
  { 
    name: 'Đăng Khoa (Hải Phòng)', 
    action: 'vừa đặt mua thành công', 
    item: 'SHF Kamen Rider Gavv Caking Form', 
    time: '12 phút trước', 
    avatar: generateCustomerAvatarSvgUrl({ maskId: 'zero-one', colorId: 'cyber-cyan', initials: 'ĐK' }),
    badge: 'COLLECTOR',
    badgeColor: 'bg-[#00f5d4] text-slate-950',
    isCustomAvatar: true
  }
];

export const CommunityTicker: React.FC<CommunityTickerProps> = ({ latestOrder }) => {
  const [activities, setActivities] = useState<ActivityItem[]>(DEFAULT_ACTIVITIES);
  const [currentIndex, setCurrentIndex] = useState(0);
  const [visible, setVisible] = useState(true);

  // When a new order is completed by the customer, prepend it to the live ticker
  useEffect(() => {
    if (latestOrder) {
      const newActivity: ActivityItem = {
        name: `${latestOrder.customerName}`,
        action: 'vừa đặt mua thành công',
        item: latestOrder.items[0]?.productName || 'Mô hình Kamen Rider',
        time: 'Vừa xong',
        avatar: latestOrder.customerAvatar || generateCustomerAvatarSvgUrl({
          maskId: 'geats-fox',
          colorId: 'crimson-ruby',
          initials: latestOrder.customerName.slice(0, 2).toUpperCase(),
          customerName: latestOrder.customerName
        }),
        badge: 'RIDER VIP',
        badgeColor: 'bg-gradient-to-r from-cyan-400 to-[#00f5d4] text-slate-950',
        isCustomAvatar: true
      };
      setActivities(prev => [newActivity, ...prev]);
      setCurrentIndex(0);
      setVisible(true);
    }
  }, [latestOrder]);

  useEffect(() => {
    const timer = setInterval(() => {
      setVisible(false);
      setTimeout(() => {
        setCurrentIndex((prev) => (prev + 1) % activities.length);
        setVisible(true);
      }, 500);
    }, 8500);

    return () => clearInterval(timer);
  }, [activities.length]);

  const current = activities[currentIndex] || activities[0];

  if (!visible || !current) return null;

  return (
    <div className="fixed bottom-20 left-4 z-40 hidden sm:block animate-fadeIn pointer-events-none">
      <div className="bg-[#080e1e]/95 border-2 border-cyan-500/50 backdrop-blur-md rounded-2xl p-2.5 shadow-2xl shadow-cyan-950/60 flex items-center gap-3 max-w-md pointer-events-auto ring-1 ring-cyan-400/30">
        
        {/* Customer Avatar with tight-fit cyan border */}
        <div className="w-12 h-12 rounded-xl border-2 border-cyan-400 overflow-hidden shrink-0 bg-black relative p-0.5 shadow-md shadow-cyan-500/30">
          <img 
            src={current.avatar} 
            alt={current.name} 
            className="w-full h-full object-cover rounded-[10px]"
            onError={(e) => {
              e.currentTarget.src = '/BIỂU TƯỢNG DANH MỤC SẢN PHẨM/dlyjpm8-ea90294c-de09-4bc2-8718-6b49acbf082e.png';
            }}
          />
          <span className={`absolute bottom-0 right-0 text-[6px] font-black px-1 rounded-tl uppercase ${current.badgeColor}`}>
            {current.badge}
          </span>
        </div>

        <div className="text-[11px] leading-tight min-w-0 flex-grow space-y-0.5">
          <p className="text-slate-200 font-medium truncate flex items-center gap-1.5">
            <strong className="text-white font-bold">{current.name}</strong> 
            <span className="text-cyan-300 font-semibold">{current.action}</span>
          </p>
          <p className="text-[#00f5d4] font-bold truncate">{current.item}</p>
          <span className="text-[9px] text-slate-300 font-mono flex items-center gap-1">
            <i className="fa-solid fa-circle-check text-cyan-400 text-[8px]"></i>
            <span className="text-cyan-300/90 font-bold">Khách hàng xác thực</span>
            <span>• {current.time}</span>
          </span>
        </div>

        <button 
          onClick={() => setVisible(false)}
          className="text-slate-400 hover:text-white text-xs ml-auto shrink-0 p-1 cursor-pointer"
          title="Ẩn thông báo"
        >
          <i className="fa-solid fa-xmark"></i>
        </button>
      </div>
    </div>
  );
};
