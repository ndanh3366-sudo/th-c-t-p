import React, { useState } from 'react';

interface FooterProps {
  setActiveTab: (tab: string) => void;
  showToast: (msg: string, type?: 'success' | 'error' | 'info') => void;
}

export const Footer: React.FC<FooterProps> = ({ setActiveTab, showToast }) => {
  const [newsletterEmail, setNewsletterEmail] = useState('');

  const handleNewsletterSubmit = (e: React.FormEvent) => {
    e.preventDefault();
    if (!newsletterEmail.trim()) return;
    showToast(`🎉 Đã đăng ký nhận bản tin ưu đãi Kamen Rider cho email: ${newsletterEmail}`, 'success');
    setNewsletterEmail('');
  };

  return (
    <footer className="bg-gradient-to-b from-[#060b1b] via-[#091228] to-[#040710] border-t border-cyan-500/30 text-slate-300 text-xs mt-16 pt-10 pb-20 md:pb-10">
      {/* Top Newsletter Bar */}
      <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 mb-10">
        <div className="bg-gradient-to-r from-[#0d1733] via-[#101e42] to-[#0d1733] border border-cyan-500/40 rounded-3xl p-6 sm:p-7 flex flex-col lg:flex-row items-center justify-between gap-6 shadow-xl">
          <div className="space-y-1 text-center lg:text-left">
            <h3 className="font-serif-title text-lg sm:text-xl font-bold text-white text-pop">
              Đăng Ký Nhận Tin <span className="aqua-gradient-text">RIDER EXCLUSIVE</span>
            </h3>
            <p className="text-xs text-slate-300 max-w-lg">
              Nhận ngay thông báo đai CSM đặt trước, sự kiện Flash Sale và tặng 100 Rider Points khi tạo tài khoản mới.
            </p>
          </div>

          <form onSubmit={handleNewsletterSubmit} className="flex items-center gap-2 w-full lg:w-auto max-w-md">
            <input 
              type="email"
              required
              value={newsletterEmail}
              onChange={(e) => setNewsletterEmail(e.target.value)}
              placeholder="Nhập email của bạn..."
              className="w-full bg-[#080e22] border border-cyan-500/40 focus:border-cyan-300 rounded-xl px-4 py-2.5 text-xs text-white focus:outline-none placeholder-slate-400 font-medium"
            />
            <button 
              type="submit"
              className="px-5 py-2.5 bg-gradient-to-r from-cyan-400 to-blue-500 hover:from-cyan-300 hover:to-blue-400 text-black font-extrabold rounded-xl transition duration-200 whitespace-nowrap shadow-md shadow-cyan-500/20"
            >
              Đăng Ký
            </button>
          </form>
        </div>
      </div>

      {/* Main Grid */}
      <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 grid grid-cols-1 md:grid-cols-2 lg:grid-cols-4 gap-8 pb-12 border-b border-cyan-500/20">
        {/* Brand Info */}
        <div className="space-y-4">
          <div className="flex items-center gap-3">
            <div className="w-12 h-12 rounded-xl bg-[#080f24] border-2 border-cyan-400 p-1 logo-container-glow overflow-hidden shadow-xl">
              <div className="w-full h-full bg-[#050914] rounded-[10px] flex items-center justify-center p-0.5">
                <img 
                  src="/Logo & Thương Hiệu (Brand Logo)/dreamina-2026-07-29-3008-A minimalist stencil-style logo of an oc....png" 
                  alt="NPTTEAMSTORE Official Logo" 
                  className="w-full h-full object-contain logo-chroma-pulse"
                  onError={(e) => {
                    e.currentTarget.style.display = 'none';
                  }}
                />
              </div>
            </div>
            <div>
              <h4 className="font-serif-title text-xl font-black tracking-wider text-white uppercase text-pop">
                NPTTEAM<span className="aqua-gradient-text">STORE</span>
              </h4>
              <p className="text-[10px] text-cyan-300 tracking-wider uppercase font-extrabold">昭和 · 平成 · 令和 · Bandai Official</p>
            </div>
          </div>
          <p className="text-xs text-slate-300 leading-relaxed font-medium">
            Nơi lưu giữ ký ức tuổi thơ & ngọn lửa đam mê Kamen Rider qua 4 kỷ nguyên Showa - Heisei - Reiwa. Cam kết 100% New Seal chính hãng Bandai Japan, bảo hành 1-đổi-1 toàn quốc.
          </p>

          {/* 4 Official Social & Ecommerce Platform Badges */}
          <div className="space-y-2 pt-2">
            <p className="text-[10px] text-gray-400 font-bold uppercase tracking-wider">Kênh Truyền Thông & Gian Hàng:</p>
            <div className="grid grid-cols-2 gap-2">
              <a 
                href="https://facebook.com" 
                target="_blank" 
                rel="noreferrer" 
                className="flex items-center gap-2 px-3 py-2 rounded-xl bg-[#1877F2]/10 border border-[#1877F2]/40 hover:bg-[#1877F2] text-[#1877F2] hover:text-white transition duration-200 group"
              >
                <i className="fa-brands fa-facebook text-base group-hover:scale-110 transition-transform"></i>
                <span className="text-[11px] font-bold">Facebook</span>
              </a>

              <a 
                href="https://youtube.com" 
                target="_blank" 
                rel="noreferrer" 
                className="flex items-center gap-2 px-3 py-2 rounded-xl bg-[#FF0000]/10 border border-[#FF0000]/40 hover:bg-[#FF0000] text-[#FF0000] hover:text-white transition duration-200 group"
              >
                <i className="fa-brands fa-youtube text-base group-hover:scale-110 transition-transform"></i>
                <span className="text-[11px] font-bold">YouTube</span>
              </a>

              <a 
                href="https://discord.com" 
                target="_blank" 
                rel="noreferrer" 
                className="flex items-center gap-2 px-3 py-2 rounded-xl bg-[#5865F2]/10 border border-[#5865F2]/40 hover:bg-[#5865F2] text-[#5865F2] hover:text-white transition duration-200 group"
              >
                <i className="fa-brands fa-discord text-base group-hover:scale-110 transition-transform"></i>
                <span className="text-[11px] font-bold">Discord</span>
              </a>

              <a 
                href="https://shopee.vn" 
                target="_blank" 
                rel="noreferrer" 
                className="flex items-center gap-2 px-3 py-2 rounded-xl bg-[#EE4D2D]/10 border border-[#EE4D2D]/40 hover:bg-[#EE4D2D] text-[#EE4D2D] hover:text-white transition duration-200 group"
              >
                <i className="fa-solid fa-bag-shopping text-base group-hover:scale-110 transition-transform"></i>
                <span className="text-[11px] font-bold">Shopee</span>
              </a>
            </div>
          </div>
        </div>

        {/* Quick Links */}
        <div className="space-y-3">
          <h4 className="font-bold text-slate-100 uppercase tracking-wider text-xs border-l-2 border-cyan-400 pl-2.5">
            Danh Mục Chính
          </h4>
          <ul className="space-y-2 text-xs">
            <li><button onClick={() => setActiveTab('shop')} className="hover:text-cyan-300 transition">Đai biến hình DX Henshin Belt</button></li>
            <li><button onClick={() => setActiveTab('shop')} className="hover:text-cyan-300 transition">Dòng CSM Complete Selection</button></li>
            <li><button onClick={() => setActiveTab('shop')} className="hover:text-cyan-300 transition">Mô hình S.H.Figuarts (SHF)</button></li>
            <li><button onClick={() => setActiveTab('shop')} className="hover:text-cyan-300 transition">Vũ khí & Ride Chemy Cards</button></li>
            <li><button onClick={() => setActiveTab('auction')} className="hover:text-cyan-300 transition">Đấu giá hàng hiếm (Collector Auction)</button></li>
            <li><button onClick={() => setActiveTab('quiz')} className="hover:text-cyan-300 transition">Trắc nghiệm: Bạn là Kamen Rider nào?</button></li>
          </ul>
        </div>

        {/* Support & Policies */}
        <div className="space-y-3">
          <h4 className="font-bold text-slate-100 uppercase tracking-wider text-xs border-l-2 border-cyan-400 pl-2.5">
            Chính Sách & Hỗ Trợ
          </h4>
          <ul className="space-y-2 text-xs">
            <li><button onClick={() => setActiveTab('warranty')} className="hover:text-cyan-300 transition">Chính sách bảo hành 1-đổi-1</button></li>
            <li><button onClick={() => setActiveTab('warranty')} className="hover:text-cyan-300 transition">Hướng dẫn bảo quản mạch loa DX/CSM</button></li>
            <li><button onClick={() => setActiveTab('promotions')} className="hover:text-cyan-300 transition">Chương trình tích điểm Rider Points</button></li>
            <li><button onClick={() => setActiveTab('contact')} className="hover:text-cyan-300 transition">Gửi Ticket hỗ trợ kỹ thuật</button></li>
            <li><button onClick={() => setActiveTab('about')} className="hover:text-cyan-300 transition">Quy trình kiểm định hàng Bandai</button></li>
          </ul>
        </div>

        {/* Store Showrooms with Showroom Photo */}
        <div className="space-y-3">
          <h4 className="font-bold text-white uppercase tracking-wider text-xs border-l-2 border-cyan-400 pl-2.5 text-pop">
            Hệ Thống Showroom NPTTEAMSTORE
          </h4>
          <div className="space-y-2.5 text-xs text-slate-300 font-medium">
            <div className="w-full h-24 rounded-xl overflow-hidden border border-cyan-500/40 shadow-md relative group">
              <img 
                src="/Ảnh Showroom & Cửa Hàng/20240708_161850.jpg" 
                alt="Showroom NPTTEAMSTORE Trưng Bày Tokusatsu" 
                className="w-full h-full object-cover group-hover:scale-105 transition duration-500"
              />
              <div className="absolute inset-0 bg-gradient-to-t from-black/80 via-transparent to-transparent flex items-end p-2">
                <span className="text-[10px] font-bold text-cyan-300 flex items-center gap-1">
                  <i className="fa-solid fa-store text-cyan-400"></i> Showroom Trưng Bày Đai & Mô Hình
                </span>
              </div>
            </div>
            <p><i className="fa-solid fa-location-dot text-cyan-400 mr-2"></i><strong>TP.HCM:</strong> 158 Nguyễn Trãi, Quận 1</p>
            <p><i className="fa-solid fa-location-dot text-cyan-400 mr-2"></i><strong>Hà Nội:</strong> 88 Chùa Bộc, Đống Đa</p>
            <p><i className="fa-solid fa-phone text-cyan-400 mr-2"></i>Hotline: <strong className="text-white">1900 8888</strong></p>
            <p><i className="fa-solid fa-clock text-cyan-400 mr-2"></i>Mở cửa: 08:30 - 21:30</p>
          </div>
        </div>
      </div>

      {/* Bottom Copyright & Author Credit */}
      <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 pt-8 flex flex-col md:flex-row items-center justify-between gap-4 text-[11px] text-slate-300">
        <div className="space-y-1 text-center md:text-left">
          <p className="text-slate-200 font-medium">
            &copy; 2026 NPTTEAMSTORE - Kamen Rider Official Store Japan. Bản quyền thuộc về <strong className="text-cyan-300 font-bold">Team NPT</strong>.
          </p>
          <p className="text-[10px] text-slate-400">
            Hệ thống phân phối đai biến hình DX, CSM & mô hình S.H.Figuarts chính hãng Bandai tại Việt Nam.
          </p>
        </div>
        <div className="flex flex-wrap items-center justify-center gap-2">
          <span className="bg-cyan-500/10 border border-cyan-400/50 px-3 py-1 rounded-xl text-cyan-200 font-bold text-[10px] shadow-sm flex items-center gap-1.5">
            <i className="fa-solid fa-crown text-cyan-300"></i> Trưởng nhóm: Đoàn Tiến Đạt
          </span>
          <span className="bg-cyan-500/10 border border-cyan-400/50 px-3 py-1 rounded-xl text-cyan-200 font-bold text-[10px] shadow-sm flex items-center gap-1.5">
            <i className="fa-solid fa-shield text-cyan-300"></i> Phó nhóm: Vũ Tạ Hữu Luân
          </span>
          <span className="bg-slate-800/80 border border-cyan-500/30 px-3 py-1 rounded-xl text-slate-300 font-bold text-[10px] shadow-sm flex items-center gap-1.5">
            <i className="fa-solid fa-users text-cyan-400"></i> Ban Quản Trị: Team NPT
          </span>
          <span className="bg-[#0b142c] border border-cyan-500/30 px-2.5 py-1 rounded-lg text-slate-200 font-bold"><i className="fa-solid fa-building-columns text-cyan-400 mr-1"></i> Chuyển Khoản</span>
          <span className="bg-[#0b142c] border border-cyan-500/30 px-2.5 py-1 rounded-lg text-slate-200 font-bold"><i className="fa-solid fa-credit-card text-cyan-400 mr-1"></i> VNPay</span>
        </div>
      </div>
    </footer>
  );
};
