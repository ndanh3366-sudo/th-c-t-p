import React, { useState } from 'react';
import { Product, User } from '../types';
import { PWAInstallButton } from './PWAInstallButton';

interface HeaderProps {
  activeTab: string;
  setActiveTab: (tab: string) => void;
  cartCount: number;
  openCart?: () => void;
  onOpenCart?: () => void;
  currentUser: User | null;
  openAuth?: (mode?: 'login' | 'register') => void;
  onOpenAuth?: (mode?: 'login' | 'register') => void;
  openProfile?: () => void;
  onOpenProfile?: () => void;
  openAdmin?: () => void;
  onOpenAdmin?: () => void;
  onLogout: () => void;
  products: Product[];
  onSelectProduct: (p: Product) => void;
  onOpenWheel?: () => void;
  onOpenCompare?: () => void;
  compareCount?: number;
  onOpenWishlist?: () => void;
  wishlistCount?: number;
  onOpenAbout?: () => void;
  onOpenTribute?: () => void;
  isAdminAuthenticated?: boolean;
}

export const Header: React.FC<HeaderProps> = ({
  activeTab,
  setActiveTab,
  cartCount,
  openCart,
  onOpenCart,
  currentUser,
  openAuth,
  onOpenAuth,
  openProfile,
  onOpenProfile,
  openAdmin,
  onOpenAdmin,
  onLogout,
  products,
  onSelectProduct,
  onOpenWheel,
  onOpenCompare,
  compareCount = 0,
  onOpenWishlist,
  wishlistCount = 0,
  onOpenAbout,
  onOpenTribute,
  isAdminAuthenticated = false
}) => {
  const handleOpenCart = openCart || onOpenCart || (() => {});
  const handleOpenAuth = openAuth || onOpenAuth || (() => {});
  const handleOpenProfile = openProfile || onOpenProfile || (() => {});
  const handleOpenAdmin = openAdmin || onOpenAdmin || (() => {});
  const [searchQuery, setSearchQuery] = useState('');
  const [showSuggestions, setShowSuggestions] = useState(false);
  const [userDropdownOpen, setUserDropdownOpen] = useState(false);

  const filteredProducts = searchQuery.trim()
    ? products.filter(p => p.name.toLowerCase().includes(searchQuery.toLowerCase()) || p.series.toLowerCase().includes(searchQuery.toLowerCase())).slice(0, 6)
    : [];

  const navLinks = [
    { id: 'home', label: 'Trang Chủ', icon: 'fa-house' },
    { id: 'live', label: 'Live Bán Hàng', icon: 'fa-video', badge: 'LIVE', livePulse: true },
    { id: 'about', label: 'Giới Thiệu Web', icon: 'fa-circle-info', highlight: true },
    { id: 'shop', label: 'Sản Phẩm', icon: 'fa-gamepad' },
    { id: 'promotions', label: 'Khuyến Mãi', icon: 'fa-tags' },
    { id: 'auction', label: 'Đấu Giá', icon: 'fa-gavel', badge: 'HOT' },
    { id: 'tracker', label: 'Tra Cứu Đơn', icon: 'fa-truck-ramp-box' },
    { id: 'quiz', label: 'Quiz Rider', icon: 'fa-wand-magic-sparkles' },
    { id: 'warranty', label: 'Bảo Hành', icon: 'fa-shield-halved' },
    { id: 'blog', label: 'Tin Tức', icon: 'fa-newspaper' },
    { id: 'forum', label: 'Cộng Đồng', icon: 'fa-users', badge: 'Khoe Hàng' },
  ];

  return (
    <header className="sticky top-0 z-40 bg-gradient-to-r from-[#060b1b]/98 via-[#0a132c]/98 to-[#060b1b]/98 backdrop-blur-xl border-b border-cyan-500/35 shadow-xl shadow-black/50">
      {/* Announcement & Portal Switcher Bar */}
      <div className="bg-[#070d1e]/95 border-b border-cyan-500/20 text-xs py-1.5 px-4 text-slate-200">
        <div className="max-w-7xl mx-auto flex flex-wrap items-center justify-between gap-2">
          
          {/* Dual Portal Switcher: Web Khách vs Web Quản Lý */}
          <div className="flex items-center gap-2">
            <button
              onClick={() => setActiveTab('home')}
              className="bg-cyan-500/20 hover:bg-cyan-500/30 text-cyan-300 border border-cyan-400/50 font-bold px-2.5 py-0.5 rounded-full text-[11px] uppercase tracking-wider shadow-sm flex items-center gap-1.5 cursor-pointer transition"
              title="Giao diện mua sắm dành cho khách hàng"
            >
              <i className="fa-solid fa-store text-cyan-400"></i>
              <span>🛒 CỔNG WEB KHÁCH</span>
            </button>

            <span className="text-slate-600 text-xs">•</span>

            <button
              onClick={handleOpenAdmin}
              className={`font-black px-2.5 py-0.5 rounded-full text-[11px] uppercase tracking-wider shadow-sm flex items-center gap-1.5 cursor-pointer transition ${
                isAdminAuthenticated
                  ? 'bg-amber-500/20 text-amber-300 border border-amber-400/60 shadow-[0_0_10px_rgba(245,158,11,0.2)]'
                  : 'bg-rose-950/70 hover:bg-rose-900/80 text-rose-300 border border-rose-500/40'
              }`}
              title="Cổng quản lý cửa hàng (Yêu cầu tài khoản Danh Nguyễn)"
            >
              <i className={`fa-solid ${isAdminAuthenticated ? 'fa-crown text-amber-400' : 'fa-lock text-rose-400'}`}></i>
              <span>{isAdminAuthenticated ? '👑 WEB QUẢN LÝ (DANH NGUYỄN)' : '🔐 CỔNG WEB QUẢN LÝ'}</span>
            </button>
          </div>

          <div className="flex items-center gap-3 text-xs text-slate-300">
            <span className="hidden sm:inline font-medium text-slate-300">
              <i className="fa-solid fa-shield-halved text-cyan-400 mr-1"></i>Chính Hãng Bandai Japan
            </span>
            <span className="hidden md:inline font-medium text-slate-300">
              <i className="fa-solid fa-truck-fast text-emerald-400 mr-1"></i>Freeship từ 1.5M
            </span>
            <PWAInstallButton variant="header" />
          </div>
        </div>
      </div>

      {/* Main Top Header */}
      <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 py-3 flex items-center justify-between gap-4">
        {/* Brand Logo with LG1 Logo Image */}
        <div 
          onClick={() => {
            if (onOpenTribute) {
              onOpenTribute();
            } else {
              setActiveTab('home');
            }
          }}
          className="flex items-center gap-3 cursor-pointer group select-none"
          title="✨ Nhấp vào logo để mở Trang Tri Ân Team NPT!"
        >
          <div className="w-11 h-11 rounded-xl bg-[#080f24] border-2 border-cyan-400 p-1 logo-container-glow group-hover:scale-110 transition-all duration-300 overflow-hidden flex items-center justify-center relative">
            <div className="w-full h-full bg-[#050914] rounded-[10px] flex items-center justify-center overflow-hidden p-0.5">
              <img 
                src="/Logo & Thương Hiệu (Brand Logo)/dreamina-2026-07-29-3008-A minimalist stencil-style logo of an oc....png" 
                alt="NPTTEAMSTORE Official Logo" 
                className="w-full h-full object-contain logo-chroma-pulse group-hover:rotate-12 transition-transform duration-300"
                onError={(e) => {
                  e.currentTarget.style.display = 'none';
                }}
              />
            </div>
          </div>
          <div>
            <div className="flex items-center gap-1.5">
              <h1 className="font-serif-title text-2xl md:text-3xl font-black tracking-wider text-white uppercase text-pop group-hover:text-cyan-300 transition-colors">
                NPTTEAM<span className="aqua-gradient-text">STORE</span>
              </h1>
            </div>
            <p className="text-[10px] text-cyan-300 tracking-wider uppercase font-extrabold flex items-center gap-1.5">
              <span>昭和 · 平成 · 令和 · Bandai Japan Official</span>
              <span className="text-[9px] text-cyan-400 animate-pulse">⚡</span>
            </p>
          </div>
        </div>

        {/* Live Search Bar */}
        <div className="flex-grow max-w-md hidden sm:block relative">
          <div className="relative">
            <input 
              type="text"
              value={searchQuery}
              onChange={(e) => {
                setSearchQuery(e.target.value);
                setShowSuggestions(true);
              }}
              onFocus={() => setShowSuggestions(true)}
              placeholder="Tìm DX Henshin Belt, CSM, S.H.Figuarts, Raise Buckle..."
              className="w-full bg-[#10141d] border border-cyan-500/30 focus:border-cyan-400 rounded-full py-2 pl-10 pr-4 text-xs text-[#F5F2EB] placeholder-gray-400 focus:outline-none focus:ring-1 focus:ring-cyan-400 transition duration-200"
            />
            <i className="fa-solid fa-magnifying-glass absolute left-3.5 top-1/2 -translate-y-1/2 text-cyan-400/70 text-xs"></i>
            {searchQuery && (
              <button 
                onClick={() => setSearchQuery('')}
                className="absolute right-3 top-1/2 -translate-y-1/2 text-gray-400 hover:text-white text-xs"
              >
                <i className="fa-solid fa-xmark"></i>
              </button>
            )}
          </div>

          {/* Instant Search Suggestions Popup */}
          {showSuggestions && filteredProducts.length > 0 && (
            <div className="absolute top-full left-0 right-0 mt-2 bg-[#10141d] border border-cyan-500/40 rounded-2xl shadow-2xl overflow-hidden z-50 divide-y divide-slate-800">
              <div className="px-4 py-2 text-[10px] uppercase font-bold text-cyan-300">Gợi ý sản phẩm ({filteredProducts.length})</div>
              {filteredProducts.map(p => (
                <div 
                  key={p.id}
                  onClick={() => {
                    onSelectProduct(p);
                    setShowSuggestions(false);
                    setSearchQuery('');
                  }}
                  className="flex items-center gap-3 p-3 hover:bg-[#181f2c] cursor-pointer transition"
                >
                  <img src={p.images[0]} alt={p.name} className="w-10 h-10 object-cover rounded-lg bg-[#090b10] border border-cyan-500/30" onError={(e) => { e.currentTarget.src = '/Ảnh Sản Phẩm/dx/Kamen Rider Zeztz DX Henshin Belt Lord Invoker1.jpg'; }} />
                  <div className="flex-grow min-w-0">
                    <h4 className="text-xs font-bold text-[#F5F2EB] truncate">{p.name}</h4>
                    <p className="text-[10px] text-gray-400">{p.series} • <span className="text-cyan-400 font-bold">{p.price.toLocaleString('vi-VN')}đ</span></p>
                  </div>
                </div>
              ))}
            </div>
          )}
        </div>

        {/* Right Actions: Cart & User Account */}
        <div className="flex items-center gap-2.5">
          {/* User Rider Points (If logged in) */}
          {currentUser && (
            <div 
              onClick={() => setActiveTab('dashboard')}
              className="hidden lg:flex items-center gap-1.5 bg-[#10141d] border border-cyan-500/40 px-3 py-1.5 rounded-full text-xs cursor-pointer hover:border-cyan-400 transition"
            >
              <i className="fa-solid fa-coins text-cyan-400"></i>
              <span className="text-gray-400 text-[11px]">Points:</span>
              <strong className="text-cyan-300 font-bold">{currentUser.riderPoints}</strong>
            </div>
          )}

          {/* Lucky Wheel Button */}
          {onOpenWheel && (
            <button
              onClick={onOpenWheel}
              className="relative w-9 h-9 sm:w-10 sm:h-10 rounded-xl bg-[#10141d] border border-cyan-500/40 text-cyan-400 flex items-center justify-center transition hover:border-cyan-300 hover:scale-105 shadow-sm shadow-cyan-500/10"
              title="Vòng Quay May Mắn Rider"
            >
              <i className="fa-solid fa-arrows-spin text-sm animate-spin" style={{ animationDuration: '8s' }}></i>
            </button>
          )}

          {/* Compare Button */}
          {onOpenCompare && (
            <button
              onClick={onOpenCompare}
              className="relative w-9 h-9 sm:w-10 sm:h-10 rounded-xl bg-[#10141d] border border-cyan-500/40 hover:border-cyan-300 text-[#F5F2EB] flex items-center justify-center transition scale-hover"
              title="So sánh sản phẩm"
            >
              <i className="fa-solid fa-code-compare text-sm text-cyan-400"></i>
              {compareCount > 0 && (
                <span className="absolute -top-1.5 -right-1.5 bg-cyan-500 text-black text-[10px] font-black w-4.5 h-4.5 rounded-full flex items-center justify-center border border-[#0A0A0A]">
                  {compareCount}
                </span>
              )}
            </button>
          )}

          {/* Wishlist Button */}
          {onOpenWishlist && (
            <button
              onClick={onOpenWishlist}
              className="relative w-9 h-9 sm:w-10 sm:h-10 rounded-xl bg-[#10141d] border border-cyan-500/40 hover:border-rose-500 text-[#F5F2EB] flex items-center justify-center transition scale-hover"
              title="Danh sách yêu thích"
            >
              <i className="fa-solid fa-heart text-sm text-rose-500"></i>
              {wishlistCount > 0 && (
                <span className="absolute -top-1.5 -right-1.5 bg-rose-600 text-white text-[10px] font-black w-4.5 h-4.5 rounded-full flex items-center justify-center border border-[#0A0A0A] animate-pulse">
                  {wishlistCount}
                </span>
              )}
            </button>
          )}

          {/* Cart Icon Button */}
          <button 
            onClick={handleOpenCart}
            className="relative w-9 h-9 sm:w-10 sm:h-10 rounded-xl bg-[#10141d] border border-cyan-500/40 hover:border-cyan-300 text-[#F5F2EB] flex items-center justify-center transition scale-hover"
            title="Giỏ hàng"
          >
            <i className="fa-solid fa-bag-shopping text-sm text-cyan-400"></i>
            {cartCount > 0 && (
              <span className="absolute -top-1.5 -right-1.5 bg-rose-600 text-white text-[10px] font-black w-4.5 h-4.5 rounded-full flex items-center justify-center border border-[#0A0A0A] animate-pulse">
                {cartCount}
              </span>
            )}
          </button>

          {/* User Profile / Auth Button */}
          <div className="relative">
            {currentUser ? (
              <button 
                onClick={() => setUserDropdownOpen(!userDropdownOpen)}
                className="flex items-center gap-2 bg-[#1A1A1A] hover:bg-[#222222] border border-[#2A2A2A] hover:border-[#C9A84C] px-3 py-1.5 rounded-xl transition"
              >
                <div className="w-6 h-6 rounded-full bg-gradient-to-br from-[#C9A84C] to-[#8B1E1E] flex items-center justify-center text-[#0A0A0A] font-bold text-xs">
                  {currentUser.name.charAt(0).toUpperCase()}
                </div>
                <span className="text-xs font-bold text-[#F5F2EB] hidden md:inline max-w-[100px] truncate">{currentUser.name}</span>
                <i className="fa-solid fa-chevron-down text-[10px] text-gray-400"></i>
              </button>
            ) : (
              <button 
                onClick={() => handleOpenAuth('login')}
                className="flex items-center gap-2 bg-gradient-to-r from-[#C9A84C] to-[#a27e2a] text-[#0A0A0A] font-extrabold px-3.5 py-2 rounded-xl text-xs hover:brightness-110 transition shadow-md shadow-[#C9A84C]/10"
              >
                <i className="fa-solid fa-user"></i>
                <span className="hidden sm:inline">Đăng Nhập</span>
              </button>
            )}

            {/* User Dropdown */}
            {userDropdownOpen && currentUser && (
              <div 
                onMouseLeave={() => setUserDropdownOpen(false)}
                className="absolute right-0 mt-2 w-56 bg-[#1A1A1A] border border-[#2A2A2A] rounded-2xl shadow-2xl p-2 z-50 text-xs text-[#F5F2EB] divide-y divide-[#2A2A2A]"
              >
                <div className="p-3">
                  <p className="font-bold text-[#F5F2EB] truncate">{currentUser.name}</p>
                  <p className="text-[10px] text-gray-400 truncate">{currentUser.email}</p>
                  <div className="mt-2 inline-block px-2 py-0.5 rounded bg-[#C9A84C]/10 border border-[#C9A84C]/30 text-[#C9A84C] text-[10px] font-bold">
                    {currentUser.tierRank}
                  </div>
                </div>

                <div className="py-1">
                  <button 
                    onClick={() => { setActiveTab('dashboard'); setUserDropdownOpen(false); }}
                    className="w-full text-left px-3 py-2 rounded-lg hover:bg-[#222222] transition flex items-center gap-2 text-gray-300 hover:text-white"
                  >
                    <i className="fa-solid fa-gauge text-[#C9A84C]"></i> Dashboard & Đơn hàng
                  </button>
                  <button 
                    onClick={() => { handleOpenProfile(); setUserDropdownOpen(false); }}
                    className="w-full text-left px-3 py-2 rounded-lg hover:bg-[#222222] transition flex items-center gap-2 text-gray-300 hover:text-white"
                  >
                    <i className="fa-solid fa-user-gear text-[#C9A84C]"></i> Cài đặt tài khoản
                  </button>
                  {currentUser.role === 'admin' && (
                    <button 
                      onClick={() => { handleOpenAdmin(); setUserDropdownOpen(false); }}
                      className="w-full text-left px-3 py-2 rounded-lg hover:bg-[#8B1E1E]/20 transition flex items-center gap-2 text-rose-400 font-bold"
                    >
                      <i className="fa-solid fa-shield-halved text-rose-500"></i> Quản Lý Admin
                    </button>
                  )}
                </div>

                <div className="pt-1">
                  <button 
                    onClick={() => { onLogout(); setUserDropdownOpen(false); }}
                    className="w-full text-left px-3 py-2 rounded-lg hover:bg-rose-900/20 text-rose-400 hover:text-rose-300 transition flex items-center gap-2 font-medium"
                  >
                    <i className="fa-solid fa-right-from-bracket"></i> Đăng xuất
                  </button>
                </div>
              </div>
            )}
          </div>
        </div>
      </div>

      {/* Navigation Links Ribbon */}
      <nav className="border-t border-cyan-500/20 bg-[#08090d] overflow-x-auto no-scrollbar">
        <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 flex items-center gap-1 sm:gap-2 py-2 text-xs font-semibold whitespace-nowrap">
          {navLinks.map((link) => {
            const isActive = activeTab === link.id;
            return (
              <button
                key={link.id}
                onClick={() => {
                  if (link.id === 'about' && onOpenAbout) {
                    onOpenAbout();
                  } else {
                    setActiveTab(link.id);
                  }
                }}
                className={`px-3 py-1.5 rounded-lg transition duration-200 flex items-center gap-1.5 relative ${
                  isActive
                    ? 'bg-cyan-500/20 text-cyan-300 border border-cyan-500/60 shadow-[0_0_12px_rgba(0,255,255,0.2)] font-bold'
                    : 'highlight' in link && link.highlight
                    ? 'bg-cyan-950/30 text-cyan-400 border border-cyan-500/30 hover:bg-cyan-900/30'
                    : 'text-slate-300 hover:text-white hover:bg-slate-800/60'
                }`}
              >
                <i className={`fa-solid ${link.icon} text-[11px] ${isActive ? 'text-cyan-400' : 'text-slate-400'}`}></i>
                <span>{link.label}</span>
                {link.badge && (
                  <span className="bg-red-600 text-white text-[8px] font-black px-1.5 py-0.2 rounded-full uppercase ml-0.5">
                    {link.badge}
                  </span>
                )}
              </button>
            );
          })}
        </div>
      </nav>
    </header>
  );
};
