import React, { useState, useEffect } from 'react';

interface BannerSlide {
  id: string;
  image: string;
  title: string;
  subtitle: string;
  tag: string;
}

export const HeroSlider: React.FC = () => {
  const [currentSlide, setCurrentSlide] = useState(0);

  // Bộ sưu tập ảnh chính thức từ thư mục 'Banner Slider Đầu Trang Chủ (Hero Banner Slider)'
  const bannerSlides: BannerSlide[] = [
    {
      id: 'banner-csm',
      image: '/Banner Slider Đầu Trang Chủ (Hero Banner Slider)/KR_CSM_Banner.webp',
      title: 'SIÊU PHẨM CSM & DX HENSHIN BELT HOÀNG GIA',
      subtitle: 'Đai biến hình Rider huyền thoại Bandai Japan bản quyền - Đỉnh cao sưu tầm Tokusatsu',
      tag: 'CSM & DX EXCLUSIVE'
    },
    {
      id: 'banner-gotchard-gavv',
      image: '/Banner Slider Đầu Trang Chủ (Hero Banner Slider)/km3_20240206150553.jpg',
      title: 'HIỆP SĨ MẶT NẠ - SIÊU PHẨM BANDAI JAPAN',
      subtitle: 'Bộ sưu tập đai biến hình DX & CSM chính hãng đầy đủ các kỉ nguyên Showa, Heisei & Reiwa',
      tag: 'BANNER CHÍNH NPTTEAMSTORE'
    },
    {
      id: 'banner-shf-figurine',
      image: '/Banner Slider Đầu Trang Chủ (Hero Banner Slider)/e094e508-ec72-4168-8a1d-e924fd323829.webp',
      title: 'S.H.FIGUARTS & MÔ HÌNH NGHỆ THUẬT CAO CẤP',
      subtitle: 'Từng chi tiết chế tác tinh xảo - Khớp cử động linh hoạt bản quyền Bandai Japan 100%',
      tag: 'LIMITED EDITION BANDAI'
    },
    {
      id: 'banner-family-tokusatsu',
      image: '/Banner Slider Đầu Trang Chủ (Hero Banner Slider)/hiep-si-mat-na-gia-dinh-sieu-pham-fpt-play-1727665332423_Landscape.jpg',
      title: 'HIỆP SĨ MẶT NẠ GIA ĐÌNH SIÊU PHẨM',
      subtitle: 'Tích điểm thưởng Rider Points - Tham gia Vòng Quay May Mắn & Đấu Giá Hoàng Gia',
      tag: 'PROMOTION & REWARDS'
    }
  ];

  useEffect(() => {
    const timer = setInterval(() => {
      setCurrentSlide((prev) => (prev + 1) % bannerSlides.length);
    }, 4500);
    return () => clearInterval(timer);
  }, [bannerSlides.length]);

  const handleNext = () => {
    setCurrentSlide((prev) => (prev + 1) % bannerSlides.length);
  };

  const handlePrev = () => {
    setCurrentSlide((prev) => (prev - 1 + bannerSlides.length) % bannerSlides.length);
  };

  const current = bannerSlides[currentSlide];

  return (
    <div className="relative w-full rounded-3xl overflow-hidden shadow-2xl border-2 border-cyan-500/40 bg-[#080e1e] group aqua-glossy-card">
      {/* Container Frame - Kéo dài rộng chuẩn khung Banner Hoàng Gia Điện Ảnh */}
      <div className="relative w-full h-[380px] sm:h-[480px] lg:h-[560px] flex items-center justify-center bg-[#040711] nostalgic-scanline">
        
        {/* Ambient Blurred Background */}
        <div className="absolute inset-0 overflow-hidden pointer-events-none">
          <img 
            src={current.image} 
            alt="Ambient blur" 
            className="w-full h-full object-cover filter blur-2xl opacity-35 transform scale-105"
            onError={(e) => {
              e.currentTarget.src = '/Banner Slider Đầu Trang Chủ (Hero Banner Slider)/km3_20240206150553.jpg';
            }}
          />
          <div className="absolute inset-0 bg-gradient-to-t from-[#040711] via-transparent to-[#040711]/70"></div>
        </div>

        {/* Main Banner Image - Stretched/Covered tràn khung vừa vặn sắc nét */}
        <div className="relative z-10 w-full h-full overflow-hidden flex items-center justify-center">
          <img 
            src={current.image} 
            alt={current.title}
            className="w-full h-full object-cover shadow-2xl transition-all duration-700 transform group-hover:scale-105"
            onError={(e) => {
              e.currentTarget.src = '/Banner Slider Đầu Trang Chủ (Hero Banner Slider)/km3_20240206150553.jpg';
            }}
          />
          
          {/* Subtle gradient overlay at bottom for easy text reading */}
          <div className="absolute inset-0 bg-gradient-to-t from-[#040711] via-[#040711]/40 to-transparent pointer-events-none"></div>
        </div>

        {/* Top Floating Tag Overlay - Typography Hoài Niệm & Dễ Nhìn */}
        <div className="absolute top-3.5 left-4 sm:left-6 z-20 flex items-center gap-2">
          <span className="bg-cyan-950/85 backdrop-blur-md text-[#00f5d4] text-[10px] sm:text-xs font-black px-3 py-1 rounded-xl uppercase tracking-widest border border-cyan-400/50 shadow-xl font-serif-title flex items-center gap-1.5">
            <span className="w-1.5 h-1.5 rounded-full bg-[#00f5d4] animate-pulse"></span>
            {current.tag}
          </span>
          <span className="bg-[#050914]/90 backdrop-blur-md text-slate-300 text-[10px] sm:text-xs font-mono font-bold px-3 py-1 rounded-xl border border-cyan-500/30 shadow-md">
            0{currentSlide + 1} / 0{bannerSlides.length}
          </span>
        </div>

        {/* Bottom Banner Title Overlay - Phông chữ to rõ nét, tương phản hoàn hảo, dễ nhìn từ xa */}
        <div className="absolute bottom-4 left-4 sm:left-6 right-16 sm:right-28 z-20 bg-[#060b18]/90 backdrop-blur-md p-4 sm:p-5 rounded-2xl border border-cyan-500/40 shadow-2xl space-y-1">
          <div className="flex items-center gap-2 text-[10px] text-cyan-300 font-mono uppercase tracking-widest">
            <span>BANDAI JAPAN AUTHENTIC</span>
            <span>·</span>
            <span>昭和 · 平成 · 令和</span>
          </div>
          <h3 className="font-serif-title text-base sm:text-xl font-black text-white uppercase tracking-wide leading-tight drop-shadow-md">
            {current.title}
          </h3>
          <p className="text-xs sm:text-sm text-slate-300 font-medium line-clamp-1 leading-normal">
            {current.subtitle}
          </p>
        </div>

        {/* Navigation Arrows */}
        <button 
          onClick={handlePrev}
          className="absolute left-2 sm:left-4 top-1/2 -translate-y-1/2 z-30 w-9 h-9 sm:w-11 sm:h-11 rounded-xl bg-[#060b18]/90 hover:bg-cyan-500 text-cyan-300 hover:text-slate-950 border border-cyan-500/40 flex items-center justify-center transition-all duration-300 shadow-2xl hover:scale-110 active:scale-95 cursor-pointer"
          aria-label="Previous Banner"
        >
          <i className="fa-solid fa-chevron-left text-xs sm:text-base"></i>
        </button>

        <button 
          onClick={handleNext}
          className="absolute right-2 sm:right-4 top-1/2 -translate-y-1/2 z-30 w-9 h-9 sm:w-11 sm:h-11 rounded-xl bg-[#060b18]/90 hover:bg-cyan-500 text-cyan-300 hover:text-slate-950 border border-cyan-500/40 flex items-center justify-center transition-all duration-300 shadow-2xl hover:scale-110 active:scale-95 cursor-pointer"
          aria-label="Next Banner"
        >
          <i className="fa-solid fa-chevron-right text-xs sm:text-base"></i>
        </button>

        {/* Bottom Right Banner Slide Indicators */}
        <div className="absolute bottom-4 right-4 z-20 hidden sm:flex items-center gap-2 bg-[#060b18]/90 backdrop-blur-md px-3 py-1.5 rounded-full border border-cyan-500/30 shadow-lg">
          {bannerSlides.map((_, idx) => (
            <button
              key={idx}
              onClick={() => setCurrentSlide(idx)}
              className={`h-2 rounded-full transition-all duration-300 cursor-pointer ${
                currentSlide === idx 
                  ? 'w-6 bg-gradient-to-r from-[#00f5d4] to-cyan-400' 
                  : 'w-2 bg-slate-700 hover:bg-slate-500'
              }`}
              aria-label={`Slide ${idx + 1}`}
            />
          ))}
        </div>
      </div>
    </div>
  );
};
