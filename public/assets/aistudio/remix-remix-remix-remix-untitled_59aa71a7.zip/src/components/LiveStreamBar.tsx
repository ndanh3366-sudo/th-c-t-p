import React from 'react';
import { Product } from '../types';

interface LiveStreamBarProps {
  products: Product[];
  onSelectProduct: (product: Product) => void;
  onOpenLive?: () => void;
}

export const LiveStreamBar: React.FC<LiveStreamBarProps> = ({ 
  products, 
  onSelectProduct,
  onOpenLive 
}) => {
  const featuredProduct = products[0];

  return (
    <section className="bg-gradient-to-r from-[#070e22] via-[#0b173b] to-[#070e22] border-b border-cyan-500/35 text-slate-100 relative z-30 shadow-lg">
      <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 py-3 flex flex-wrap items-center justify-between gap-4">
        
        {/* Left: Pulsing Live Indicator & Title */}
        <div className="flex items-center gap-3 min-w-0">
          <span className="relative flex h-3.5 w-3.5 shrink-0">
            <span className="animate-ping absolute inline-flex h-full w-full rounded-full bg-rose-500 opacity-75"></span>
            <span className="relative inline-flex rounded-full h-3.5 w-3.5 bg-rose-600"></span>
          </span>

          <div className="min-w-0">
            <div className="flex items-center gap-2">
              <span className="bg-rose-600 text-white text-[10px] font-black px-2 py-0.5 rounded uppercase tracking-wider shadow">
                LIVEKIT PRO
              </span>
              <h2 className="font-serif-title text-xs sm:text-sm font-extrabold text-white truncate text-pop uppercase">
                🔴 ĐẠI TIỆC LIVE SHOWCASE KAMEN RIDER GAVV & ĐAI DX/CSM BANDAI JAPAN
              </h2>
            </div>
            <p className="text-[11px] text-cyan-300 font-medium flex items-center gap-2 mt-0.5">
              <span>Chuẩn 1080p 60fps SVC</span>
              <span>•</span>
              <span className="text-amber-400 font-bold">10 Filter AR & Làm Đẹp WebGL</span>
              <span>•</span>
              <span className="text-emerald-400 font-bold">Flash Sale Giảm 15%</span>
            </p>
          </div>
        </div>

        {/* Right: Featured Pin teaser & Enter Room Button */}
        <div className="flex items-center gap-3 shrink-0">
          {featuredProduct && (
            <div 
              onClick={() => onSelectProduct(featuredProduct)}
              className="hidden md:flex items-center gap-2 bg-[#060c1d] border border-cyan-500/30 rounded-xl px-2.5 py-1.5 cursor-pointer hover:border-cyan-400 transition"
              title="Sản phẩm đang được review trực tiếp"
            >
              <img 
                src={featuredProduct.images[0]} 
                alt={featuredProduct.name} 
                className="w-8 h-8 object-contain rounded"
              />
              <div className="text-left text-xs">
                <div className="text-[10px] text-slate-400">Đang Ghim Trên Live:</div>
                <div className="text-amber-400 font-black truncate max-w-[140px]">{featuredProduct.name}</div>
              </div>
            </div>
          )}

          <button
            onClick={onOpenLive}
            className="bg-gradient-to-r from-rose-600 via-rose-500 to-amber-500 hover:brightness-110 text-white font-black text-xs px-4 py-2 rounded-xl transition shadow-[0_0_20px_rgba(244,63,94,0.4)] flex items-center gap-2 cursor-pointer"
          >
            <i className="fa-solid fa-play text-xs animate-pulse"></i>
            <span>VÀO PHÒNG LIVE SẢN PHẨM</span>
          </button>
        </div>
      </div>
    </section>
  );
};
