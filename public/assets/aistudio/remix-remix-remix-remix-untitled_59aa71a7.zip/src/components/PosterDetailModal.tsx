import React, { useState } from 'react';
import { PosterItem, posterToProduct } from '../data/posters';
import { Product } from '../types';

interface PosterDetailModalProps {
  poster: PosterItem | null;
  onClose: () => void;
  onAddToCart: (product: Product, e: React.MouseEvent) => void;
}

export const PosterDetailModal: React.FC<PosterDetailModalProps> = ({
  poster,
  onClose,
  onAddToCart
}) => {
  const [selectedSize, setSelectedSize] = useState<'A2' | 'A3' | 'A1'>('A2');

  if (!poster) return null;

  const product = posterToProduct(poster);

  return (
    <div className="fixed inset-0 z-50 flex items-center justify-center p-4 bg-black/80 backdrop-blur-md animate-fadeIn">
      <div 
        className="bg-[#1A1A1A] border border-[#C9A84C]/50 rounded-3xl max-w-4xl w-full max-h-[90vh] overflow-y-auto p-6 sm:p-8 relative shadow-2xl space-y-6"
        onClick={(e) => e.stopPropagation()}
      >
        {/* Close Button */}
        <button 
          onClick={onClose}
          className="absolute top-4 right-4 w-10 h-10 rounded-full bg-[#0D0D0D] border border-[#2A2A2A] text-gray-400 hover:text-white hover:border-[#C9A84C] flex items-center justify-center transition z-20"
        >
          <i className="fa-solid fa-xmark text-lg"></i>
        </button>

        <div className="grid grid-cols-1 md:grid-cols-12 gap-6 sm:gap-8 items-start">
          {/* Left Column: High Res Poster Image */}
          <div className="md:col-span-6 bg-[#27272a] border border-[#2A2A2A] rounded-2xl p-3 relative overflow-hidden group">
            <img 
              src={poster.image} 
              alt={poster.title} 
              className="w-full h-auto max-h-[500px] object-contain rounded-xl mx-auto shadow-2xl"
              onError={(e) => {
                e.currentTarget.src = '/Banner Slider Đầu Trang Chủ (Hero Banner Slider)/km3_20240206150553.jpg';
              }}
            />
            <div className="absolute bottom-4 left-4 right-4 bg-[#0A0A0A]/90 backdrop-blur-md p-2.5 rounded-xl border border-[#2A2A2A] text-center text-xs text-[#C9A84C] font-semibold">
              <i className="fa-solid fa-circle-check mr-1 text-emerald-400"></i> Ảnh Poster Ultra HD Chính Hãng Bandai Japan
            </div>
          </div>

          {/* Right Column: Specifications & Purchasing */}
          <div className="md:col-span-6 space-y-5">
            <div>
              <div className="flex items-center gap-2 mb-2">
                <span className="bg-[#C9A84C] text-[#0A0A0A] font-black text-[10px] px-2.5 py-0.5 rounded-full uppercase">
                  {poster.badge}
                </span>
                <span className="text-xs text-gray-400">{poster.series}</span>
              </div>
              <h2 className="font-serif-title text-xl sm:text-2xl font-bold text-[#F5F2EB] leading-tight">
                {poster.title}
              </h2>
            </div>

            {/* Social Proof */}
            <div className="flex items-center gap-4 text-xs border-y border-[#2A2A2A] py-3">
              <div className="flex items-center gap-1.5 text-[#C9A84C] font-bold">
                <i className="fa-solid fa-star text-sm"></i>
                <span className="text-sm">{poster.rating.toFixed(1)}</span>
                <span className="text-gray-400 font-normal">({poster.reviewCount} Đánh giá)</span>
              </div>
              <span className="text-gray-600">|</span>
              <div className="text-emerald-400 font-bold">
                Đã bán {poster.soldCount}+ tấm
              </div>
            </div>

            {/* Pricing */}
            <div className="bg-[#0D0D0D] border border-[#2A2A2A] p-4 rounded-2xl flex items-center justify-between">
              <div>
                <span className="text-xs text-gray-400 block mb-0.5">Giá Khuyến Mãi Bản In Premium</span>
                <div className="text-2xl font-black text-[#C9A84C]">
                  {poster.price.toLocaleString('vi-VN')}đ
                </div>
              </div>
              {poster.originalPrice && (
                <div className="text-right">
                  <span className="text-xs text-gray-500 line-through block">
                    {poster.originalPrice.toLocaleString('vi-VN')}đ
                  </span>
                  <span className="bg-[#8B1E1E] text-white font-extrabold text-[10px] px-2 py-0.5 rounded-full">
                    Tiết kiệm {Math.round((1 - poster.price / poster.originalPrice) * 100)}%
                  </span>
                </div>
              )}
            </div>

            {/* Size Options */}
            <div className="space-y-2">
              <label className="text-xs font-bold text-[#F5F2EB] block">Kích Thước Khổ In Poster:</label>
              <div className="grid grid-cols-3 gap-2">
                {[
                  { id: 'A3', label: 'A3 (30 x 42 cm)', desc: 'Chuẩn treo bàn làm việc' },
                  { id: 'A2', label: 'A2 (42 x 60 cm)', desc: 'Chuẩn sưu tầm phổ biến' },
                  { id: 'A1', label: 'A1 (60 x 84 cm)', desc: 'Khổ siêu lớn ấn tượng' }
                ].map((s) => (
                  <button
                    key={s.id}
                    onClick={() => setSelectedSize(s.id as any)}
                    className={`p-2.5 rounded-xl border text-left transition ${
                      selectedSize === s.id
                        ? 'border-[#C9A84C] bg-[#C9A84C]/10 text-[#C9A84C] font-bold'
                        : 'border-[#2A2A2A] bg-[#0D0D0D] text-gray-400 hover:text-white'
                    }`}
                  >
                    <span className="text-xs font-bold block">{s.label}</span>
                    <span className="text-[9px] text-gray-500">{s.desc}</span>
                  </button>
                ))}
              </div>
            </div>

            {/* Paper Quality Spec */}
            <div className="space-y-2 text-xs text-gray-300 bg-[#0D0D0D] p-3.5 rounded-2xl border border-[#2A2A2A]">
              <div className="flex items-center gap-2 text-[#C9A84C] font-bold border-b border-[#2A2A2A] pb-2">
                <i className="fa-solid fa-scroll"></i> Thông Số Kỹ Thuật In Poster
              </div>
              <ul className="space-y-1.5 text-[11px] pt-1">
                <li>• <strong className="text-gray-200">Chất liệu:</strong> {poster.paperType}</li>
                <li>• <strong className="text-gray-200">Độ phân giải:</strong> Ultra HD 1200 DPI không mờ nhòe</li>
                <li>• <strong className="text-gray-200">Công nghệ:</strong> In UV Nano phủ bóng chống nước & bay màu</li>
                <li>• <strong className="text-gray-200">Quy cách đóng gói:</strong> Đóng ống Carton cứng bảo vệ 100% không vỡ gập</li>
              </ul>
            </div>

            {/* Action Buttons */}
            <div className="flex items-center gap-3 pt-2">
              <button
                onClick={(e) => {
                  onAddToCart(product, e);
                  onClose();
                }}
                className="flex-1 py-3.5 bg-gradient-to-r from-[#C9A84C] to-[#a27e2a] hover:brightness-110 text-[#0A0A0A] font-black text-sm rounded-2xl shadow-xl transition flex items-center justify-center gap-2"
              >
                <i className="fa-solid fa-cart-plus text-base"></i> Thêm Poster Vào Giỏ Hàng
              </button>
            </div>
          </div>
        </div>
      </div>
    </div>
  );
};
