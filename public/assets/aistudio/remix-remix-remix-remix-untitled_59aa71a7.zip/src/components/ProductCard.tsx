import React from 'react';
import { Product } from '../types';
import { playLaserClashSound, playHenshinSound } from '../utils/sound';

interface ProductCardProps {
  product: Product;
  onSelect: (product: Product) => void;
  onAddToCart: (product: Product, e: React.MouseEvent) => void;
  onAddToCompare?: (product: Product, e: React.MouseEvent) => void;
  isFavorite?: boolean;
  onToggleFavorite?: (product: Product, e: React.MouseEvent) => void;
}

export const ProductCard = React.memo<ProductCardProps>(({ 
  product, 
  onSelect, 
  onAddToCart, 
  onAddToCompare,
  isFavorite = false,
  onToggleFavorite
}) => {
  const discountPercent = product.originalPrice && product.originalPrice > product.price
    ? Math.round((1 - product.price / product.originalPrice) * 100)
    : 0;

  const isEven = parseInt(product.id.replace(/\D/g, '') || '0') % 2 === 0;
  const isGoldEdition = product.isCSM || product.isHot || !isEven;
  const isSilverEdition = product.isFlashSale || product.category === 'shf' || isEven;

  return (
    <div 
      onClick={() => onSelect(product)}
      className="group bg-[#080e1e] rounded-2xl overflow-hidden transition-all duration-300 flex flex-col cursor-pointer relative border border-cyan-500/35 hover:border-cyan-400 hover:shadow-[0_0_25px_rgba(0,245,212,0.25)] transform hover:-translate-y-1 aqua-glossy-card"
    >
      {/* Glossy Sheen Sweep on Card Hover */}
      <div className="absolute inset-0 bg-gradient-to-tr from-transparent via-cyan-400/10 to-transparent opacity-0 group-hover:opacity-100 transition-opacity duration-500 pointer-events-none z-10"></div>

      {/* Image Container with Hover Swap */}
      <div className="relative aspect-square bg-[#050914] overflow-hidden flex items-center justify-center p-2 border-b border-cyan-500/25">
        {/* Primary Image */}
        <img 
          src={product.images[0]} 
          alt={product.name} 
          className={`w-full h-full object-contain rounded-lg transition-all duration-500 ${
            product.images[1] && product.images[1] !== product.images[0]
              ? 'group-hover:opacity-0 group-hover:scale-105' 
              : 'group-hover:scale-105'
          }`}
          loading="lazy"
          decoding="async"
          onError={(e) => {
            e.currentTarget.src = '/Ảnh Sản Phẩm/dx/Kamen Rider Zeztz DX Henshin Belt Lord Invoker1.jpg';
          }}
        />

        {/* Secondary Hover Image (if available) */}
        {product.images[1] && product.images[1] !== product.images[0] && (
          <img 
            src={product.images[1]} 
            alt={`${product.name} alternate view`} 
            className="absolute inset-0 w-full h-full object-contain p-2 rounded-lg opacity-0 group-hover:opacity-100 group-hover:scale-105 transition-all duration-500"
            loading="lazy"
            decoding="async"
            onError={(e) => {
              e.currentTarget.style.display = 'none';
            }}
          />
        )}

        {/* Badges - Positioned at Bottom Left */}
        <div className="absolute bottom-2 left-2 flex flex-wrap items-center gap-1 z-10 max-w-[70%] pointer-events-none">
          {product.isFlashSale && (
            <span className="bg-rose-600 text-white text-[8px] font-black px-1.5 py-0.5 rounded uppercase tracking-wider shadow-sm border border-rose-400">
              ⚡ Flash Sale
            </span>
          )}
          {product.isCSM && (
            <span className="bg-[#00f5d4] text-slate-950 text-[8px] font-black px-1.5 py-0.5 rounded uppercase tracking-wider shadow-sm border border-cyan-300">
              CSM
            </span>
          )}
          {discountPercent > 0 && (
            <span className="bg-cyan-950 text-cyan-200 font-bold text-[8px] px-1.5 py-0.5 rounded border border-cyan-500/50">
              -{discountPercent}%
            </span>
          )}
        </div>

        {/* Top-Right Quick Action Overlay */}
        <div className="absolute top-2 right-2 flex items-center gap-1 z-20">
          {/* Quick Sound Effect Button */}
          <button
            type="button"
            onClick={(e) => {
              e.stopPropagation();
              if (product.category === 'csm' || product.isCSM) {
                playHenshinSound();
              } else {
                playLaserClashSound();
              }
            }}
            className="w-7 h-7 rounded-lg flex items-center justify-center transition-all duration-200 shadow-sm bg-[#060b18]/85 text-cyan-300 hover:text-white hover:bg-cyan-500/30 border border-cyan-500/40 hover:border-cyan-300 active:scale-90"
            title="Nghe âm thanh Henshin mẫu"
          >
            <i className="fa-solid fa-volume-high text-[10px]"></i>
          </button>

          {onToggleFavorite && (
            <button
              type="button"
              onClick={(e) => onToggleFavorite(product, e)}
              className={`w-7 h-7 rounded-lg flex items-center justify-center transition-all duration-200 shadow-sm ${
                isFavorite 
                  ? 'bg-rose-600 text-white border border-rose-400' 
                  : 'bg-[#060b18]/85 text-slate-300 hover:text-rose-400 border border-cyan-500/40 hover:border-rose-400'
              }`}
              title={isFavorite ? 'Bỏ yêu thích' : 'Yêu thích'}
            >
              <i className="fa-solid fa-heart text-[10px]"></i>
            </button>
          )}

          {onAddToCompare && (
            <button
              type="button"
              onClick={(e) => onAddToCompare(product, e)}
              className="w-7 h-7 rounded-lg flex items-center justify-center transition-all duration-200 shadow-sm bg-[#060b18]/85 text-slate-300 hover:text-cyan-300 border border-cyan-500/40 hover:border-cyan-300"
              title="So sánh"
            >
              <i className="fa-solid fa-code-compare text-[10px]"></i>
            </button>
          )}
        </div>
      </div>

      {/* Content Body - Tối ưu font chữ to rõ, tương phản cao, dễ nhìn nhất */}
      <div className="p-3.5 sm:p-4 flex-grow flex flex-col justify-between space-y-2.5">
        <div className="space-y-1.5">
          <div className="flex items-center justify-between text-[11px] text-slate-300">
            <span className="text-cyan-300 font-bold truncate max-w-[130px] uppercase tracking-wider">{product.series}</span>
            <span className="text-slate-200 text-[10px] bg-cyan-950/60 border border-cyan-500/30 px-2 py-0.5 rounded font-medium">
              {product.condition}
            </span>
          </div>

          <h3 className="font-extrabold text-sm sm:text-[15px] text-white group-hover:text-cyan-300 line-clamp-2 transition duration-200 leading-snug drop-shadow-sm">
            {product.name}
          </h3>

          {/* Social Proof */}
          <div className="flex items-center justify-between text-xs pt-0.5 text-slate-300">
            <div className="flex items-center gap-1 text-cyan-400">
              <i className="fa-solid fa-star text-[10px]"></i>
              <span className="font-bold text-white">{product.rating ? product.rating.toFixed(1) : '5.0'}</span>
            </div>
            <div className="text-emerald-400 text-xs font-semibold">
              Đã bán {product.soldCount || 120}
            </div>
          </div>
        </div>

        {/* Flash Sale Progress bar if active */}
        {product.isFlashSale && product.flashSaleStock && (
          <div className="space-y-1">
            <div className="flex justify-between text-[10px] text-slate-300 font-medium">
              <span className="text-rose-400 font-bold">⚡ Sắp hết hàng</span>
              <span>Còn: {product.flashSaleStock}</span>
            </div>
            <div className="w-full bg-slate-900 rounded-full h-1.5 overflow-hidden border border-cyan-500/20">
              <div 
                className="bg-gradient-to-r from-cyan-400 to-teal-300 h-full rounded-full"
                style={{ width: `${Math.min(100, (product.flashSaleStock / 30) * 100)}%` }}
              ></div>
            </div>
          </div>
        )}

        {/* Price & Action - Giá Aqua công nghệ to rõ ràng, nút Mua nổi bật */}
        <div className="pt-2.5 border-t border-cyan-500/25 flex items-center justify-between gap-2">
          <div>
            <div className="flex items-baseline gap-1.5">
              <span className="text-sm sm:text-base font-black text-[#00f5d4] font-mono tracking-tight drop-shadow-[0_0_8px_rgba(0,245,212,0.3)]">
                {product.price.toLocaleString('vi-VN')}đ
              </span>
            </div>
            {product.originalPrice && product.originalPrice > product.price && (
              <span className="text-[10px] sm:text-xs text-slate-400 line-through font-mono">
                {product.originalPrice.toLocaleString('vi-VN')}đ
              </span>
            )}
          </div>

          <button 
            onClick={(e) => onAddToCart(product, e)}
            className="px-3.5 py-1.5 rounded-xl bg-gradient-to-r from-[#00f5d4] via-[#06b6d4] to-[#0284c7] hover:brightness-110 text-slate-950 font-black shadow-[0_0_15px_rgba(0,245,212,0.35)] flex items-center gap-1.5 text-xs sm:text-sm transition duration-200 active:scale-95 cursor-pointer"
            title="Thêm vào giỏ hàng"
          >
            <i className="fa-solid fa-cart-plus text-xs"></i>
            <span>Mua</span>
          </button>
        </div>
      </div>
    </div>
  );
});
