import React from 'react';
import { Product } from '../types';

interface ProductCompareModalProps {
  isOpen: boolean;
  onClose: () => void;
  compareList: Product[];
  onRemoveFromCompare: (productId: string) => void;
  onAddToCart: (p: Product) => void;
}

export const ProductCompareModal: React.FC<ProductCompareModalProps> = ({
  isOpen,
  onClose,
  compareList,
  onRemoveFromCompare,
  onAddToCart
}) => {
  if (!isOpen) return null;

  return (
    <div className="fixed inset-0 z-50 bg-black/85 backdrop-blur-md flex items-center justify-center p-4 animate-fadeIn">
      <div className="bg-[#121212] border border-[#2A2A2A] rounded-3xl max-w-5xl w-full max-h-[90vh] flex flex-col overflow-hidden shadow-2xl text-[#F5F2EB]">
        {/* Header */}
        <div className="p-6 border-b border-[#2A2A2A] flex items-center justify-between bg-[#1A1A1A]">
          <div>
            <span className="text-[10px] uppercase font-bold text-[#C9A84C] tracking-widest block">Rider Spec Comparison Matrix</span>
            <h3 className="font-serif-title text-xl font-bold uppercase">
              SO SÁNH <span className="gold-gradient-text">SẢN PHẨM RIDER ({compareList.length}/3)</span>
            </h3>
          </div>
          <button 
            onClick={onClose}
            className="w-8 h-8 rounded-full bg-[#121212] border border-[#2A2A2A] hover:bg-[#2A2A2A] flex items-center justify-center text-gray-400 hover:text-white transition"
          >
            <i className="fa-solid fa-xmark"></i>
          </button>
        </div>

        {/* Comparison Content */}
        <div className="p-6 overflow-y-auto flex-grow space-y-6">
          {compareList.length === 0 ? (
            <div className="text-center py-12 text-gray-500 space-y-3">
              <i className="fa-solid fa-code-compare text-4xl block text-[#C9A84C]/40"></i>
              <p className="text-sm">Chưa có sản phẩm nào trong danh sách so sánh.</p>
              <p className="text-xs text-gray-600">Bấm biểu tượng "So sánh" ở sản phẩm ngoài Cửa hàng để thêm vào đây!</p>
            </div>
          ) : (
            <div className="overflow-x-auto">
              <table className="w-full text-left border-collapse text-xs">
                <thead>
                  <tr className="border-b border-[#2A2A2A]">
                    <th className="p-3 w-40 text-gray-400 uppercase font-bold bg-[#1A1A1A]">Thông Số / Chi Tiết</th>
                    {compareList.map(p => (
                      <th key={p.id} className="p-3 min-w-[220px] align-top bg-[#161616]">
                        <div className="relative space-y-2">
                          <button 
                            onClick={() => onRemoveFromCompare(p.id)}
                            className="absolute top-0 right-0 text-gray-500 hover:text-rose-400 p-1"
                            title="Xóa khỏi danh sách"
                          >
                            <i className="fa-solid fa-trash-can"></i>
                          </button>
                          <img src={p.images[0]} alt={p.name} className="w-24 h-24 object-contain p-1 rounded-xl bg-[#0A0A0A] border border-[#2A2A2A] mx-auto" />
                          <h4 className="font-bold text-[#F5F2EB] text-center text-xs line-clamp-2 h-8">{p.name}</h4>
                          <div className="text-center font-bold text-[#C9A84C] text-sm">
                            {p.price.toLocaleString('vi-VN')}đ
                          </div>
                          <button
                            onClick={() => onAddToCart(p)}
                            className="w-full bg-[#C9A84C] text-[#0A0A0A] font-extrabold py-1.5 rounded-lg text-[11px] hover:brightness-110 transition"
                          >
                            Thêm Vào Giỏ
                          </button>
                        </div>
                      </th>
                    ))}
                  </tr>
                </thead>
                <tbody className="divide-y divide-[#2A2A2A] text-gray-300">
                  <tr>
                    <td className="p-3 font-bold bg-[#1A1A1A] text-gray-400">Dòng Phim / Series</td>
                    {compareList.map(p => (
                      <td key={p.id} className="p-3 font-semibold text-[#F5F2EB]">{p.series}</td>
                    ))}
                  </tr>
                  <tr>
                    <td className="p-3 font-bold bg-[#1A1A1A] text-gray-400">Kỷ Nguyên (Era)</td>
                    {compareList.map(p => (
                      <td key={p.id} className="p-3">{p.era}</td>
                    ))}
                  </tr>
                  <tr>
                    <td className="p-3 font-bold bg-[#1A1A1A] text-gray-400">Phân Loại</td>
                    {compareList.map(p => (
                      <td key={p.id} className="p-3 uppercase font-bold text-[#C9A84C]">{p.category}</td>
                    ))}
                  </tr>
                  <tr>
                    <td className="p-3 font-bold bg-[#1A1A1A] text-gray-400">Tình Trạng Hàng</td>
                    {compareList.map(p => (
                      <td key={p.id} className="p-3 font-semibold text-emerald-400">{p.condition}</td>
                    ))}
                  </tr>
                  <tr>
                    <td className="p-3 font-bold bg-[#1A1A1A] text-gray-400">Chất Liệu</td>
                    {compareList.map(p => (
                      <td key={p.id} className="p-3">{p.specifications?.material || 'ABS / PVC'}</td>
                    ))}
                  </tr>
                  <tr>
                    <td className="p-3 font-bold bg-[#1A1A1A] text-gray-400">Hiệu Ứng LED & Sound</td>
                    {compareList.map(p => (
                      <td key={p.id} className="p-3">{p.specifications?.effects || 'N/A'}</td>
                    ))}
                  </tr>
                  <tr>
                    <td className="p-3 font-bold bg-[#1A1A1A] text-gray-400">Loại Pin</td>
                    {compareList.map(p => (
                      <td key={p.id} className="p-3 font-mono">{p.specifications?.batteryType || 'N/A'}</td>
                    ))}
                  </tr>
                  <tr>
                    <td className="p-3 font-bold bg-[#1A1A1A] text-gray-400">Năm Phát Hành</td>
                    {compareList.map(p => (
                      <td key={p.id} className="p-3 font-mono">{p.specifications?.releaseYear || '2026'}</td>
                    ))}
                  </tr>
                  <tr>
                    <td className="p-3 font-bold bg-[#1A1A1A] text-gray-400">Đánh Giá Collector</td>
                    {compareList.map(p => (
                      <td key={p.id} className="p-3 text-[#C9A84C] font-bold">
                        ★ {p.rating} ({p.reviewCount} đánh giá)
                      </td>
                    ))}
                  </tr>
                </tbody>
              </table>
            </div>
          )}
        </div>
      </div>
    </div>
  );
};
