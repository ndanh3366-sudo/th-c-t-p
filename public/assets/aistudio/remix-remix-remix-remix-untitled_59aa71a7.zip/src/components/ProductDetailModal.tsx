import React, { useState } from 'react';
import { Product } from '../types';

interface ProductDetailModalProps {
  product: Product | null;
  isOpen?: boolean;
  onClose: () => void;
  onAddToCart: (product: Product, quantity: number) => void;
  onBuyNow?: (product: Product, quantity: number) => void;
  showToast: (msg: string, type?: 'success' | 'error' | 'info') => void;
  isFavorite?: boolean;
  onToggleFavorite?: (product: Product, e?: React.MouseEvent) => void;
  onAddToCompare?: (product: Product, e?: React.MouseEvent) => void;
}

export const ProductDetailModal: React.FC<ProductDetailModalProps> = ({
  product,
  isOpen = true,
  onClose,
  onAddToCart,
  onBuyNow = (p, q) => { onAddToCart(p, q); showToast(`⚡ Đang tiến hành thanh toán cho [${p.name}]!`, 'success'); },
  showToast,
  isFavorite = false,
  onToggleFavorite,
  onAddToCompare
}) => {
  const [selectedImgIndex, setSelectedImgIndex] = useState(0);
  const [quantity, setQuantity] = useState(1);
  const [activeTab, setActiveTab] = useState<'desc' | 'specs' | 'video' | 'reviews' | 'qa'>('desc');
  const [is360Mode, setIs360Mode] = useState(false);
  
  // Review form state
  const [newComment, setNewComment] = useState('');
  const [newRating, setNewRating] = useState(5);
  const [reviewerName, setReviewerName] = useState('');

  // QA form state
  const [newQuestion, setNewQuestion] = useState('');

  if (!product) return null;

  const CUSTOMER_REVIEW_AVATARS = [
    { img: '/BIỂU TƯỢNG DANH MỤC SẢN PHẨM/dlyjpm8-ea90294c-de09-4bc2-8718-6b49acbf082e.png', border: 'border-red-500/50', bg: 'bg-red-950/40' },
    { img: '/BIỂU TƯỢNG DANH MỤC SẢN PHẨM/kamen_rider_revice_logo_by_driftingcar_dghk15w-pre.png', border: 'border-cyan-500/50', bg: 'bg-cyan-950/40' },
    { img: '/BIỂU TƯỢNG DANH MỤC SẢN PHẨM/kamen_rider_saber_logo_by_driftingcar_dgh9vay-pre.png', border: 'border-amber-500/50', bg: 'bg-amber-950/40' },
    { img: '/BIỂU TƯỢNG DANH MỤC SẢN PHẨM/kamen_rider_kiva_logo_by_driftingcar_dg7tj5z-pre.png', border: 'border-purple-500/50', bg: 'bg-purple-950/40' },
    { img: '/BIỂU TƯỢNG DANH MỤC SẢN PHẨM/kamen_rider_knight_logo_by_driftingcar_dg73k3x-414w-2x.png', border: 'border-blue-500/50', bg: 'bg-blue-950/40' },
    { img: '/BIỂU TƯỢNG DANH MỤC SẢN PHẨM/kamen_rider_femme_logo_by_driftingcar_dg73lkh-pre.png', border: 'border-pink-500/50', bg: 'bg-pink-950/40' },
  ];

  const defaultReviews = [
    {
      id: 'rev-default-1',
      userName: 'Trần Huy Hoàng (Collector)',
      rating: 5,
      date: '28/07/2026',
      comment: 'Hàng chính hãng Bandai Japan xịn xò 100%! Đóng gói xốp nổ cẩn thận, hộp đai không bị móp méo. Đèn LED siêu sáng và âm thanh giả lập biến hình chuẩn phim.',
      verifiedPurchase: true,
      avatar: '/BIỂU TƯỢNG DANH MỤC SẢN PHẨM/dlyjpm8-ea90294c-de09-4bc2-8718-6b49acbf082e.png'
    },
    {
      id: 'rev-default-2',
      userName: 'Minh Hoàng Tokusatsu',
      rating: 5,
      date: '25/07/2026',
      comment: 'Giao hàng hỏa tốc trong 2h tại TP.HCM. Đã test full chức năng âm thanh cảm ứng với phụ kiện đai. Rất đáng tiền ủng hộ shop lâu dài!',
      verifiedPurchase: true,
      avatar: '/BIỂU TƯỢNG DANH MỤC SẢN PHẨM/kamen_rider_revice_logo_by_driftingcar_dghk15w-pre.png'
    },
    {
      id: 'rev-default-3',
      userName: 'Phạm Tuấn Anh (Vĩnh Long)',
      rating: 5,
      date: '20/07/2026',
      comment: 'Chất lượng nhựa ABS cao cấp, các khớp cử động chắc chắn, màu sơn tĩnh điện phản quang rực rỡ.',
      verifiedPurchase: true,
      avatar: '/BIỂU TƯỢNG DANH MỤC SẢN PHẨM/kamen_rider_saber_logo_by_driftingcar_dgh9vay-pre.png'
    }
  ];

  const defaultQAList = [
    {
      id: 'qa-default-1',
      question: 'Sản phẩm này có kèm sẵn pin và bảo hành chính hãng Bandai chưa ạ?',
      askedBy: 'Trần Văn Nam',
      date: '27/07/2026',
      answer: 'Sản phẩm nguyên seal Bandai Japan 100%. NPTTEAMSTORE tặng kèm sẵn pin AAA kiềm cao cấp và thẻ bảo hành 12 tháng!',
      answeredBy: 'NPTTEAMSTORE Technical Team'
    },
    {
      id: 'qa-default-2',
      question: 'Có hỗ trợ ship COD toàn quốc và mở hộp đồng kiểm trước khi thanh toán không shop?',
      askedBy: 'Lê Hoàng Yến',
      date: '22/07/2026',
      answer: 'Dạ có ạ! Khách hàng được quyền mở hộp đồng kiểm tra hàng trước khi thanh toán cho tất cả đơn hàng COD toàn quốc.',
      answeredBy: 'NPTTEAMSTORE Customer Care'
    }
  ];

  const safeImages = (product.images && Array.isArray(product.images) && product.images.length > 0)
    ? product.images
    : [product.image || '/Ảnh Sản Phẩm/dx/Kamen Rider Zeztz DX Henshin Belt Lord Invoker1.jpg'];

  const safeFullDesc = (product.fullDescription && Array.isArray(product.fullDescription) && product.fullDescription.length > 0)
    ? product.fullDescription
    : [product.description || 'Sản phẩm Tokusatsu Kamen Rider chính hãng Bandai Japan cao cấp. Mới 100% nguyên seal đai & phụ kiện.'];

  const displayReviews = product.reviews && product.reviews.length > 0 ? product.reviews : defaultReviews;
  const displayQAList = product.qaList && product.qaList.length > 0 ? product.qaList : defaultQAList;

  const handleAddReview = (e: React.FormEvent) => {
    e.preventDefault();
    if (!newComment.trim() || !reviewerName.trim()) {
      showToast('⚠️ Vui lòng nhập tên và nội dung đánh giá!', 'error');
      return;
    }
    const newRev = {
      id: 'rev-' + Date.now(),
      userName: reviewerName,
      rating: newRating,
      date: new Date().toLocaleDateString('vi-VN'),
      comment: newComment,
      verifiedPurchase: true
    };
    if (!product.reviews) product.reviews = [];
    product.reviews.unshift(newRev);
    setNewComment('');
    setReviewerName('');
    showToast('🎉 Đã gửi đánh giá thành công! Nhận +50 Rider Points!', 'success');
  };

  const handleAddQuestion = (e: React.FormEvent) => {
    e.preventDefault();
    if (!newQuestion.trim()) return;
    const newQA = {
      id: 'qa-' + Date.now(),
      question: newQuestion,
      askedBy: 'Khách hàng',
      date: new Date().toLocaleDateString('vi-VN'),
      answer: 'Cảm ơn câu hỏi của bạn. Kỹ thuật viên NPTTEAMSTORE sẽ phản hồi trong 15 phút!',
      answeredBy: 'NPTTEAMSTORE Technical Team'
    };
    if (!product.qaList) product.qaList = [];
    product.qaList.unshift(newQA);
    setNewQuestion('');
    showToast('💬 Đã gửi câu hỏi! Ban tư vấn sẽ giải đáp ngay.', 'info');
  };

  return (
    <div className="fixed inset-0 z-50 flex items-center justify-center p-3 sm:p-6 bg-black/80 backdrop-blur-sm overflow-y-auto animate-fadeIn">
      <div className="bg-[#10141d] border border-cyan-500/40 rounded-3xl w-full max-w-5xl overflow-hidden shadow-2xl relative my-auto max-h-[90vh] flex flex-col">
        {/* Close Button */}
        <button 
          onClick={onClose}
          className="absolute top-4 right-4 z-20 w-9 h-9 rounded-full bg-[#090b10] border border-cyan-500/30 hover:border-cyan-400 text-gray-300 hover:text-white flex items-center justify-center transition"
        >
          <i className="fa-solid fa-xmark text-sm"></i>
        </button>

        {/* Modal Scrollable Body */}
        <div className="overflow-y-auto p-6 space-y-8 flex-grow">
          {/* Top Product Overview */}
          <div className="grid grid-cols-1 lg:grid-cols-12 gap-8 items-start">
            {/* Gallery Left */}
            <div className="lg:col-span-6 space-y-4">
              <div className="relative aspect-square bg-[#27272a] border border-[#2A2A2A] rounded-2xl overflow-hidden flex items-center justify-center p-3 group">
                <img 
                  src={safeImages[selectedImgIndex] || safeImages[0]} 
                  alt={product.name}
                  className={`w-full h-full object-contain transition-all duration-300 ${is360Mode ? 'animate-pulse scale-105' : ''}`}
                  onError={(e) => {
                    e.currentTarget.src = '/Ảnh Sản Phẩm/dx/Kamen Rider Zeztz DX Henshin Belt Lord Invoker1.jpg';
                  }}
                />

                {/* 360 Mode Simulator Button */}
                <button 
                  onClick={() => setIs360Mode(!is360Mode)}
                  className={`absolute bottom-4 right-4 px-3 py-1.5 rounded-full text-xs font-bold border flex items-center gap-1.5 shadow-lg transition ${
                    is360Mode 
                      ? 'bg-[#C9A84C] text-[#0A0A0A] border-[#C9A84C]' 
                      : 'bg-[#0A0A0A]/80 text-[#C9A84C] border-[#2A2A2A] hover:border-[#C9A84C]'
                  }`}
                >
                  <i className="fa-solid fa-arrows-spin"></i>
                  <span>{is360Mode ? 'Xoay 360° Đang Bật' : 'Chế độ Xoay 360°'}</span>
                </button>
              </div>

              {/* Thumbnails */}
              <div className="flex items-center gap-3 overflow-x-auto no-scrollbar pb-1">
                {safeImages.map((img, idx) => (
                  <button
                    key={idx}
                    onClick={() => { setSelectedImgIndex(idx); setIs360Mode(false); }}
                    className={`w-16 h-16 rounded-xl border overflow-hidden flex-shrink-0 bg-[#0D0D0D] p-1 transition ${
                      selectedImgIndex === idx ? 'border-[#C9A84C] ring-2 ring-[#C9A84C]/30' : 'border-[#2A2A2A] opacity-60 hover:opacity-100'
                    }`}
                  >
                    <img src={img} alt="" className="w-full h-full object-contain" onError={(e) => { e.currentTarget.src = '/Ảnh Sản Phẩm/dx/Kamen Rider Zeztz DX Henshin Belt Lord Invoker1.jpg'; }} />
                  </button>
                ))}
              </div>
            </div>

            {/* Main Info Right */}
            <div className="lg:col-span-6 space-y-5">
              <div>
                <div className="flex items-center gap-2 mb-2">
                  <span className="bg-[#C9A84C]/10 border border-[#C9A84C]/30 text-[#C9A84C] text-[10px] font-bold px-2.5 py-0.5 rounded-md uppercase">
                    {product.series}
                  </span>
                  <span className="bg-[#2A2A2A] text-gray-300 text-[10px] font-semibold px-2.5 py-0.5 rounded-md">
                    {product.condition}
                  </span>
                </div>
                <h2 className="font-serif-title text-xl sm:text-2xl font-bold text-[#F5F2EB] leading-tight">
                  {product.name}
                </h2>
                <p className="text-[10px] font-mono text-gray-500 mt-0.5">Mã SP: {product.code}</p>

                {/* Social Proof Stats Bar: Rating, Reviews, Sold Count & Q&A */}
                <div className="flex flex-wrap items-center gap-3 text-xs text-gray-300 mt-2.5 bg-[#0D0D0D] border border-[#2A2A2A] p-2.5 rounded-xl">
                  <div className="flex items-center gap-1 text-[#C9A84C] font-extrabold">
                    <i className="fa-solid fa-star text-xs"></i>
                    <span>{product.rating ? product.rating.toFixed(1) : '5.0'}</span>
                    <span className="text-gray-400 font-normal">({product.reviews?.length || product.reviewCount || 0} Đánh giá)</span>
                  </div>
                  <span className="text-gray-700">|</span>
                  <div className="flex items-center gap-1 font-bold text-emerald-400">
                    <i className="fa-solid fa-fire text-amber-500"></i>
                    <span>Đã bán <strong className="text-white font-mono">{product.soldCount}</strong> sản phẩm</span>
                  </div>
                  <span className="text-gray-700">|</span>
                  <div className="flex items-center gap-1 text-sky-400 font-medium">
                    <i className="fa-solid fa-comments"></i>
                    <span>{product.qaList?.length || 0} Hỏi đáp</span>
                  </div>
                </div>
              </div>

              {/* Price & Guarantee Box */}
              <div className="bg-[#060b18] border border-cyan-500/35 rounded-2xl p-4 flex items-center justify-between shadow-lg">
                <div>
                  <span className="text-2xl font-black text-[#00f5d4] font-mono drop-shadow-[0_0_10px_rgba(0,245,212,0.35)]">
                    {product.price.toLocaleString('vi-VN')}đ
                  </span>
                  {product.originalPrice && (
                    <span className="text-xs text-slate-400 line-through font-mono ml-2">
                      {product.originalPrice.toLocaleString('vi-VN')}đ
                    </span>
                  )}
                </div>
                <span className="text-xs text-emerald-400 font-semibold bg-emerald-950/60 border border-emerald-500/50 px-3 py-1 rounded-full flex items-center gap-1.5 shadow-sm">
                  <i className="fa-solid fa-circle-check"></i> New Seal Bandai 100%
                </span>
              </div>

              {/* Specs Quick Pill List */}
              <div className="grid grid-cols-2 gap-2 text-xs text-slate-300">
                <div className="bg-[#091124] p-2.5 rounded-xl border border-cyan-500/30">
                  <span className="text-[10px] text-slate-400 block font-medium">Hãng Sản Xuất</span>
                  <strong className="text-white font-bold">{product.specifications?.manufacturer || 'Bandai Japan'}</strong>
                </div>
                <div className="bg-[#091124] p-2.5 rounded-xl border border-cyan-500/30">
                  <span className="text-[10px] text-slate-400 block font-medium">Loại Pin Khuyên Dùng</span>
                  <strong className="text-white font-bold">{product.specifications?.batteryType || 'Không dùng pin'}</strong>
                </div>
              </div>

              {/* Quantity Selector & Purchase CTAs */}
              <div className="space-y-3 pt-2">
                <div className="flex items-center gap-4">
                  <span className="text-xs font-semibold text-slate-300">Số lượng:</span>
                  <div className="flex items-center border border-cyan-500/35 bg-[#060b18] rounded-xl overflow-hidden">
                    <button 
                      onClick={() => setQuantity(Math.max(1, quantity - 1))}
                      className="px-3 py-1.5 hover:bg-cyan-500/20 text-slate-200 font-bold"
                    >
                      -
                    </button>
                    <span className="px-4 py-1.5 text-xs font-bold font-mono text-white">{quantity}</span>
                    <button 
                      onClick={() => setQuantity(quantity + 1)}
                      className="px-3 py-1.5 hover:bg-cyan-500/20 text-slate-200 font-bold"
                    >
                      +
                    </button>
                  </div>
                  <span className="text-[10px] text-slate-400 font-medium">Kho: còn {product.stock} sản phẩm</span>
                </div>

                <div className="flex flex-col gap-2.5 pt-2">
                  <div className="grid grid-cols-2 sm:grid-cols-4 gap-2">
                    {onToggleFavorite && (
                      <button
                        onClick={(e) => onToggleFavorite(product, e)}
                        className={`py-3 rounded-xl border font-bold text-xs flex items-center justify-center gap-1.5 transition ${
                          isFavorite 
                            ? 'bg-rose-600 text-white border-rose-500 shadow-lg shadow-rose-600/30' 
                            : 'bg-[#091124] hover:bg-[#0c1833] text-slate-300 hover:text-rose-400 border-cyan-500/30'
                        }`}
                        title={isFavorite ? 'Xóa khỏi yêu thích' : 'Thêm vào yêu thích'}
                      >
                        <i className={`fa-solid fa-heart ${isFavorite ? 'animate-pulse' : ''}`}></i>
                        <span>{isFavorite ? 'Đã Yêu Thích' : 'Yêu Thích'}</span>
                      </button>
                    )}

                    {onAddToCompare && (
                      <button
                        onClick={(e) => onAddToCompare(product, e)}
                        className="py-3 rounded-xl border border-cyan-500/40 bg-[#091124] hover:bg-cyan-500/20 text-cyan-300 font-bold text-xs flex items-center justify-center gap-1.5 transition"
                        title="Thêm vào bảng so sánh"
                      >
                        <i className="fa-solid fa-code-compare"></i>
                        <span>So Sánh</span>
                      </button>
                    )}

                    <button 
                      onClick={() => onAddToCart(product, quantity)}
                      className="py-3 bg-cyan-500/15 hover:bg-cyan-500/25 border border-cyan-500/50 text-[#00f5d4] font-bold text-xs rounded-xl transition flex items-center justify-center gap-1.5 shadow-sm"
                    >
                      <i className="fa-solid fa-cart-plus"></i> Thêm Giỏ
                    </button>

                    <button 
                      onClick={() => onBuyNow(product, quantity)}
                      className="py-3 bg-gradient-to-r from-[#00f5d4] via-[#06b6d4] to-[#0284c7] hover:brightness-110 text-slate-950 font-black text-xs rounded-xl shadow-[0_0_20px_rgba(0,245,212,0.35)] transition flex items-center justify-center gap-1.5 cursor-pointer active:scale-95"
                    >
                      <i className="fa-solid fa-bolt"></i> Mua Ngay
                    </button>
                  </div>
                </div>
              </div>
            </div>
          </div>

          {/* Lower Tabs: Specs, Unboxing Video, Reviews, Q&A */}
          <div className="border-t border-slate-800 pt-6 space-y-6">
            <div className="flex items-center gap-2 border-b border-slate-800 overflow-x-auto no-scrollbar pb-3 text-xs font-bold">
              <button 
                onClick={() => setActiveTab('desc')}
                className={`px-4 py-2 rounded-xl transition ${activeTab === 'desc' ? 'bg-cyan-500/20 text-cyan-300 border border-cyan-500/50' : 'text-slate-400 hover:text-white'}`}
              >
                Mô Tả Chi Tiết
              </button>
              <button 
                onClick={() => setActiveTab('specs')}
                className={`px-4 py-2 rounded-xl transition ${activeTab === 'specs' ? 'bg-cyan-500/20 text-cyan-300 border border-cyan-500/50' : 'text-slate-400 hover:text-white'}`}
              >
                Thông Số Kỹ Thuật
              </button>
              {product.videoUrl && (
                <button 
                  onClick={() => setActiveTab('video')}
                  className={`px-4 py-2 rounded-xl transition ${activeTab === 'video' ? 'bg-cyan-500/20 text-cyan-300 border border-cyan-500/50' : 'text-slate-400 hover:text-white'}`}
                >
                  <i className="fa-brands fa-youtube text-red-500 mr-1"></i> Video Review Unboxing
                </button>
              )}
              <button 
                onClick={() => setActiveTab('reviews')}
                className={`px-4 py-2 rounded-xl transition ${activeTab === 'reviews' ? 'bg-[#C9A84C] text-[#0A0A0A]' : 'text-gray-400 hover:text-white'}`}
              >
                Đánh Giá ({displayReviews.length})
              </button>
              <button 
                onClick={() => setActiveTab('qa')}
                className={`px-4 py-2 rounded-xl transition ${activeTab === 'qa' ? 'bg-[#C9A84C] text-[#0A0A0A]' : 'text-gray-400 hover:text-white'}`}
              >
                Hỏi Đáp Q&A ({displayQAList.length})
              </button>
            </div>

            {/* Tab Contents */}
            {activeTab === 'desc' && (
              <div className="space-y-3 text-xs sm:text-sm text-gray-300 leading-relaxed">
                {safeFullDesc.map((p, idx) => (
                  <p key={idx}>{p}</p>
                ))}
              </div>
            )}

            {activeTab === 'specs' && (
              <div className="bg-[#0D0D0D] border border-[#2A2A2A] rounded-2xl overflow-hidden text-xs">
                <table className="w-full text-left border-collapse">
                  <tbody className="divide-y divide-[#2A2A2A] text-gray-300">
                    <tr><td className="p-3 bg-[#1A1A1A] font-bold text-[#C9A84C] w-1/3">Nhà sản xuất</td><td className="p-3">{product.specifications?.manufacturer || 'Bandai Japan'}</td></tr>
                    <tr><td className="p-3 bg-[#1A1A1A] font-bold text-[#C9A84C]">Chất liệu</td><td className="p-3">{product.specifications?.material || 'Nhựa ABS / PVC / Diecast'}</td></tr>
                    <tr><td className="p-3 bg-[#1A1A1A] font-bold text-[#C9A84C]">Năm phát hành</td><td className="p-3">{product.specifications?.releaseYear || '2026'}</td></tr>
                    <tr><td className="p-3 bg-[#1A1A1A] font-bold text-[#C9A84C]">Loại Pin</td><td className="p-3">{product.specifications?.batteryType || 'Không dùng pin'}</td></tr>
                    <tr><td className="p-3 bg-[#1A1A1A] font-bold text-[#C9A84C]">Hiệu ứng</td><td className="p-3">{product.specifications?.effects || 'In UV sắc nét / Đèn LED & Âm Thanh (nếu có)'}</td></tr>
                    <tr><td className="p-3 bg-[#1A1A1A] font-bold text-[#C9A84C]">Kích thước đóng hộp</td><td className="p-3">{product.specifications?.dimensions || 'Khổ tiêu chuẩn (42 x 59.4 cm)'}</td></tr>
                  </tbody>
                </table>
              </div>
            )}

            {activeTab === 'video' && product.videoUrl && (
              <div className="aspect-video w-full rounded-2xl overflow-hidden border border-[#2A2A2A] bg-black">
                <iframe 
                  src={product.videoUrl} 
                  title={product.name}
                  className="w-full h-full"
                  allow="accelerometer; autoplay; clipboard-write; encrypted-media; gyroscope; picture-in-picture"
                  allowFullScreen
                ></iframe>
              </div>
            )}

            {activeTab === 'reviews' && (
              <div className="space-y-6">
                {/* Submit review form */}
                <form onSubmit={handleAddReview} className="bg-[#0D0D0D] border border-[#2A2A2A] p-4 rounded-2xl space-y-3">
                  <h4 className="font-bold text-xs text-[#C9A84C] uppercase">Viết Đánh Giá Mới (Nhận +50 Rider Points)</h4>
                  <div className="grid grid-cols-1 sm:grid-cols-2 gap-3">
                    <input 
                      type="text" 
                      value={reviewerName}
                      onChange={(e) => setReviewerName(e.target.value)}
                      placeholder="Họ và tên của bạn..." 
                      className="bg-[#1A1A1A] border border-[#2A2A2A] rounded-xl px-3 py-2 text-xs text-white"
                      required
                    />
                    <div className="flex items-center gap-2 text-xs text-gray-300">
                      <span>Đánh giá:</span>
                      {[1, 2, 3, 4, 5].map(star => (
                        <button
                          type="button"
                          key={star}
                          onClick={() => setNewRating(star)}
                          className={`text-sm ${star <= newRating ? 'text-[#C9A84C]' : 'text-gray-600'}`}
                        >
                          ★
                        </button>
                      ))}
                    </div>
                  </div>
                  <textarea 
                    value={newComment}
                    onChange={(e) => setNewComment(e.target.value)}
                    placeholder="Chia sẻ trải nghiệm chơi đai / mô hình Bandai của bạn..."
                    className="w-full bg-[#1A1A1A] border border-[#2A2A2A] rounded-xl p-3 text-xs text-white h-20 resize-none"
                    required
                  ></textarea>
                  <button type="submit" className="px-5 py-2 bg-[#C9A84C] text-[#0A0A0A] font-bold text-xs rounded-xl hover:brightness-110">
                    Gửi Đánh Giá
                  </button>
                </form>

                {/* Reviews List */}
                <div className="space-y-3">
                  {displayReviews.length > 0 ? (
                    displayReviews.map((rev, idx) => {
                      const avatarInfo = CUSTOMER_REVIEW_AVATARS[idx % CUSTOMER_REVIEW_AVATARS.length];
                      return (
                        <div key={rev.id} className="bg-[#0D0D0D] border border-[#2A2A2A] p-4 rounded-2xl space-y-2 text-xs">
                          <div className="flex justify-between items-center">
                            <div className="flex items-center gap-2.5">
                              <div className={`w-8 h-8 rounded-full overflow-hidden border ${avatarInfo.border} ${avatarInfo.bg} p-1 flex items-center justify-center shrink-0`}>
                                <img 
                                  src={rev.avatar || avatarInfo.img} 
                                  alt={rev.userName} 
                                  className="w-full h-full object-contain filter drop-shadow-[0_0_4px_rgba(0,255,255,0.7)]" 
                                  onError={(e) => {
                                    e.currentTarget.src = '/BIỂU TƯỢNG DANH MỤC SẢN PHẨM/dlyjpm8-ea90294c-de09-4bc2-8718-6b49acbf082e.png';
                                  }}
                                />
                              </div>
                              <div>
                                <span className="font-bold text-[#F5F2EB] block leading-tight">{rev.userName}</span>
                                {rev.verifiedPurchase && (
                                  <span className="text-[9px] text-emerald-400 font-semibold flex items-center gap-1">
                                    <i className="fa-solid fa-circle-check"></i> Đã mua hàng tại NPTTEAMSTORE
                                  </span>
                                )}
                              </div>
                            </div>
                            <span className="text-gray-500 text-[10px]">{rev.date}</span>
                          </div>
                        <div className="text-[#C9A84C] text-sm tracking-wider">{'★'.repeat(rev.rating)}{'☆'.repeat(5 - rev.rating)}</div>
                        <p className="text-gray-300 leading-relaxed bg-[#141414] p-2.5 rounded-xl border border-[#222]">{rev.comment}</p>
                      </div>
                    );
                  })
                  ) : (
                    <p className="text-xs text-gray-500 py-4 text-center">Chưa có đánh giá nào cho sản phẩm này.</p>
                  )}
                </div>
              </div>
            )}

            {activeTab === 'qa' && (
              <div className="space-y-6">
                <form onSubmit={handleAddQuestion} className="flex gap-2">
                  <input 
                    type="text"
                    value={newQuestion}
                    onChange={(e) => setNewQuestion(e.target.value)}
                    placeholder="Đặt câu hỏi về đai, loại pin, phụ kiện..."
                    className="flex-grow bg-[#0D0D0D] border border-[#2A2A2A] rounded-xl px-4 py-2.5 text-xs text-white focus:outline-none"
                    required
                  />
                  <button type="submit" className="px-5 py-2.5 bg-[#C9A84C] text-[#0A0A0A] font-bold text-xs rounded-xl whitespace-nowrap">
                    Gửi Câu Hỏi
                  </button>
                </form>

                <div className="space-y-3">
                  {displayQAList.length > 0 ? (
                    displayQAList.map(qa => (
                      <div key={qa.id} className="bg-[#0D0D0D] border border-[#2A2A2A] p-4 rounded-2xl space-y-2 text-xs">
                        <p className="font-bold text-[#F5F2EB]"><i className="fa-solid fa-circle-question text-[#C9A84C] mr-1.5"></i>{qa.question}</p>
                        {qa.answer && (
                          <div className="bg-[#1A1A1A] p-3 rounded-xl border border-[#2A2A2A] text-gray-300 space-y-1">
                            <span className="text-[10px] text-[#C9A84C] font-bold uppercase block">{qa.answeredBy}</span>
                            <p>{qa.answer}</p>
                          </div>
                        )}
                      </div>
                    ))
                  ) : (
                    <p className="text-xs text-gray-500 py-4 text-center">Chưa có câu hỏi nào.</p>
                  )}
                </div>
              </div>
            )}
          </div>
        </div>
      </div>
    </div>
  );
};
