import React, { useState, useEffect } from 'react';
import { playFanfareSound, playLaserClashSound } from '../utils/sound';

interface TeamTributeModalProps {
  isOpen: boolean;
  onClose: () => void;
  showToast?: (msg: string, type?: 'success' | 'error' | 'info') => void;
}

interface TeamMember {
  id: string;
  name: string;
  tier: 'leader' | 'vice' | 'soldier';
  role: string;
  roleBadge: string;
  image: string;
  quote: string;
  favoriteRider: string;
  riderCrest: string;
  accentBorder: string;
  badgeStyle: string;
  cardBg: string;
  iconSymbol: string;
}

const LEADER_MEMBER: TeamMember = {
  id: 'dat',
  name: 'Đoàn Tiến Đạt',
  tier: 'leader',
  role: 'Trưởng nhóm',
  roleBadge: '👑 TRƯỞNG NHÓM SÁNG LẬP',
  image: '/Ảnh Sản Phẩm/teamnpt/Đoàn Tiến Đạt.jpg',
  quote: '“Kiến tạo không gian mua sắm và giao lưu Tokusatsu chuẩn mực, chính hãng và đáng tin cậy nhất cho cộng đồng tại Việt Nam.”',
  favoriteRider: 'Kamen Rider Decade & Gavv',
  riderCrest: '/BIỂU TƯỢNG DANH MỤC SẢN PHẨM/dlyjpm8-ea90294c-de09-4bc2-8718-6b49acbf082e.png',
  accentBorder: 'border-2 border-cyan-400 shadow-[0_0_25px_rgba(6,182,212,0.6)]',
  badgeStyle: 'bg-gradient-to-r from-cyan-400 via-teal-400 to-blue-500 text-black font-black border border-cyan-300 shadow-md',
  cardBg: 'bg-gradient-to-b from-[#0a152e] via-[#081024] to-[#040814] border-2 border-cyan-400/90 shadow-[0_0_40px_rgba(6,182,212,0.25)]',
  iconSymbol: '👑'
};

const VICE_MEMBER: TeamMember = {
  id: 'luan',
  name: 'Vũ Tạ Hữu Luân',
  tier: 'vice',
  role: 'Phó nhóm',
  roleBadge: '⚔️ PHÓ NHÓM ĐIỀU HÀNH',
  image: '/Ảnh Sản Phẩm/teamnpt/Vũ Tạ Hữu Luân.jpg',
  quote: '“Đồng hành xây dựng hệ thống NPTTEAMSTORE chuyên nghiệp, chuẩn mực và bền vững dài lâu cùng ngọn lửa đam mê.”',
  favoriteRider: 'Kamen Rider Knight & Geats',
  riderCrest: '/BIỂU TƯỢNG DANH MỤC SẢN PHẨM/kamen_rider_knight_logo_by_driftingcar_dg73k3x-414w-2x.png',
  accentBorder: 'border-2 border-slate-200 shadow-[0_0_22px_rgba(226,232,240,0.55)]',
  badgeStyle: 'bg-gradient-to-r from-slate-200 via-slate-300 to-slate-400 text-slate-950 font-black border border-slate-100 shadow-md',
  cardBg: 'bg-gradient-to-b from-[#0a152e] via-[#091124] to-[#050914] border-2 border-slate-300/80 shadow-[0_0_35px_rgba(203,213,225,0.2)]',
  iconSymbol: '⚔️'
};

const SOLDIER_MEMBERS: TeamMember[] = [
  {
    id: 'hiep',
    name: 'Hoàng Trọng Hiệp',
    tier: 'soldier',
    role: 'Đồng sáng lập & Quản trị viên',
    roleBadge: 'QUẢN TRỊ VIÊN',
    image: '/Ảnh Sản Phẩm/teamnpt/Hoàng Trọng Hiệp.jpg',
    quote: '“Đảm bảo từng kiện hàng Bandai đến tay collector an toàn, nguyên seal và nhanh chóng nhất.”',
    favoriteRider: 'Kamen Rider Zeztz 2026',
    riderCrest: '/BIỂU TƯỢNG DANH MỤC SẢN PHẨM/kamen_rider_revice_logo_by_driftingcar_dghk15w-pre.png',
    accentBorder: 'border-2 border-cyan-400/80 shadow-[0_0_15px_rgba(6,182,212,0.4)]',
    badgeStyle: 'bg-cyan-500/20 text-cyan-300 border border-cyan-400/50 font-bold',
    cardBg: 'bg-[#091122]/90 border border-cyan-500/40 hover:border-cyan-400',
    iconSymbol: '📦'
  },
  {
    id: 'danh',
    name: 'Nguyễn Thành Danh',
    tier: 'soldier',
    role: 'Đồng sáng lập & Quản trị viên',
    roleBadge: 'QUẢN TRỊ VIÊN',
    image: '/Ảnh Sản Phẩm/teamnpt/Nguyễn Thành Danh.jpg',
    quote: '“Uy tín và chuẩn mực sưu tầm là kim chỉ nam trong từng quyết định hỗ trợ người mua.”',
    favoriteRider: 'Kamen Rider Saber & Gaim',
    riderCrest: '/BIỂU TƯỢNG DANH MỤC SẢN PHẨM/kamen_rider_saber_logo_by_driftingcar_dgh9vay-pre.png',
    accentBorder: 'border-2 border-cyan-400/80 shadow-[0_0_15px_rgba(6,182,212,0.4)]',
    badgeStyle: 'bg-cyan-500/20 text-cyan-300 border border-cyan-400/50 font-bold',
    cardBg: 'bg-[#091122]/90 border border-cyan-500/40 hover:border-cyan-400',
    iconSymbol: '💎'
  },
  {
    id: 'binh',
    name: 'Vũ Thanh Bình',
    tier: 'soldier',
    role: 'Đồng sáng lập & Quản trị viên',
    roleBadge: 'QUẢN TRỊ VIÊN',
    image: '/Ảnh Sản Phẩm/teamnpt/Vũ Thanh Bình.png',
    quote: '“Lan tỏa ngọn lửa đam mê Tokusatsu và tinh thần Henshin tích cực đến mọi thế hệ.”',
    favoriteRider: 'Kamen Rider Kiva & Femme',
    riderCrest: '/BIỂU TƯỢNG DANH MỤC SẢN PHẨM/kamen_rider_kiva_logo_by_driftingcar_dg7tj5z-pre.png',
    accentBorder: 'border-2 border-cyan-400/80 shadow-[0_0_15px_rgba(6,182,212,0.4)]',
    badgeStyle: 'bg-cyan-500/20 text-cyan-300 border border-cyan-400/50 font-bold',
    cardBg: 'bg-[#091122]/90 border border-cyan-500/40 hover:border-cyan-400',
    iconSymbol: '✨'
  }
];

export const TeamTributeModal: React.FC<TeamTributeModalProps> = ({
  isOpen,
  onClose,
  showToast
}) => {
  const [likes, setLikes] = useState<{ [key: string]: number }>({
    dat: 890,
    luan: 420,
    hiep: 310,
    danh: 295,
    binh: 305
  });

  useEffect(() => {
    if (isOpen) {
      playFanfareSound();
    }
  }, [isOpen]);

  if (!isOpen) return null;

  const handleLike = (id: string, name: string) => {
    setLikes(prev => ({ ...prev, [id]: (prev[id] || 0) + 1 }));
    playLaserClashSound();
    if (showToast) {
      showToast(`⭐ Cảm ơn bạn đã gửi lời tri ân đến ${name}!`, 'success');
    }
  };

  return (
    <div className="fixed inset-0 z-50 flex items-center justify-center p-3 sm:p-4 bg-black/85 backdrop-blur-md animate-fade-in">
      <div 
        className="relative w-full max-w-4xl rounded-3xl bg-[#060b18] border-2 border-cyan-400/80 shadow-[0_0_50px_rgba(6,182,212,0.35)] overflow-hidden flex flex-col max-h-[92vh]"
        onClick={(e) => e.stopPropagation()}
      >
        {/* Header Bar */}
        <div className="bg-gradient-to-r from-[#09152b] via-[#0d2249] to-[#09152b] p-4 sm:p-5 border-b border-cyan-500/40 flex items-center justify-between shrink-0">
          <div className="flex items-center gap-3">
            <div className="w-10 h-10 rounded-xl bg-cyan-950 border border-cyan-400/80 flex items-center justify-center text-cyan-300 shadow-[0_0_15px_rgba(0,255,255,0.4)]">
              <i className="fa-solid fa-award text-lg"></i>
            </div>
            <div>
              <span className="text-[10px] text-cyan-300 font-bold uppercase tracking-wider">
                NPTTEAMSTORE OFFICIAL TRIBUTE
              </span>
              <h2 className="font-serif-title text-base sm:text-lg font-black text-white text-pop">
                Bảng Tri Ân: Đội Ngũ Sáng Lập & Ban Quản Trị Team NPT
              </h2>
            </div>
          </div>

          <button 
            onClick={onClose}
            className="w-9 h-9 rounded-full bg-[#0a152e] hover:bg-cyan-900/60 text-slate-300 hover:text-white border border-cyan-500/30 hover:border-cyan-400 flex items-center justify-center transition shrink-0 cursor-pointer"
            title="Đóng cửa sổ"
          >
            <i className="fa-solid fa-xmark text-sm"></i>
          </button>
        </div>

        {/* Scrollable Content Body */}
        <div className="p-4 sm:p-6 space-y-6 max-h-[82vh] overflow-y-auto no-scrollbar relative z-10">
          
          {/* Hero Banner: Respectful tribute overview */}
          <div className="bg-gradient-to-r from-[#07132a] via-[#0b1c3c] to-[#060e20] border border-cyan-500/40 rounded-2xl p-4 sm:p-5 flex flex-col sm:flex-row items-center justify-between gap-4 shadow-lg">
            <div className="space-y-1 text-center sm:text-left">
              <div className="inline-flex items-center gap-2 text-xs font-bold text-cyan-300">
                <span>👑 Trưởng nhóm</span>
                <span className="text-slate-500">•</span>
                <span>⚔️ Phó nhóm</span>
                <span className="text-slate-500">•</span>
                <span>🛡️ Ban Quản Trị</span>
              </div>
              <h3 className="font-serif-title text-base sm:text-xl font-black text-white text-pop">
                Đội Ngũ Sáng Lập & Đồng Hành Team NPT
              </h3>
              <p className="text-xs text-slate-200 leading-relaxed max-w-2xl font-medium">
                Gửi lời tri ân sâu sắc đến những người đã gây dựng và đồng hành cùng NPTTEAMSTORE, mang đến không gian mua sắm và bảo tồn văn hóa Tokusatsu Bandai Japan hàng đầu Việt Nam.
              </p>
            </div>

            <div className="flex-shrink-0 flex sm:flex-col items-center gap-2 text-center text-xs">
              <div className="bg-[#050a16] border border-cyan-400/60 rounded-xl px-3 py-1.5 shadow-sm">
                <span className="block font-mono text-cyan-300 font-black text-sm">TEAM NPT</span>
                <span className="text-[9px] text-slate-300 uppercase">Kỷ Niệm Đam Mê</span>
              </div>
            </div>
          </div>

          {/* 1. TRƯỞNG NHÓM - ĐOÀN TIẾN ĐẠT */}
          <div className="space-y-2">
            <div className="flex items-center gap-2">
              <span className="text-xl">👑</span>
              <h3 className="font-serif-title text-sm sm:text-base font-black text-cyan-300 uppercase tracking-wider">
                TRƯỞNG NHÓM SÁNG LẬP
              </h3>
            </div>

            <div className={`${LEADER_MEMBER.cardBg} rounded-2xl p-4 sm:p-6 relative overflow-hidden transition-all duration-300 hover:shadow-[0_0_35px_rgba(6,182,212,0.35)] group`}>
              <div className="flex flex-col md:flex-row items-center md:items-start gap-5 relative z-10">
                
                {/* Avatar with Royal Crown */}
                <div className="relative shrink-0">
                  <div className="absolute -top-3 -left-3 z-20 flex items-center justify-center bg-cyan-400 text-black p-1 rounded-full shadow-lg border-2 border-white">
                    <span className="text-lg leading-none">👑</span>
                  </div>

                  <div className={`w-28 h-28 sm:w-32 sm:h-32 rounded-2xl overflow-hidden bg-[#08020a] p-0.5 ${LEADER_MEMBER.accentBorder} transition duration-300 group-hover:scale-105`}>
                    <img 
                      src={LEADER_MEMBER.image} 
                      alt={LEADER_MEMBER.name} 
                      className="w-full h-full object-cover rounded-[14px]"
                      onError={(e) => {
                        e.currentTarget.src = '/Logo & Thương Hiệu (Brand Logo)/dreamina-2026-07-29-3008-A minimalist stencil-style logo of an oc....png';
                      }}
                    />
                  </div>

                  <div className="absolute -bottom-2 -right-2 w-7 h-7 rounded-lg bg-black/90 p-0.5 border-2 border-cyan-400 overflow-hidden shadow-md">
                    <img src={LEADER_MEMBER.riderCrest} alt="Crest" className="w-full h-full object-contain" />
                  </div>
                </div>

                {/* Leader Info */}
                <div className="space-y-3 flex-grow text-center md:text-left">
                  <div className="flex flex-col sm:flex-row sm:items-center justify-between gap-2">
                    <div>
                      <span className={`inline-flex items-center gap-1 text-[10px] uppercase px-2.5 py-0.5 rounded-full mb-1 ${LEADER_MEMBER.badgeStyle}`}>
                        👑 TRƯỞNG NHÓM SÁNG LẬP
                      </span>
                      <h4 className="font-serif-title font-black text-xl sm:text-2xl text-white text-pop flex items-center justify-center md:justify-start gap-2">
                        {LEADER_MEMBER.name}
                      </h4>
                      <p className="text-xs text-cyan-300 font-bold">
                        Sáng lập & Trưởng nhóm Team NPT
                      </p>
                    </div>

                    <button
                      onClick={() => handleLike(LEADER_MEMBER.id, LEADER_MEMBER.name)}
                      className="px-4 py-2 rounded-xl text-xs font-black bg-gradient-to-r from-cyan-400 to-blue-500 hover:brightness-110 text-black flex items-center justify-center gap-2 shadow-lg shadow-cyan-500/25 transition transform active:scale-95 shrink-0 self-center sm:self-auto cursor-pointer"
                    >
                      <span>👑 Tri ân Trưởng nhóm</span>
                      <span className="font-mono bg-black/20 px-2 py-0.5 rounded-full text-black text-[11px]">
                        {likes[LEADER_MEMBER.id]}
                      </span>
                    </button>
                  </div>

                  {/* Rider Favorite */}
                  <div className="inline-flex items-center gap-2 bg-[#040916] border border-cyan-500/30 px-3 py-1 rounded-xl text-xs text-cyan-200">
                    <i className="fa-solid fa-mask text-cyan-400"></i>
                    <span>Rider yêu thích: <strong>{LEADER_MEMBER.favoriteRider}</strong></span>
                  </div>

                  {/* Leader Quote */}
                  <p className="text-xs text-cyan-100 italic bg-[#040918]/70 border border-cyan-500/30 p-3 rounded-xl text-center md:text-left leading-relaxed">
                    {LEADER_MEMBER.quote}
                  </p>
                </div>

              </div>
            </div>
          </div>

          {/* 2. PHÓ NHÓM - VŨ TẠ HỮU LUÂN */}
          <div className="space-y-2">
            <div className="flex items-center gap-2">
              <span className="text-xl">⚔️</span>
              <h3 className="font-serif-title text-sm sm:text-base font-black text-slate-200 uppercase tracking-wider">
                PHÓ NHÓM ĐIỀU HÀNH
              </h3>
            </div>

            <div className={`${VICE_MEMBER.cardBg} rounded-2xl p-4 sm:p-5 relative overflow-hidden transition-all duration-300 hover:shadow-[0_0_30px_rgba(203,213,225,0.25)] group`}>
              <div className="flex flex-col md:flex-row items-center md:items-start gap-4 sm:gap-5 relative z-10">
                
                {/* Avatar with Silver Crest */}
                <div className="relative shrink-0">
                  <div className="absolute -top-3 -left-3 z-20 flex items-center justify-center bg-slate-200 text-slate-950 p-1.5 rounded-full shadow-lg border-2 border-white">
                    <span className="text-base leading-none">⚔️</span>
                  </div>

                  <div className={`w-24 h-24 sm:w-28 sm:h-28 rounded-2xl overflow-hidden bg-[#08020a] p-0.5 ${VICE_MEMBER.accentBorder} transition duration-300 group-hover:scale-105`}>
                    <img 
                      src={VICE_MEMBER.image} 
                      alt={VICE_MEMBER.name} 
                      className="w-full h-full object-cover rounded-[14px]"
                      onError={(e) => {
                        e.currentTarget.src = '/Logo & Thương Hiệu (Brand Logo)/dreamina-2026-07-29-3008-A minimalist stencil-style logo of an oc....png';
                      }}
                    />
                  </div>

                  <div className="absolute -bottom-2 -right-2 w-7 h-7 rounded-lg bg-black/90 p-0.5 border-2 border-slate-300 overflow-hidden shadow-md">
                    <img src={VICE_MEMBER.riderCrest} alt="Crest" className="w-full h-full object-contain" />
                  </div>
                </div>

                {/* Vice Leader Info */}
                <div className="space-y-2.5 flex-grow text-center md:text-left">
                  <div className="flex flex-col sm:flex-row sm:items-center justify-between gap-2">
                    <div>
                      <span className={`inline-flex items-center gap-1 text-[10px] uppercase px-2.5 py-0.5 rounded-full mb-1 ${VICE_MEMBER.badgeStyle}`}>
                        ⚔️ PHÓ NHÓM ĐIỀU HÀNH
                      </span>
                      <h4 className="font-serif-title font-black text-lg sm:text-xl text-white text-pop flex items-center justify-center md:justify-start gap-2">
                        {VICE_MEMBER.name}
                      </h4>
                      <p className="text-xs text-slate-300 font-semibold">
                        Phó nhóm Team NPT
                      </p>
                    </div>

                    <button
                      onClick={() => handleLike(VICE_MEMBER.id, VICE_MEMBER.name)}
                      className="px-3.5 py-1.5 rounded-xl text-xs font-bold bg-[#0a1428] hover:bg-slate-200 hover:text-slate-950 text-slate-200 border border-slate-300 flex items-center justify-center gap-2 shadow-sm transition active:scale-95 shrink-0 self-center sm:self-auto cursor-pointer"
                    >
                      <span>⚔️ Tri ân Phó nhóm</span>
                      <span className="font-mono bg-black/40 px-2 py-0.5 rounded-full text-slate-300 text-[11px]">
                        {likes[VICE_MEMBER.id]}
                      </span>
                    </button>
                  </div>

                  {/* Rider Favorite */}
                  <div className="inline-flex items-center gap-2 bg-[#040916] border border-slate-500/30 px-3 py-1 rounded-xl text-xs text-slate-200">
                    <i className="fa-solid fa-mask text-slate-300"></i>
                    <span>Rider yêu thích: <strong>{VICE_MEMBER.favoriteRider}</strong></span>
                  </div>

                  {/* Quote */}
                  <p className="text-[11px] text-slate-300 italic bg-[#050d1e]/70 border border-slate-400/25 p-2.5 rounded-xl text-center md:text-left leading-relaxed">
                    {VICE_MEMBER.quote}
                  </p>
                </div>

              </div>
            </div>
          </div>

          {/* 3. BAN QUẢN TRỊ & ĐỒNG SÁNG LẬP */}
          <div className="space-y-3">
            <div className="flex items-center justify-between border-b border-cyan-500/30 pb-2">
              <div className="flex items-center gap-2">
                <span className="text-xl">🛡️</span>
                <h3 className="font-serif-title text-sm sm:text-base font-black text-cyan-300 uppercase tracking-wider flex items-center gap-2">
                  <span>BAN QUẢN TRỊ ĐỒNG SÁNG LẬP</span>
                </h3>
              </div>
              <span className="text-[11px] text-slate-300 hidden sm:inline">
                Đồng hành phát triển cộng đồng Tokusatsu
              </span>
            </div>

            <div className="grid grid-cols-1 md:grid-cols-3 gap-4">
              {SOLDIER_MEMBERS.map((member) => (
                <div 
                  key={member.id}
                  className={`${member.cardBg} rounded-2xl p-4 flex flex-col justify-between transition-all duration-300 hover:-translate-y-1 hover:shadow-lg group relative overflow-hidden`}
                >
                  <div className="space-y-3">
                    {/* Header with avatar */}
                    <div className="flex items-center gap-3">
                      <div className="relative shrink-0">
                        <div className="absolute -top-2 -left-2 z-10 w-6 h-6 rounded-full bg-slate-900 border border-cyan-400/50 flex items-center justify-center text-xs shadow">
                          {member.iconSymbol}
                        </div>

                        <div className={`w-16 h-16 rounded-xl overflow-hidden bg-[#08020a] p-0.5 ${member.accentBorder} transition group-hover:scale-105`}>
                          <img 
                            src={member.image} 
                            alt={member.name} 
                            className="w-full h-full object-cover rounded-[10px]"
                            onError={(e) => {
                              e.currentTarget.src = '/Logo & Thương Hiệu (Brand Logo)/dreamina-2026-07-29-3008-A minimalist stencil-style logo of an oc....png';
                            }}
                          />
                        </div>

                        <div className="absolute -bottom-1 -right-1 w-5 h-5 rounded-md bg-black/90 p-0.5 border border-cyan-400/50 overflow-hidden shadow">
                          <img src={member.riderCrest} alt="Crest" className="w-full h-full object-contain" />
                        </div>
                      </div>

                      <div className="min-w-0 flex-grow">
                        <span className={`inline-block text-[9px] font-black uppercase px-2 py-0.5 rounded-full mb-1 ${member.badgeStyle}`}>
                          {member.roleBadge}
                        </span>
                        <h4 className="font-serif-title font-black text-sm text-white group-hover:text-cyan-300 transition truncate text-pop">
                          {member.name}
                        </h4>
                        <p className="text-[11px] text-cyan-200 font-medium truncate">
                          Ban Quản Trị Team NPT
                        </p>
                      </div>
                    </div>

                    {/* Member Quote */}
                    <p className="text-[11px] text-slate-300 italic bg-[#070e1c]/80 p-2.5 rounded-xl border border-cyan-500/20 leading-relaxed">
                      {member.quote}
                    </p>
                  </div>

                  {/* Bottom reaction button */}
                  <div className="pt-3 mt-3 border-t border-cyan-500/20 flex items-center justify-between text-xs">
                    <span className="text-[10px] text-slate-400 truncate">
                      <i className="fa-solid fa-shield-halved text-cyan-400 mr-1"></i>
                      {member.favoriteRider.split('(')[0]}
                    </span>

                    <button
                      onClick={() => handleLike(member.id, member.name)}
                      className="px-2.5 py-1 rounded-lg text-xs font-bold bg-[#07162c] hover:bg-cyan-500/20 text-cyan-300 border border-cyan-500/40 flex items-center gap-1.5 transition active:scale-95 cursor-pointer"
                    >
                      <span>{member.iconSymbol} Tri ân</span>
                      <span className="font-mono text-[10px]">{likes[member.id]}</span>
                    </button>
                  </div>
                </div>
              ))}
            </div>
          </div>

          {/* Bottom Gratitude Banner */}
          <div className="bg-gradient-to-r from-[#071224] via-[#091b38] to-[#071224] border border-cyan-400/40 rounded-2xl p-4 sm:p-5 text-center space-y-2">
            <h4 className="font-serif-title font-black text-sm sm:text-base text-cyan-300 uppercase tracking-widest flex items-center justify-center gap-2">
              <span>ĐỘI NGŨ SÁNG LẬP & BAN ĐIỀU HÀNH TEAM NPT</span>
            </h4>
            <p className="text-xs text-slate-300 max-w-xl mx-auto leading-relaxed">
              Dự án NPTTEAMSTORE là kết tinh của trí tuệ, mồ hôi và lòng say mê Tokusatsu cháy bỏng!
            </p>
            <div className="pt-2 flex flex-wrap items-center justify-center gap-3">
              <button
                onClick={onClose}
                className="px-6 py-2.5 rounded-xl bg-gradient-to-r from-cyan-400 via-blue-500 to-cyan-300 hover:brightness-110 text-black font-extrabold text-xs shadow-lg shadow-cyan-500/20 transition duration-200 cursor-pointer"
              >
                <i className="fa-solid fa-store mr-1.5"></i> Tiếp tục khám phá NPTTEAMSTORE
              </button>
              <button
                onClick={() => {
                  navigator.clipboard.writeText(window.location.origin);
                  if (showToast) showToast('📋 Đã sao chép liên kết chia sẻ website!', 'success');
                }}
                className="px-4 py-2.5 rounded-xl bg-[#081224] hover:bg-[#0c1c38] text-slate-200 border border-cyan-500/30 hover:border-cyan-400 text-xs font-bold transition duration-200 cursor-pointer"
              >
                <i className="fa-solid fa-share-nodes mr-1.5"></i> Lan tỏa website
              </button>
            </div>
          </div>

        </div>

      </div>
    </div>
  );
};
