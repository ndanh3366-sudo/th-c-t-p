import {StrictMode} from 'react';
import {createRoot} from 'react-dom/client';
import App from './App.tsx';
import './index.css';
import { registerSW } from 'virtual:pwa-register';

// Initialize PWA Service Worker for offline caching and fast reload
registerSW({
  immediate: true,
  onNeedRefresh() {
    console.log('[NPTSTORE PWA] New update available');
  },
  onOfflineReady() {
    console.log('[NPTSTORE PWA] App is ready for 100% offline usage');
  },
});

createRoot(document.getElementById('root')!).render(
  <StrictMode>
    <App />
  </StrictMode>,
);
