/**
 * Live Product WebGL & Canvas AR Filter Pipeline
 * Supports 10 customized filters for live streaming & interactive shopping:
 * 1. Làm đẹp: Mịn da (Smooth Skin)
 * 2. Làm đẹp: Sáng da (Bright & Glow)
 * 3. Làm đẹp: Thon mặt (V-Line Slim)
 * 4. Vui nhộn: Tai mèo/thỏ (Bunny & Cat Ears)
 * 5. Vui nhộn: Kính râm cực ngầu (Cyber Sunglasses)
 * 6. Vui nhộn: Hoạt hình Cyberpunk (Cyberpunk Neon Glitch)
 * 7. Vui nhộn: Hiệu ứng Vintage (Vintage Retro 35mm)
 * 8. Tương tác sản phẩm: Thử son môi (Virtual AR Lipstick)
 * 9. Tương tác sản phẩm: Thử kính mắt thời trang (Designer Glasses)
 * 10. Tương tác sản phẩm: Thả tim & Lấp lánh khi chốt đơn (Heart & Sparkle Burst)
 */

import { LiveFilterType } from '../types';

export interface Particle {
  x: number;
  y: number;
  vx: number;
  vy: number;
  size: number;
  alpha: number;
  type: 'heart' | 'sparkle' | 'diamond';
  color: string;
}

export class LiveFilterProcessor {
  private canvas: HTMLCanvasElement;
  private ctx: CanvasRenderingContext2D;
  private particles: Particle[] = [];
  private animationId: number | null = null;
  private currentFilter: LiveFilterType = 'none';
  private frameCount = 0;

  constructor(canvas: HTMLCanvasElement) {
    this.canvas = canvas;
    this.ctx = canvas.getContext('2d', { willReadFrequently: true })!;
  }

  public setFilter(filter: LiveFilterType) {
    this.currentFilter = filter;
    if (filter === 'heart-sparkle-burst') {
      this.spawnBurst(25);
    }
  }

  public spawnBurst(count = 15) {
    const width = this.canvas.width;
    const height = this.canvas.height;
    const types: Particle['type'][] = ['heart', 'sparkle', 'diamond'];
    const colors = ['#f43f5e', '#ec4899', '#fbbf24', '#00f5d4', '#38bdf8'];

    for (let i = 0; i < count; i++) {
      this.particles.push({
        x: width * 0.2 + Math.random() * (width * 0.6),
        y: height - 20 - Math.random() * 50,
        vx: (Math.random() - 0.5) * 4,
        vy: -(Math.random() * 4 + 3),
        size: Math.random() * 18 + 14,
        alpha: 1,
        type: types[Math.floor(Math.random() * types.length)],
        color: colors[Math.floor(Math.random() * colors.length)],
      });
    }
  }

  public render(source: CanvasImageSource | null) {
    const { width, height } = this.canvas;
    if (width === 0 || height === 0) return;
    this.frameCount++;

    const ctx = this.ctx;

    // 1. Transparent canvas clearing & filter preparation
    if (this.currentFilter === 'none') {
      ctx.clearRect(0, 0, width, height);
    } else if (source) {
      try {
        ctx.save();
        ctx.drawImage(source, 0, 0, width, height);
        ctx.restore();
      } catch {
        ctx.clearRect(0, 0, width, height);
      }
    } else {
      ctx.clearRect(0, 0, width, height);
    }

    // 2. Apply chosen filter
    switch (this.currentFilter) {
      case 'smooth-skin':
        this.applySmoothSkin(ctx, width, height);
        break;
      case 'bright-glow':
        this.applyBrightGlow(ctx, width, height);
        break;
      case 'v-line-slim':
        this.applyVLineSlim(ctx, width, height);
        break;
      case 'bunny-cat-ears':
        this.applyBunnyCatEars(ctx, width, height);
        break;
      case 'cyber-sunglasses':
        this.applyCyberSunglasses(ctx, width, height);
        break;
      case 'cyberpunk-glitch':
        this.applyCyberpunkGlitch(ctx, width, height);
        break;
      case 'vintage-retro':
        this.applyVintageRetro(ctx, width, height);
        break;
      case 'virtual-lipstick':
        this.applyVirtualLipstick(ctx, width, height);
        break;
      case 'designer-glasses':
        this.applyDesignerGlasses(ctx, width, height);
        break;
      case 'heart-sparkle-burst':
        // Continual slight bubbling + rendered particles
        if (this.frameCount % 8 === 0) {
          this.spawnBurst(2);
        }
        break;
      default:
        break;
    }

    // 3. Always render any active floating particles
    this.renderParticles(ctx, width, height);
  }

  // Filter 1: Mịn da (Smooth Skin)
  private applySmoothSkin(ctx: CanvasRenderingContext2D, width: number, height: number) {
    ctx.save();
    ctx.globalCompositeOperation = 'screen';
    ctx.filter = 'blur(6px) brightness(1.05) contrast(0.95)';
    ctx.globalAlpha = 0.35;
    ctx.drawImage(this.canvas, 0, 0, width, height);
    ctx.restore();

    // Soft warm tint
    ctx.save();
    ctx.fillStyle = 'rgba(255, 235, 220, 0.08)';
    ctx.fillRect(0, 0, width, height);
    ctx.restore();
  }

  // Filter 2: Sáng da (Bright & Glow)
  private applyBrightGlow(ctx: CanvasRenderingContext2D, width: number, height: number) {
    ctx.save();
    ctx.globalCompositeOperation = 'overlay';
    ctx.globalAlpha = 0.3;
    const grad = ctx.createRadialGradient(width / 2, height / 2, 50, width / 2, height / 2, width * 0.7);
    grad.addColorStop(0, 'rgba(255, 255, 255, 0.45)');
    grad.addColorStop(0.5, 'rgba(255, 240, 210, 0.2)');
    grad.addColorStop(1, 'rgba(255, 200, 150, 0)');
    ctx.fillStyle = grad;
    ctx.fillRect(0, 0, width, height);
    ctx.restore();

    // Radiant skin light
    ctx.save();
    ctx.globalCompositeOperation = 'soft-light';
    ctx.fillStyle = 'rgba(255, 248, 230, 0.25)';
    ctx.fillRect(0, 0, width, height);
    ctx.restore();
  }

  // Filter 3: Thon mặt (V-Line Slim Contour)
  private applyVLineSlim(ctx: CanvasRenderingContext2D, width: number, height: number) {
    ctx.save();
    // Contour shadowing at the lower jawline
    const leftContour = ctx.createLinearGradient(0, height * 0.5, width * 0.3, height);
    leftContour.addColorStop(0, 'rgba(30, 15, 10, 0)');
    leftContour.addColorStop(1, 'rgba(20, 10, 8, 0.45)');
    ctx.fillStyle = leftContour;
    ctx.beginPath();
    ctx.moveTo(0, height * 0.4);
    ctx.lineTo(width * 0.35, height);
    ctx.lineTo(0, height);
    ctx.closePath();
    ctx.fill();

    const rightContour = ctx.createLinearGradient(width, height * 0.5, width * 0.7, height);
    rightContour.addColorStop(0, 'rgba(30, 15, 10, 0)');
    rightContour.addColorStop(1, 'rgba(20, 10, 8, 0.45)');
    ctx.fillStyle = rightContour;
    ctx.beginPath();
    ctx.moveTo(width, height * 0.4);
    ctx.lineTo(width * 0.65, height);
    ctx.lineTo(width, height);
    ctx.closePath();
    ctx.fill();

    // V-Line chin highlight
    ctx.globalCompositeOperation = 'soft-light';
    ctx.fillStyle = 'rgba(255, 255, 255, 0.35)';
    ctx.beginPath();
    ctx.ellipse(width * 0.5, height * 0.82, 35, 18, 0, 0, Math.PI * 2);
    ctx.fill();
    ctx.restore();
  }

  // Filter 4: Tai mèo / Tai thỏ (Bunny & Cat Ears)
  private applyBunnyCatEars(ctx: CanvasRenderingContext2D, width: number, height: number) {
    const cx = width / 2;
    const earY = height * 0.22;
    const earDistance = width * 0.24;
    const earHeight = height * 0.18;
    const earWidth = width * 0.09;
    const wiggle = Math.sin(this.frameCount * 0.08) * 4;

    ctx.save();
    // Left ear
    ctx.save();
    ctx.translate(cx - earDistance, earY);
    ctx.rotate((-12 + wiggle) * (Math.PI / 180));
    this.drawCuteEar(ctx, earWidth, earHeight);
    ctx.restore();

    // Right ear
    ctx.save();
    ctx.translate(cx + earDistance, earY);
    ctx.rotate((12 - wiggle) * (Math.PI / 180));
    this.drawCuteEar(ctx, earWidth, earHeight);
    ctx.restore();

    // Cute rosy cheeks blush
    ctx.globalAlpha = 0.45;
    ctx.fillStyle = '#ff6b8b';
    ctx.beginPath();
    ctx.ellipse(cx - width * 0.22, height * 0.58, 22, 14, 0, 0, Math.PI * 2);
    ctx.fill();
    ctx.beginPath();
    ctx.ellipse(cx + width * 0.22, height * 0.58, 22, 14, 0, 0, Math.PI * 2);
    ctx.fill();

    // Cat whiskers
    ctx.strokeStyle = 'rgba(255, 255, 255, 0.7)';
    ctx.lineWidth = 2.5;
    ctx.lineCap = 'round';
    // left
    ctx.beginPath();
    ctx.moveTo(cx - width * 0.18, height * 0.62);
    ctx.lineTo(cx - width * 0.32, height * 0.59);
    ctx.moveTo(cx - width * 0.18, height * 0.65);
    ctx.lineTo(cx - width * 0.33, height * 0.66);
    ctx.stroke();
    // right
    ctx.beginPath();
    ctx.moveTo(cx + width * 0.18, height * 0.62);
    ctx.lineTo(cx + width * 0.32, height * 0.59);
    ctx.moveTo(cx + width * 0.18, height * 0.65);
    ctx.lineTo(cx + width * 0.33, height * 0.66);
    ctx.stroke();

    ctx.restore();
  }

  private drawCuteEar(ctx: CanvasRenderingContext2D, w: number, h: number) {
    // Outer white/pink ear
    ctx.fillStyle = '#ffffff';
    ctx.strokeStyle = '#f472b6';
    ctx.lineWidth = 3;
    ctx.beginPath();
    ctx.moveTo(0, 0);
    ctx.quadraticCurveTo(-w * 0.8, -h * 0.6, -w * 0.2, -h);
    ctx.quadraticCurveTo(0, -h * 1.05, w * 0.2, -h);
    ctx.quadraticCurveTo(w * 0.8, -h * 0.6, 0, 0);
    ctx.closePath();
    ctx.fill();
    ctx.stroke();

    // Inner pink ear
    ctx.fillStyle = '#f472b6';
    ctx.beginPath();
    ctx.moveTo(0, -h * 0.15);
    ctx.quadraticCurveTo(-w * 0.5, -h * 0.6, 0, -h * 0.85);
    ctx.quadraticCurveTo(w * 0.5, -h * 0.6, 0, -h * 0.15);
    ctx.closePath();
    ctx.fill();
  }

  // Filter 5: Kính râm cực ngầu (Cyber Sunglasses)
  private applyCyberSunglasses(ctx: CanvasRenderingContext2D, width: number, height: number) {
    const cx = width / 2;
    const cy = height * 0.44;
    const glassW = width * 0.21;
    const glassH = height * 0.09;
    const gap = width * 0.04;

    ctx.save();
    // Frame
    ctx.fillStyle = 'rgba(10, 10, 15, 0.96)';
    ctx.strokeStyle = '#00f5d4';
    ctx.lineWidth = 3.5;
    ctx.shadowColor = '#00f5d4';
    ctx.shadowBlur = 12;

    // Left lens
    ctx.beginPath();
    ctx.roundRect(cx - gap / 2 - glassW, cy - glassH / 2, glassW, glassH, [8, 8, 20, 20]);
    ctx.fill();
    ctx.stroke();

    // Right lens
    ctx.beginPath();
    ctx.roundRect(cx + gap / 2, cy - glassH / 2, glassW, glassH, [8, 8, 20, 20]);
    ctx.fill();
    ctx.stroke();

    // Bridge
    ctx.beginPath();
    ctx.moveTo(cx - gap / 2, cy - glassH * 0.1);
    ctx.lineTo(cx + gap / 2, cy - glassH * 0.1);
    ctx.stroke();

    // Neon reflection stripes across sunglasses
    ctx.strokeStyle = 'rgba(0, 245, 212, 0.65)';
    ctx.lineWidth = 2;
    ctx.beginPath();
    ctx.moveTo(cx - gap / 2 - glassW + 10, cy - glassH * 0.2);
    ctx.lineTo(cx - gap / 2 - 15, cy + glassH * 0.2);
    ctx.moveTo(cx + gap / 2 + 15, cy - glassH * 0.2);
    ctx.lineTo(cx + gap / 2 + glassW - 10, cy + glassH * 0.2);
    ctx.stroke();

    ctx.restore();
  }

  // Filter 6: Hoạt hình Cyberpunk (Cyberpunk Neon Glitch)
  private applyCyberpunkGlitch(ctx: CanvasRenderingContext2D, width: number, height: number) {
    ctx.save();
    // Scanlines
    ctx.fillStyle = 'rgba(0, 255, 255, 0.05)';
    for (let y = 0; y < height; y += 4) {
      ctx.fillRect(0, y, width, 1.5);
    }

    // Occasional horizontal chromatic shift slice
    if (this.frameCount % 12 < 4) {
      const sliceY = (Math.sin(this.frameCount) * 0.5 + 0.5) * height;
      const sliceH = 25;
      ctx.fillStyle = 'rgba(255, 0, 128, 0.35)';
      ctx.fillRect(0, sliceY, width, sliceH);
    }

    // Neon HUD border & crosshair
    ctx.strokeStyle = '#00f5d4';
    ctx.lineWidth = 2;
    ctx.strokeRect(16, 16, width - 32, height - 32);

    // Corner brackets
    const bLen = 28;
    ctx.lineWidth = 4;
    // Top-left
    ctx.beginPath();
    ctx.moveTo(16, 16 + bLen);
    ctx.lineTo(16, 16);
    ctx.lineTo(16 + bLen, 16);
    ctx.stroke();
    // Top-right
    ctx.beginPath();
    ctx.moveTo(width - 16 - bLen, 16);
    ctx.lineTo(width - 16, 16);
    ctx.lineTo(width - 16, 16 + bLen);
    ctx.stroke();

    // HUD Tech Data
    ctx.font = 'bold 11px monospace';
    ctx.fillStyle = '#00f5d4';
    ctx.fillText('LIVEKIT SVC // 1080P 60FPS // HENSHIN SYSTEM LOCKED', 28, 36);
    ctx.fillStyle = '#f43f5e';
    ctx.fillText('● REC // TARGET ENGAGED', width - 200, 36);

    ctx.restore();
  }

  // Filter 7: Vintage Retro (Retro 35mm Film)
  private applyVintageRetro(ctx: CanvasRenderingContext2D, width: number, height: number) {
    ctx.save();
    // Sepia / warm amber wash
    ctx.fillStyle = 'rgba(180, 110, 45, 0.18)';
    ctx.fillRect(0, 0, width, height);

    // Dark film vignette
    const vig = ctx.createRadialGradient(width / 2, height / 2, width * 0.3, width / 2, height / 2, width * 0.75);
    vig.addColorStop(0, 'rgba(0, 0, 0, 0)');
    vig.addColorStop(1, 'rgba(15, 8, 4, 0.65)');
    ctx.fillStyle = vig;
    ctx.fillRect(0, 0, width, height);

    // Film timestamp
    ctx.font = 'bold 15px "Courier New", monospace';
    ctx.fillStyle = '#fbbf24';
    ctx.shadowColor = '#000000';
    ctx.shadowBlur = 4;
    const now = new Date();
    const dateStr = `OCT 24 2026  ${now.toTimeString().split(' ')[0]}`;
    ctx.fillText(dateStr, width - 220, height - 24);

    ctx.restore();
  }

  // Filter 8: Thử son môi (Virtual AR Lipstick)
  private applyVirtualLipstick(ctx: CanvasRenderingContext2D, width: number, height: number) {
    const cx = width / 2;
    const cy = height * 0.66;
    const lipW = width * 0.13;
    const lipH = height * 0.045;

    ctx.save();
    ctx.globalCompositeOperation = 'source-over';
    // Subtle ruby red lip tint
    ctx.fillStyle = 'rgba(225, 29, 72, 0.42)';
    ctx.filter = 'blur(4px)';

    // Upper lip
    ctx.beginPath();
    ctx.ellipse(cx, cy - lipH * 0.3, lipW * 0.8, lipH * 0.5, 0, 0, Math.PI * 2);
    ctx.fill();

    // Lower lip
    ctx.beginPath();
    ctx.ellipse(cx, cy + lipH * 0.3, lipW, lipH * 0.65, 0, 0, Math.PI * 2);
    ctx.fill();

    // Gloss shine
    ctx.filter = 'none';
    ctx.fillStyle = 'rgba(255, 255, 255, 0.45)';
    ctx.beginPath();
    ctx.ellipse(cx, cy + lipH * 0.25, lipW * 0.4, 3, 0, 0, Math.PI * 2);
    ctx.fill();

    // AR Label
    ctx.font = 'bold 10px sans-serif';
    ctx.fillStyle = '#fda4af';
    ctx.fillText('💄 AR Lipstick: Ruby Red #08 (Bandai Edition)', cx - 90, cy + lipH + 18);

    ctx.restore();
  }

  // Filter 9: Thử kính mắt thời trang (Designer Eyewear)
  private applyDesignerGlasses(ctx: CanvasRenderingContext2D, width: number, height: number) {
    const cx = width / 2;
    const cy = height * 0.45;
    const r = width * 0.085;
    const dist = width * 0.12;

    ctx.save();
    // Golden wire round spectacles
    ctx.strokeStyle = '#f59e0b';
    ctx.lineWidth = 3;
    ctx.fillStyle = 'rgba(245, 158, 11, 0.12)';

    // Left round lens
    ctx.beginPath();
    ctx.arc(cx - dist, cy, r, 0, Math.PI * 2);
    ctx.fill();
    ctx.stroke();

    // Right round lens
    ctx.beginPath();
    ctx.arc(cx + dist, cy, r, 0, Math.PI * 2);
    ctx.fill();
    ctx.stroke();

    // Nose bridge
    ctx.beginPath();
    ctx.arc(cx, cy - 8, dist - r, Math.PI, 0, false);
    ctx.stroke();

    // Temples (arms)
    ctx.beginPath();
    ctx.moveTo(cx - dist - r, cy);
    ctx.lineTo(cx - dist - r - 25, cy - 8);
    ctx.moveTo(cx + dist + r, cy);
    ctx.lineTo(cx + dist + r + 25, cy - 8);
    ctx.stroke();

    // AR label
    ctx.font = 'bold 10px sans-serif';
    ctx.fillStyle = '#fbbf24';
    ctx.fillText('👓 AR Specs: Classic Gold Edition', cx - 75, cy - r - 10);

    ctx.restore();
  }

  // Filter 10 Particle System (Thả tim & Lấp lánh khi chốt đơn)
  private renderParticles(ctx: CanvasRenderingContext2D, width: number, height: number) {
    for (let i = this.particles.length - 1; i >= 0; i--) {
      const p = this.particles[i];
      p.x += p.vx;
      p.y += p.vy;
      p.alpha -= 0.012;

      if (p.alpha <= 0 || p.y < -30) {
        this.particles.splice(i, 1);
        continue;
      }

      ctx.save();
      ctx.globalAlpha = Math.max(0, p.alpha);

      if (p.type === 'heart') {
        this.drawHeart(ctx, p.x, p.y, p.size, p.color);
      } else if (p.type === 'diamond') {
        this.drawDiamond(ctx, p.x, p.y, p.size, p.color);
      } else {
        this.drawStar(ctx, p.x, p.y, p.size, p.color);
      }

      ctx.restore();
    }
  }

  private drawHeart(ctx: CanvasRenderingContext2D, x: number, y: number, size: number, color: string) {
    ctx.fillStyle = color;
    ctx.beginPath();
    const topCurveHeight = size * 0.3;
    ctx.moveTo(x, y + topCurveHeight);
    // Top left curve
    ctx.bezierCurveTo(x, y, x - size / 2, y, x - size / 2, y + topCurveHeight);
    // Bottom left curve
    ctx.bezierCurveTo(x - size / 2, y + (size + topCurveHeight) / 2, x, y + (size + topCurveHeight) / 2, x, y + size);
    // Bottom right curve
    ctx.bezierCurveTo(x, y + (size + topCurveHeight) / 2, x + size / 2, y + (size + topCurveHeight) / 2, x + size / 2, y + topCurveHeight);
    // Top right curve
    ctx.bezierCurveTo(x + size / 2, y, x, y, x, y + topCurveHeight);
    ctx.closePath();
    ctx.fill();
  }

  private drawDiamond(ctx: CanvasRenderingContext2D, x: number, y: number, size: number, color: string) {
    ctx.fillStyle = color;
    ctx.beginPath();
    ctx.moveTo(x, y - size / 2);
    ctx.lineTo(x + size / 2, y);
    ctx.lineTo(x, y + size / 2);
    ctx.lineTo(x - size / 2, y);
    ctx.closePath();
    ctx.fill();
  }

  private drawStar(ctx: CanvasRenderingContext2D, cx: number, cy: number, size: number, color: string) {
    ctx.fillStyle = color;
    ctx.beginPath();
    const spikes = 5;
    const outerRadius = size / 2;
    const innerRadius = outerRadius / 2;
    let rot = (Math.PI / 2) * 3;
    let x = cx;
    let y = cy;
    const step = Math.PI / spikes;

    ctx.moveTo(cx, cy - outerRadius);
    for (let i = 0; i < spikes; i++) {
      x = cx + Math.cos(rot) * outerRadius;
      y = cy + Math.sin(rot) * outerRadius;
      ctx.lineTo(x, y);
      rot += step;

      x = cx + Math.cos(rot) * innerRadius;
      y = cy + Math.sin(rot) * innerRadius;
      ctx.lineTo(x, y);
      rot += step;
    }
    ctx.lineTo(cx, cy - outerRadius);
    ctx.closePath();
    ctx.fill();
  }

  public destroy() {
    if (this.animationId) {
      cancelAnimationFrame(this.animationId);
      this.animationId = null;
    }
    this.particles = [];
  }
}
