import React, { useState } from 'react';
import { AuctionItem, User } from '../types';

interface AuctionViewProps {
  auctions: AuctionItem[];
  currentUser: User | null;
  onPlaceBid: (auctionId: string, amount: number, bidderName: string) => void;
  showToast: (msg: string, type?: 'success' | 'error' | 'info') => void;
}

export const AuctionView: React.FC<AuctionViewProps> = ({
  auctions,
  currentUser,
  onPlaceBid,
  showToast
}) => {
  const [selectedAuction, setSelectedAuction] = useState<AuctionItem>(auctions[0]);
  const [bidInput, setBidInput] = useState<number>(selectedAuction ? selectedAuction.currentBid + 200000 : 0);

  if (!selectedAuction) return null;

  const minNextBid = selectedAuction.currentBid + 100000;

  const handleBidSubmit = (e: React.FormEvent) => {
    e.preventDefault();
    if (!currentUser) {
      showToast('⚠️ Vui lòng đăng nhập trước khi đặt giá đấu giá!', 'error');
      return;
    }
    if (bidInput < minNextBid) {
      showToast(`⚠️ Mức giá đấu tối thiểu tiếp theo phải từ ${minNextBid.toLocaleString('vi-VN')}đ!`, 'error');
      return;
    }

    onPlaceBid(selectedAuction.id, bidInput, currentUser.name);
    selectedAuction.currentBid = bidInput;
    selectedAuction.highestBidder = currentUser.name;
    selectedAuction.bidCount += 1;
    selectedAuction.bidHistory.unshift({
      bidderName: currentUser.name,
      amount: bidInput,
      time: new Date().toLocaleTimeString('vi-VN', { hour: '2-digit', minute: '2-digit' }) + ' - Hôm nay'
    });

    setBidInput(bidInput + 200000);
    showToast(`🎉 Đặt giá thành công! Bạn đang giữ mức giá cao nhất ${bidInput.toLocaleString('vi-VN')}đ!`, 'success');
  };

  return (
    <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 py-8 space-y-10 text-[#F5F2EB]">
      {/* Header */}
      <div className="border-b border-[#2A2A2A] pb-6">
        <span className="inline-block bg-[#8B1E1E] text-white text-[10px] font-black px-3 py-1 rounded-full uppercase tracking-wider mb-2">
          🔥 Live Collector Auction
        </span>
        <h2 className="font-serif-title text-2xl sm:text-3xl font-black">
          Đấu Giá Đồ Chơi <span className="gold-gradient-text">RIDER HÀNG HIẾM & GIỚI HẠN</span>
        </h2>
        <p className="text-xs text-gray-400 mt-1">Săn các bản đai CSM mạ vàng, bản đai kèm chữ ký diễn viên và SHF sản xuất giới hạn</p>
      </div>

      {/* Active Auction Showcase */}
      <div className="grid grid-cols-1 lg:grid-cols-12 gap-8 items-start">
        {/* Left Visuals */}
        <div className="lg:col-span-6 space-y-4">
          <div className="relative aspect-video bg-[#0D0D0D] border border-[#2A2A2A] rounded-3xl overflow-hidden flex items-center justify-center p-3">
            <img src={selectedAuction.image} alt="" className="w-full h-full object-contain" onError={(e) => { e.currentTarget.src = '/Sản Phẩm Đấu Giá Hoàng Gia/DX Don Onitaijin Gold Mekki Version.jpg'; }} />
            <div className="absolute top-4 left-4 bg-[#8B1E1E] text-white text-[10px] font-extrabold px-3 py-1 rounded-full uppercase">
              ● Đang Đấu Giá Trực Tiếp
            </div>
          </div>

          {/* Other Auction Cards Selector */}
          <div className="grid grid-cols-2 gap-3">
            {auctions.map(a => (
              <div 
                key={a.id}
                onClick={() => {
                  setSelectedAuction(a);
                  setBidInput(a.currentBid + 200000);
                }}
                className={`p-3 rounded-2xl border cursor-pointer transition flex items-center gap-3 ${
                  selectedAuction.id === a.id ? 'bg-[#1A1A1A] border-[#C9A84C]' : 'bg-[#0D0D0D] border-[#2A2A2A] opacity-70 hover:opacity-100'
                }`}
              >
                <img src={a.image} alt="" className="w-12 h-12 rounded-xl object-contain p-1 bg-black border border-[#2A2A2A]" onError={(e) => { e.currentTarget.src = '/Sản Phẩm Đấu Giá Hoàng Gia/DX Don Onitaijin Gold Mekki Version.jpg'; }} />
                <div className="min-w-0">
                  <h4 className="font-bold text-[11px] text-[#F5F2EB] truncate">{a.productName}</h4>
                  <p className="text-[10px] text-[#C9A84C] font-mono font-bold">{a.currentBid.toLocaleString('vi-VN')}đ</p>
                </div>
              </div>
            ))}
          </div>
        </div>

        {/* Right Bidding Panel */}
        <div className="lg:col-span-6 bg-[#1A1A1A] border border-[#2A2A2A] p-6 sm:p-8 rounded-3xl space-y-6 text-xs">
          <div>
            <span className="text-[10px] text-[#C9A84C] font-bold uppercase block">{selectedAuction.era} Era • {selectedAuction.condition}</span>
            <h3 className="font-serif-title text-xl font-bold text-[#F5F2EB] leading-tight mt-1">
              {selectedAuction.productName}
            </h3>
            <p className="text-gray-400 text-xs mt-2 leading-relaxed">{selectedAuction.description}</p>
          </div>

          {/* Current Highest Bid Box */}
          <div className="bg-[#0D0D0D] border border-[#C9A84C]/40 p-5 rounded-2xl space-y-2">
            <div className="flex justify-between items-center text-[10px] text-gray-400 uppercase font-bold">
              <span>Giá Hiện Tại Cao Nhất</span>
              <span className="text-emerald-400">Lượt đấu: {selectedAuction.bidCount}</span>
            </div>
            <div className="flex items-baseline gap-2">
              <span className="text-3xl font-black text-[#C9A84C] font-mono">
                {selectedAuction.currentBid.toLocaleString('vi-VN')}đ
              </span>
            </div>
            <p className="text-[11px] text-gray-300">
              Người giữ giá cao nhất: <strong className="text-white font-bold">{selectedAuction.highestBidder}</strong>
            </p>
          </div>

          {/* Place Bid Form */}
          <form onSubmit={handleBidSubmit} className="space-y-3">
            <label className="block font-bold text-gray-400 uppercase text-[10px]">
              Nhập Mức Giá Đấu Của Bạn (Tối thiểu {minNextBid.toLocaleString('vi-VN')}đ)
            </label>
            <div className="flex gap-2">
              <input 
                type="number" 
                min={minNextBid}
                step={50000}
                value={bidInput}
                onChange={(e) => setBidInput(Number(e.target.value))}
                className="flex-grow bg-[#0D0D0D] border border-[#2A2A2A] rounded-xl px-4 py-3 text-sm font-mono text-white focus:outline-none focus:border-[#C9A84C]"
              />
              <button 
                type="submit"
                className="px-6 py-3 bg-gradient-to-r from-[#C9A84C] to-[#a27e2a] text-[#0A0A0A] font-extrabold text-xs rounded-xl shadow-lg hover:brightness-110 whitespace-nowrap"
              >
                Đặt Giá Ngay
              </button>
            </div>
          </form>

          {/* Bid History Table */}
          <div className="space-y-2 border-t border-[#2A2A2A] pt-4">
            <h4 className="font-bold text-xs uppercase tracking-wider text-gray-400">Lịch Sử Đặt Giá</h4>
            <div className="space-y-1.5 max-h-32 overflow-y-auto no-scrollbar">
              {selectedAuction.bidHistory.map((bh, idx) => (
                <div key={idx} className="bg-[#0D0D0D] p-2.5 rounded-xl flex justify-between items-center text-[11px]">
                  <span className="font-bold text-gray-300">{bh.bidderName}</span>
                  <span className="font-mono text-[#C9A84C] font-bold">{bh.amount.toLocaleString('vi-VN')}đ</span>
                  <span className="text-gray-500 text-[10px]">{bh.time}</span>
                </div>
              ))}
            </div>
          </div>
        </div>
      </div>
    </div>
  );
};
