import React, { useState } from 'react';
import { Product, EraType } from '../types';
import { ProductCard } from '../components/ProductCard';

interface CollectionsViewProps {
  products: Product[];
  onSelectProduct: (p: Product) => void;
  onAddToCart: (p: Product, e: React.MouseEvent) => void;
}

export const CollectionsView: React.FC<CollectionsViewProps> = ({
  products,
  onSelectProduct,
  onAddToCart
}) => {
  const [activeEra, setActiveEra] = useState<EraType>('Reiwa');

  const eras = [
    {
      id: 'Reiwa' as EraType,
      title: 'Kỷ Nguyên Reiwa (2019 - Hiện Tại)',
      subtitle: 'Zero-One, Saber, Revice, Geats, Gotchard & Gavv',
      desc: 'Thời đại của sự đột phá công nghệ, đai biến hình đa dạng cơ chế từ cảm ứng NFC, thẻ Ride Chemy Cards đến nhai kẹo Gochizo kịch tính.',
      bg: 'from-[#8B1E1E]/20 to-[#1A1A1A]'
    },
    {
      id: 'Heisei' as EraType,
      title: 'Kỷ Nguyên Heisei (2000 - 2019)',
      subtitle: 'Từ Kuuga đến Zi-O • Thời Hoàng Kim Của Tokusatsu',
      desc: 'Kỷ nguyên gắn liền với tuổi thơ của hàng triệu Collector Việt Nam: Faiz 555, Kabuto Clock Up, Decade Rider Cards, W Gaia Memory và Build Fullbottle.',
      bg: 'from-[#C9A84C]/20 to-[#1A1A1A]'
    },
    {
      id: 'Showa' as EraType,
      title: 'Kỷ Nguyên Showa (1971 - 1989)',
      subtitle: 'Huyền Thoại Khởi Đầu • Ichigo, V3, Black, Black RX',
      desc: 'Những chiến binh huyền thoại tiên phong cho văn hóa Kamen Rider toàn cầu. Nổi bật với đai biến hình Century King Sun Driver.',
      bg: 'from-[#222222] to-[#1A1A1A]'
    }
  ];

  const eraInfo = eras.find(e => e.id === activeEra)!;
  const eraProducts = products.filter(p => p.era === activeEra);

  return (
    <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 py-8 space-y-10 text-[#F5F2EB]">
      {/* Header */}
      <div className="border-b border-[#2A2A2A] pb-6">
        <h2 className="font-serif-title text-2xl sm:text-3xl font-black">
          Bộ Sưu Tập Theo <span className="gold-gradient-text">KỶ NGUYÊN KAMEN RIDER</span>
        </h2>
        <p className="text-xs text-gray-400 mt-1">Hành trình trải dài qua hơn 50 năm lịch sử Tokusatsu từ Showa, Heisei đến Reiwa</p>
      </div>

      {/* Era Tabs */}
      <div className="grid grid-cols-1 sm:grid-cols-3 gap-4">
        {eras.map(e => (
          <button
            key={e.id}
            onClick={() => setActiveEra(e.id)}
            className={`p-5 rounded-3xl border text-left transition duration-300 ${
              activeEra === e.id
                ? 'bg-gradient-to-r from-[#1A1A1A] via-[#222222] to-[#1A1A1A] border-[#C9A84C] shadow-xl'
                : 'bg-[#0D0D0D] border-[#2A2A2A] text-gray-400 hover:border-gray-500'
            }`}
          >
            <span className={`text-[10px] font-bold uppercase tracking-wider block ${activeEra === e.id ? 'text-[#C9A84C]' : 'text-gray-500'}`}>
              Kỷ Nguyên {e.id}
            </span>
            <h3 className="font-serif-title text-base font-bold text-[#F5F2EB] mt-1">{e.title}</h3>
          </button>
        ))}
      </div>

      {/* Selected Era Banner */}
      <div className={`bg-gradient-to-r ${eraInfo.bg} border border-[#2A2A2A] rounded-3xl p-6 sm:p-10 space-y-3 shadow-2xl`}>
        <span className="bg-[#C9A84C] text-[#0A0A0A] font-extrabold text-[10px] px-3 py-1 rounded-full uppercase">
          {eraInfo.id} Era Highlight Collection
        </span>
        <h3 className="font-serif-title text-2xl sm:text-3xl font-black text-[#F5F2EB]">
          {eraInfo.title}
        </h3>
        <p className="text-xs sm:text-sm text-gray-300 leading-relaxed max-w-3xl">
          {eraInfo.desc}
        </p>
      </div>

      {/* Era Products Grid */}
      <div className="space-y-6">
        <h4 className="font-serif-title text-xl font-bold">
          Sản Phẩm Thuộc Kỷ Nguyên {activeEra}
        </h4>

        <div className="grid grid-cols-2 sm:grid-cols-4 gap-3.5 sm:gap-4">
          {eraProducts.map(p => (
            <ProductCard 
              key={p.id}
              product={p}
              onSelect={onSelectProduct}
              onAddToCart={onAddToCart}
            />
          ))}
        </div>
      </div>
    </div>
  );
};
