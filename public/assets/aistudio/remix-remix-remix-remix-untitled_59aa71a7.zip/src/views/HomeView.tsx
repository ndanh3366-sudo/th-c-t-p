import React, { useState } from 'react';
import { HeroSlider } from '../components/HeroSlider';
import { ProductCard } from '../components/ProductCard';
import { PosterCard } from '../components/PosterCard';
import { PosterDetailModal } from '../components/PosterDetailModal';
import { POSTER_ITEMS, PosterItem, posterToProduct } from '../data/posters';
import { Product, BlogPost } from '../types';

interface HomeViewProps {
  products: Product[];
  blogs: BlogPost[];
  onSelectProduct: (p: Product) => void;
  onAddToCart: (p: Product, e: React.MouseEvent) => void;
  setActiveTab: (tab: string) => void;
  showToast: (msg: string, type?: 'success' | 'error' | 'info') => void;
  wishlistIds?: string[];
  onToggleFavorite?: (p: Product, e?: React.MouseEvent) => void;
  onAddToCompare?: (p: Product, e?: React.MouseEvent) => void;
  onSelectBlog?: (b: BlogPost) => void;
}

export const HomeView: React.FC<HomeViewProps> = ({
  products,
  blogs,
  onSelectProduct,
  onAddToCart,
  setActiveTab,
  showToast,
  wishlistIds = [],
  onToggleFavorite,
  onAddToCompare,
  onSelectBlog
}) => {
  const [selectedFilter, setSelectedTabFilter] = useState<'all' | 'dx-belt' | 'csm' | 'shf' | 'shf-premium' | 'weapon' | 'super-sentai' | 'item-card'>('all');
  const [selectedEra, setSelectedEra] = useState<'all' | 'Showa' | 'Heisei-1' | 'Heisei-2' | 'Reiwa'>('all');
  const [selectedPoster, setSelectedPoster] = useState<PosterItem | null>(null);

  // Helper to distinguish Heisei Phase 1 vs Phase 2
  const isHeiseiPhase1 = (series: string) => {
    const p1Series = ['Kuuga', 'Agito', 'Ryuki', 'Faiz', '555', 'Blade', 'Hibiki', 'Kabuto', 'Den-O', 'Kiva', 'Decade'];
    return p1Series.some(s => series.toLowerCase().includes(s.toLowerCase()));
  };

  // Categorized product groups
  const flashSaleItems = products.filter(p => p.isFlashSale).slice(0, 4);
  const dxProducts = products.filter(p => p.category === 'dx-belt');
  const shfProducts = products.filter(p => p.category === 'shf');
  const shfPremiumProducts = products.filter(p => p.category === 'shf-premium' || p.category === 'shf-pbandai');
  const weaponProducts = products.filter(p => p.category === 'weapon' || p.category === 'cosplay');
  const sentaiProducts = products.filter(p => p.category === 'super-sentai' || p.category === 'sentai');
  const itemProducts = products.filter(p => p.category === 'item-card' || p.category === 'item-cards' || p.category === 'item');

  // Era counts
  const showaCount = products.filter(p => p.era === 'Showa').length;
  const heisei1Count = products.filter(p => p.era === 'Heisei' && isHeiseiPhase1(p.series)).length;
  const heisei2Count = products.filter(p => p.era === 'Heisei' && !isHeiseiPhase1(p.series)).length;
  const reiwaCount = products.filter(p => p.era === 'Reiwa').length;

  // Filtered products for tabbed showcase
  const showcaseProducts = products.filter(p => {
    // 1. Era filter
    if (selectedEra === 'Showa' && p.era !== 'Showa') return false;
    if (selectedEra === 'Reiwa' && p.era !== 'Reiwa') return false;
    if (selectedEra === 'Heisei-1') {
      if (p.era !== 'Heisei' || !isHeiseiPhase1(p.series)) return false;
    }
    if (selectedEra === 'Heisei-2') {
      if (p.era !== 'Heisei' || isHeiseiPhase1(p.series)) return false;
    }

    // 2. Category tab filter
    if (selectedFilter === 'all') return true;
    if (selectedFilter === 'dx-belt') return p.category === 'dx-belt';
    if (selectedFilter === 'shf') return p.category === 'shf';
    if (selectedFilter === 'shf-premium') return p.category === 'shf-premium' || p.category === 'shf-pbandai';
    if (selectedFilter === 'weapon') return p.category === 'weapon' || p.category === 'cosplay';
    if (selectedFilter === 'super-sentai') return p.category === 'super-sentai' || p.category === 'sentai';
    if (selectedFilter === 'item-card') return p.category === 'item-card' || p.category === 'item-cards' || p.category === 'item';
    return true;
  }).slice(0, 8);

  const categories = [
    { 
      id: 'shf', 
      filterId: 'shf' as const,
      name: 'SHF Standard', 
      desc: 'Mô hình 1/12 nguyên mẫu',
      logo: '/BIỂU TƯỢNG DANH MỤC SẢN PHẨM/dlyjpm8-ea90294c-de09-4bc2-8718-6b49acbf082e.png', 
      count: shfProducts.length
    },
    { 
      id: 'shf-premium', 
      filterId: 'shf-premium' as const,
      name: 'SHF Premium', 
      desc: 'Bản giới hạn P-Bandai',
      logo: '/BIỂU TƯỢNG DANH MỤC SẢN PHẨM/kamen_rider_kiva_logo_by_driftingcar_dg7tj5z-pre.png', 
      count: shfPremiumProducts.length
    },
    { 
      id: 'dx-belt', 
      filterId: 'dx-belt' as const,
      name: 'DX Belt & Driver', 
      desc: 'Đai biến hình LED & Voice',
      logo: '/BIỂU TƯỢNG DANH MỤC SẢN PHẨM/kamen_rider_revice_logo_by_driftingcar_dghk15w-pre.png', 
      count: dxProducts.length
    },
    { 
      id: 'super-sentai', 
      filterId: 'super-sentai' as const,
      name: 'Super Sentai', 
      desc: 'Robot Mecha & SMP Bandai',
      logo: '/BIỂU TƯỢNG DANH MỤC SẢN PHẨM/kamen_rider_saber_logo_by_driftingcar_dgh9vay-pre.png', 
      count: sentaiProducts.length
    },
    { 
      id: 'weapon', 
      filterId: 'weapon' as const,
      name: 'Vũ Khí Chiến Đấu', 
      desc: 'Súng kiếm Rider tỷ lệ 1:1',
      logo: '/BIỂU TƯỢNG DANH MỤC SẢN PHẨM/kamen_rider_knight_logo_by_driftingcar_dg73k3x-414w-2x.png', 
      count: weaponProducts.length
    },
    { 
      id: 'item-card', 
      filterId: 'item-card' as const,
      name: 'Thẻ Bài & Item', 
      desc: 'Ride Chemy, Capsem sưu tầm',
      logo: '/BIỂU TƯỢNG DANH MỤC SẢN PHẨM/kamen_rider_femme_logo_by_driftingcar_dg73lkh-pre.png', 
      count: itemProducts.length
    }
  ];

  return (
    <div className="space-y-10 py-6 max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
      {/* 1. Hero Slider Banner */}
      <HeroSlider />

      {/* 2. Quick Category Navigation Bar - Clean, uncrowded */}
      <section className="space-y-3">
        <div className="flex items-center justify-between">
          <div className="flex items-center gap-2">
            <span className="w-2.5 h-2.5 rounded-full bg-cyan-400 animate-pulse"></span>
            <h2 className="text-base sm:text-lg font-bold text-slate-100 uppercase tracking-wide">
              Danh Mục Sản Phẩm Chính
            </h2>
          </div>
          <button 
            onClick={() => setActiveTab('shop')}
            className="text-xs text-cyan-400 hover:text-cyan-300 font-bold flex items-center gap-1 transition"
          >
            Toàn bộ kho hàng <i className="fa-solid fa-angle-right text-[10px]"></i>
          </button>
        </div>

        <div className="grid grid-cols-2 sm:grid-cols-3 lg:grid-cols-6 gap-3">
          {categories.map((c) => {
            const isSelected = selectedFilter === c.filterId;
            return (
              <button
                key={c.id}
                onClick={() => {
                  setSelectedTabFilter(c.filterId);
                  const el = document.getElementById('showcase-section');
                  if (el) el.scrollIntoView({ behavior: 'smooth' });
                }}
                className={`p-3 rounded-2xl flex flex-col items-center text-center gap-2 transition-all duration-200 text-left cursor-pointer border ${
                  isSelected
                    ? 'bg-cyan-950/40 border-cyan-400 shadow-[0_0_15px_rgba(0,255,255,0.25)]'
                    : 'bg-[#10141d] border-cyan-500/20 hover:border-cyan-400/60 hover:bg-[#151a26]'
                }`}
              >
                <div className="w-13 h-13 rounded-xl bg-[#06080e] border-2 border-cyan-400/50 p-1 flex items-center justify-center overflow-hidden shadow-sm group-hover:border-cyan-300">
                  <img 
                    src={c.logo} 
                    alt={c.name} 
                    className="max-h-full max-w-full object-contain filter drop-shadow hover:scale-105 transition duration-300" 
                    onError={(e) => { e.currentTarget.style.display = 'none'; }}
                  />
                </div>
                <div>
                  <h3 className="text-xs font-bold text-slate-100 line-clamp-1">{c.name}</h3>
                  <p className="text-[10px] text-cyan-300 font-semibold">{c.count} sản phẩm</p>
                </div>
              </button>
            );
          })}
        </div>
      </section>

      {/* 3. Nostalgic Tokusatsu Chronology Bar (Hành Trình 4 Kỷ Nguyên Huyền Thoại · 昭和 · 平成 · 令和) */}
      <section className="space-y-4 pt-2">
        <div className="flex flex-col sm:flex-row items-start sm:items-center justify-between gap-3 border-b border-cyan-500/25 pb-3">
          <div className="space-y-0.5">
            <div className="flex items-center gap-2">
              <span className="w-2.5 h-2.5 rounded-full bg-cyan-400 animate-pulse"></span>
              <h2 className="text-base sm:text-xl font-black text-white uppercase tracking-wider flex items-center gap-2">
                Biểu Tượng Kỷ Nguyên <span className="aqua-gradient-text">TOKUSATSU HOÀI NIỆM</span>
              </h2>
            </div>
            <p className="text-xs text-slate-300">
              Khám phá 4 thời kỳ vàng son gắn liền với tuổi thơ người hâm mộ Kamen Rider qua từng thước phim & món đồ chơi Bandai
            </p>
          </div>
          {selectedEra !== 'all' ? (
            <button 
              onClick={() => setSelectedEra('all')}
              className="text-xs text-cyan-300 hover:text-white bg-cyan-950/70 border border-cyan-400/50 px-3.5 py-1.5 rounded-xl transition flex items-center gap-1.5 cursor-pointer font-bold shadow-sm"
            >
              <i className="fa-solid fa-rotate-left text-[11px]"></i>
              <span>Xem Tất Cả Kỷ Nguyên ({products.length})</span>
            </button>
          ) : (
            <span className="text-[11px] text-cyan-400/80 font-mono tracking-wider hidden sm:inline">
              昭和 · 平成前期 · 平成後期 · 令和
            </span>
          )}
        </div>

        {/* 4 Interactive Era Cards */}
        <div className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-4 gap-3.5">
          {[
            {
              id: 'Showa' as const,
              kanji: '昭和',
              name: 'Kỷ Nguyên Showa',
              years: '1971 — 1989',
              tagline: 'Khai sinh huyền thoại · Băng VHS tuổi thơ',
              quote: '"Rider... Henshin!" — Cú đá Rider Kick khai phóng công lý thế hệ đầu',
              riders: 'Ichigo · Nigo · V3 · Black · Black RX',
              count: showaCount,
              icon: 'fa-motorcycle'
            },
            {
              id: 'Heisei-1' as const,
              kanji: '平成前期',
              name: 'Heisei Tiền Kỳ',
              years: '2000 — 2009',
              tagline: 'Thời hoàng kim tuổi thơ · Đĩa VCD/DVD',
              quote: '"Standing By... Complete!" — Tiếng bấm điện thoại Faiz 555 in sâu tâm trí',
              riders: 'Kuuga · Ryuki · Faiz 555 · Blade · Kabuto · Decade',
              count: heisei1Count,
              icon: 'fa-compact-disc'
            },
            {
              id: 'Heisei-2' as const,
              kanji: '平成後期',
              name: 'Heisei Hậu Kỳ',
              years: '2009 — 2018',
              tagline: 'Kỷ nguyên Gimmick · Âm thanh bất hủ',
              quote: '"Cyclone! Joker!" — Giai điệu Henshin vang dội khắp mọi ký ức',
              riders: 'W · OOO · Fourze · Gaim · Drive · Build · Zi-O',
              count: heisei2Count,
              icon: 'fa-bolt'
            },
            {
              id: 'Reiwa' as const,
              kanji: 'Reiwa' as const,
              kanjiText: '令和',
              name: 'Kỷ Nguyên Reiwa',
              years: '2019 — Nay',
              tagline: 'Đỉnh cao công nghệ vị lai · Thiết kế tối tân',
              quote: '"A Jump to the Sky Turns to a Rider Kick" — Đai cảm biến & âm thanh đỉnh cao',
              riders: 'Zero-One · Saber · Geats · Gotchard · Gavv · Zeztz',
              count: reiwaCount,
              icon: 'fa-microchip'
            }
          ].map((era) => {
            const isSelected = selectedEra === era.id;
            const kanjiDisplay = era.kanjiText || era.kanji;
            return (
              <div
                key={era.id}
                onClick={() => {
                  setSelectedEra(isSelected ? 'all' : era.id);
                  const el = document.getElementById('showcase-section');
                  if (el) el.scrollIntoView({ behavior: 'smooth' });
                }}
                className={`group relative p-4 rounded-2xl cursor-pointer transition-all duration-300 overflow-hidden border ${
                  isSelected
                    ? 'bg-gradient-to-br from-[#0c1a36] to-[#060e22] border-cyan-400 shadow-[0_0_25px_rgba(0,255,255,0.35)] scale-[1.02]'
                    : 'bg-gradient-to-br from-[#080e1e] to-[#040813] border-cyan-500/25 hover:border-cyan-400/60 hover:bg-[#0c162e] hover:shadow-[0_4px_20px_rgba(0,245,212,0.15)]'
                }`}
              >
                {/* Nostalgic TV Scanline Overlay */}
                <div className="nostalgic-scanline pointer-events-none"></div>

                {/* Japanese Kanji Background Watermark */}
                <div className="absolute right-2 -bottom-2 text-6xl md:text-7xl font-black text-cyan-400/5 select-none pointer-events-none group-hover:text-cyan-400/10 transition-colors">
                  {kanjiDisplay}
                </div>

                <div className="relative z-10 space-y-2.5">
                  <div className="flex items-center justify-between">
                    <span className="font-mono text-[10px] font-bold text-cyan-300 bg-cyan-950/80 border border-cyan-500/40 px-2.5 py-0.5 rounded-lg flex items-center gap-1.5">
                      <i className={`fa-solid ${era.icon} text-[10px]`}></i>
                      <span>{era.years}</span>
                    </span>
                    <span className="text-xs font-serif text-cyan-400/70 font-bold tracking-widest">
                      {kanjiDisplay}
                    </span>
                  </div>

                  <div>
                    <h3 className="text-sm font-black text-white group-hover:text-cyan-300 transition-colors flex items-center gap-1.5">
                      <span>{era.name}</span>
                      {isSelected && <i className="fa-solid fa-circle-check text-cyan-400 text-xs"></i>}
                    </h3>
                    <p className="text-[11px] text-cyan-200/90 font-medium mt-0.5 line-clamp-1">
                      {era.tagline}
                    </p>
                  </div>

                  <p className="text-[10px] text-slate-400 italic line-clamp-2 leading-relaxed bg-[#040711]/60 p-2 rounded-xl border border-cyan-500/15">
                    {era.quote}
                  </p>

                  <div className="pt-1 flex items-center justify-between text-[10px]">
                    <span className="text-slate-400 truncate max-w-[150px]" title={era.riders}>
                      <i className="fa-solid fa-mask mr-1 text-cyan-400/70"></i>
                      {era.riders}
                    </span>
                    <span className="text-cyan-300 font-bold whitespace-nowrap bg-cyan-500/15 px-2 py-0.5 rounded-md border border-cyan-500/30">
                      {era.count} SP
                    </span>
                  </div>
                </div>
              </div>
            );
          })}
        </div>
      </section>

      {/* 4. Flash Sale Section - Harmonized Dark Obsidian + Aqua Neon */}
      {flashSaleItems.length > 0 && (
        <section className="bg-gradient-to-r from-[#070e1e] via-[#09152b] to-[#070e1e] border border-cyan-500/40 rounded-3xl p-4 sm:p-6 space-y-4 shadow-2xl aqua-running-border">
          <div className="flex flex-col sm:flex-row items-start sm:items-center justify-between gap-3 border-b border-cyan-500/20 pb-3">
            <div className="flex items-center gap-2.5">
              <span className="bg-cyan-500/20 text-[#00f5d4] border border-cyan-400/60 font-black text-[10px] px-2.5 py-1 rounded-lg uppercase tracking-wider flex items-center gap-1.5 shadow-[0_0_12px_rgba(0,245,212,0.3)]">
                <i className="fa-solid fa-bolt text-[#00f5d4] animate-pulse"></i> FLASH SALE GIỜ VÀNG
              </span>
              <h2 className="text-base sm:text-lg font-bold text-slate-100">
                Ưu Đãi Đặc Biệt Giá Sốc Hôm Nay
              </h2>
            </div>
            <div className="flex items-center gap-2 bg-[#040814] border border-cyan-500/40 px-3.5 py-1 rounded-xl text-xs font-mono shadow-inner">
              <span className="text-slate-400 text-[10px] uppercase font-bold mr-1">Kết thúc sau:</span>
              <span className="text-[#00f5d4] font-bold tracking-widest drop-shadow-[0_0_8px_rgba(0,245,212,0.6)]">04 : 18 : 32</span>
            </div>
          </div>

          <div className="grid grid-cols-2 sm:grid-cols-4 gap-3.5 sm:gap-4">
            {flashSaleItems.map(p => (
              <ProductCard
                key={p.id}
                product={p}
                onSelect={onSelectProduct}
                onAddToCart={onAddToCart}
                onAddToCompare={onAddToCompare}
                isFavorite={wishlistIds.includes(p.id)}
                onToggleFavorite={onToggleFavorite}
              />
            ))}
          </div>
        </section>
      )}

      {/* 5. Main Product Showcase with Filter Tabs */}
      <section id="showcase-section" className="space-y-4">
        <div className="flex flex-col sm:flex-row items-start sm:items-center justify-between gap-3 border-b border-cyan-500/25 pb-3">
          <div>
            <h2 className="text-base sm:text-xl font-bold text-slate-100 flex items-center gap-2 flex-wrap">
              <span className="aqua-gradient-text uppercase">Bộ Sưu Tập Nổi Bật</span>
              {selectedEra !== 'all' && (
                <span className="text-[11px] font-bold text-cyan-300 bg-cyan-950/80 border border-cyan-400/50 px-2.5 py-0.5 rounded-full flex items-center gap-1 shadow-sm">
                  <span>{selectedEra === 'Showa' ? '昭和 Showa' : selectedEra === 'Heisei-1' ? '平成 I Heisei Tiền Kỳ' : selectedEra === 'Heisei-2' ? '平成 II Heisei Hậu Kỳ' : '令和 Reiwa'}</span>
                  <button onClick={() => setSelectedEra('all')} className="hover:text-white ml-1 text-xs font-bold" title="Bỏ lọc kỷ nguyên">✕</button>
                </span>
              )}
            </h2>
            <p className="text-xs text-slate-400 mt-0.5">
              Lọc theo danh mục hoặc kỷ nguyên để tìm lại món bảo vật kỷ niệm tuổi thơ
            </p>
          </div>

          {/* Interactive Segmented Filter Tabs */}
          <div className="flex items-center gap-1.5 overflow-x-auto no-scrollbar w-full sm:w-auto p-1 bg-[#10141d] rounded-xl border border-cyan-500/30">
            {[
              { id: 'all', label: 'Tất Cả' },
              { id: 'dx-belt', label: 'DX Belts' },
              { id: 'shf', label: 'S.H.Figuarts' },
              { id: 'shf-premium', label: 'SHF Premium' },
              { id: 'super-sentai', label: 'Super Sentai' },
              { id: 'weapon', label: 'Vũ Khí' },
              { id: 'item-card', label: 'Thẻ Bài' },
            ].map(f => (
              <button
                key={f.id}
                onClick={() => setSelectedTabFilter(f.id as any)}
                className={`px-3 py-1.5 rounded-lg text-xs font-medium transition whitespace-nowrap ${
                  selectedFilter === f.id
                    ? 'bg-cyan-500/20 text-cyan-300 border border-cyan-500/50 shadow-sm font-bold'
                    : 'text-slate-400 hover:text-white hover:bg-slate-800/50'
                }`}
              >
                {f.label}
              </button>
            ))}
          </div>
        </div>

        {/* 4-column Product Grid */}
        <div className="grid grid-cols-2 sm:grid-cols-3 lg:grid-cols-4 gap-3.5 sm:gap-4">
          {showcaseProducts.map(p => (
            <ProductCard 
              key={p.id}
              product={p}
              onSelect={onSelectProduct}
              onAddToCart={onAddToCart}
              onAddToCompare={onAddToCompare}
              isFavorite={wishlistIds.includes(p.id)}
              onToggleFavorite={onToggleFavorite}
            />
          ))}
        </div>

        <div className="text-center pt-2">
          <button
            onClick={() => setActiveTab('shop')}
            className="px-6 py-2.5 rounded-xl bg-cyan-500/10 border border-cyan-500/40 hover:bg-cyan-500 hover:text-black text-cyan-300 font-bold text-xs transition duration-200 inline-flex items-center gap-2"
          >
            <span>Khám phá toàn bộ {products.length} sản phẩm trong Shop</span>
            <i className="fa-solid fa-arrow-right text-xs"></i>
          </button>
        </div>
      </section>



      {/* 6. Tokusatsu Movie Posters Art Showcase - Horizontal 4-grid */}
      <section className="bg-[#10141d] border border-cyan-500/35 rounded-3xl p-5 space-y-4 shadow-lg">
        <div className="flex flex-col sm:flex-row sm:items-center justify-between gap-2 border-b border-slate-800 pb-3">
          <div className="flex items-center gap-2.5">
            <span className="w-8 h-8 rounded-lg bg-cyan-950/70 border border-cyan-500/40 flex items-center justify-center text-cyan-400 text-sm">
              <i className="fa-solid fa-image"></i>
            </span>
            <div>
              <h3 className="text-sm sm:text-base font-bold text-slate-100">
                Bộ Sưu Tập Poster Điện Ảnh & Art Print 4K
              </h3>
              <p className="text-[10px] text-slate-400">
                In trên giấy Coucher Glossy 300gsm phủ UV chống trầy, chống phai màu
              </p>
            </div>
          </div>
          <span className="text-xs text-cyan-400 font-medium">
            Bấm vào poster để phóng to chi tiết
          </span>
        </div>

        <div className="grid grid-cols-2 sm:grid-cols-4 gap-3.5 sm:gap-4">
          {POSTER_ITEMS.slice(0, 4).map(poster => (
            <PosterCard
              key={poster.id}
              poster={poster}
              onSelectPoster={(p) => setSelectedPoster(p)}
              onAddToCart={onAddToCart}
              posterToProductMap={posterToProduct}
            />
          ))}
        </div>
      </section>

      {/* 7. Rider Points Membership Banner */}
      <section className="bg-gradient-to-r from-[#070e1e] via-[#0b162f] to-[#070e1e] border border-cyan-500/40 rounded-3xl p-5 sm:p-7 grid grid-cols-1 lg:grid-cols-12 gap-5 items-center shadow-2xl aqua-running-border">
        <div className="lg:col-span-8 space-y-2 text-center lg:text-left">
          <span className="inline-block bg-cyan-500/15 border border-cyan-400/40 text-cyan-300 text-[10px] font-bold px-3 py-0.5 rounded-full uppercase tracking-wider">
            ⭐ Tích Điểm Đổi Quà Thẻ & Vouchers
          </span>
          <h3 className="text-base sm:text-lg font-bold text-white text-pop">
            Chương Trình <span className="aqua-gradient-text font-black">RIDER POINTS NPTTEAMSTORE</span>
          </h3>
          <p className="text-xs text-slate-200 max-w-2xl leading-relaxed font-medium">
            Tích lũy 1 Rider Point cho mỗi 10.000đ mua hàng tại NPTTEAMSTORE. Đạt mốc Legend Rider để hưởng đặc quyền giảm 10% trọn đời và quyền ưu tiên đặt trước đai CSM giới hạn!
          </p>
          <div className="flex flex-wrap items-center justify-center lg:justify-start gap-2 pt-1 text-slate-300 text-[10px]">
            <span className="bg-[#040814] border border-cyan-500/20 px-2.5 py-1 rounded-lg">Novice Rider (100pt)</span>
            <span className="bg-[#040814] border border-cyan-500/30 px-2.5 py-1 rounded-lg text-cyan-300">Rider Collector (500pt)</span>
            <span className="bg-[#040814] border border-cyan-500/40 px-2.5 py-1 rounded-lg text-cyan-200 font-bold">CSM Master (2,000pt)</span>
            <span className="bg-cyan-500/20 border border-cyan-400 text-cyan-300 font-bold px-2.5 py-1 rounded-lg shadow-sm">Legend Rider (5,000pt)</span>
          </div>
        </div>

        <div className="lg:col-span-4 flex justify-center">
          <button 
            onClick={() => setActiveTab('promotions')}
            className="px-5 py-2.5 bg-gradient-to-r from-cyan-400 to-blue-500 hover:from-cyan-300 hover:to-blue-400 text-black font-extrabold text-xs rounded-xl shadow-lg shadow-cyan-500/25 transition duration-200 flex items-center gap-2"
          >
            <i className="fa-solid fa-crown text-xs"></i>
            <span>Xem Chi Tiết Đặc Quyền</span>
          </button>
        </div>
      </section>

      {/* 8. Blog & News Preview */}
      <section className="space-y-4">
        <div className="flex items-center justify-between border-b border-cyan-500/25 pb-3">
          <div className="flex items-center gap-2">
            <span className="w-2.5 h-2.5 rounded-full bg-cyan-400"></span>
            <h2 className="text-base sm:text-lg font-bold text-slate-100">
              Tin Tức Mới & <span className="aqua-gradient-text">REVIEW SẢN PHẨM</span>
            </h2>
          </div>
          <button 
            onClick={() => setActiveTab('blog')}
            className="text-xs text-cyan-400 hover:underline font-bold"
          >
            Tất cả bài viết →
          </button>
        </div>

        <div className="grid grid-cols-1 md:grid-cols-3 gap-4">
          {blogs.slice(0, 3).map((b) => (
            <div 
              key={b.id}
              onClick={() => {
                if (onSelectBlog) {
                  onSelectBlog(b);
                } else {
                  setActiveTab('blog');
                }
              }}
              className="bg-[#10141d] rounded-2xl overflow-hidden cursor-pointer group transition duration-300 flex flex-col justify-between border border-cyan-500/30 hover:border-cyan-400 hover:shadow-[0_0_15px_rgba(0,255,255,0.2)]"
            >
              <div className="aspect-video overflow-hidden bg-[#090b10] relative">
                <img 
                  src={b.image} 
                  alt={b.title} 
                  className="w-full h-full object-cover group-hover:scale-105 transition duration-500" 
                  onError={(e) => {
                    e.currentTarget.src = '/Tin Tức & Bài Viết Blog/thumb_hiep-si-mat-na-zeztz_4567685e.webp';
                  }}
                />
                <div className="absolute top-2 left-2 bg-[#090b10]/90 border border-cyan-500/40 text-cyan-300 text-[9px] font-bold px-2 py-0.5 rounded-md uppercase">
                  {b.category}
                </div>
              </div>
              <div className="p-4 space-y-2 flex-grow flex flex-col justify-between">
                <div>
                  <div className="text-[10px] text-slate-400 font-medium mb-1">
                    {b.date} · {b.author}
                  </div>
                  <h3 className="font-bold text-xs sm:text-sm text-slate-100 group-hover:text-cyan-300 line-clamp-2 transition leading-snug">
                    {b.title}
                  </h3>
                  <p className="text-[11px] text-slate-400 line-clamp-2 mt-1 leading-relaxed">
                    {b.summary}
                  </p>
                </div>
                <div className="pt-2 border-t border-slate-800 flex items-center justify-between text-[10px] text-slate-400">
                  <span>{b.readTime} đọc</span>
                  <span className="text-cyan-400 group-hover:translate-x-1 transition duration-200">Đọc bài →</span>
                </div>
              </div>
            </div>
          ))}
        </div>
      </section>

      {/* Poster Zoom Modal */}
      {selectedPoster && (
        <PosterDetailModal
          poster={selectedPoster}
          onClose={() => setSelectedPoster(null)}
          onAddToCart={onAddToCart}
        />
      )}
    </div>
  );
};
