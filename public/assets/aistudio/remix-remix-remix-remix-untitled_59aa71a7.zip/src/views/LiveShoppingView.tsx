import React, { useState, useEffect, useRef } from 'react';
import { Product, User, LiveFilterType, LiveChatMessage, LiveRoom } from '../types';
import { LiveFilterProcessor } from '../utils/liveFilters';
import { 
  verifyCameraPresence, 
  getLiveStreamMedia, 
  getScreenShareMedia,
  DEFAULT_VIDEO_CONFIG, 
  VideoConfigOptions,
} from '../utils/livekitClient';

interface LiveShoppingViewProps {
  products: Product[];
  currentUser: User | null;
  onAddToCart: (product: Product, e?: React.MouseEvent | number) => void;
  onBuyNow: (product: Product, e?: React.MouseEvent | number) => void;
  onSelectProduct: (product: Product) => void;
  showToast: (msg: string, type?: 'success' | 'error' | 'info') => void;
  openAuth: () => void;
  isAdminAuthenticated?: boolean;
  openAdmin?: () => void;
}

export const LiveShoppingView: React.FC<LiveShoppingViewProps> = ({
  products,
  currentUser,
  onAddToCart,
  onBuyNow,
  onSelectProduct,
  showToast,
  openAuth,
  isAdminAuthenticated = false,
  openAdmin
}) => {
  const isAdmin = Boolean(isAdminAuthenticated || currentUser?.role === 'admin' || (typeof window !== 'undefined' && localStorage.getItem('npt_admin_auth') === 'true'));

  // -------------------------------------------------------------
  // 1. LIVE ROOMS & ACTIVE CHANNEL STATE
  // -------------------------------------------------------------
  const [rooms, setRooms] = useState<LiveRoom[]>([]);
  const [activeRoomId, setActiveRoomId] = useState<string>('room_npt_official');
  const [activeRoom, setActiveRoom] = useState<LiveRoom | null>(null);

  // Mode: STRICT SEPARATION ('streamer' = Người Live vs 'audience' = Người Xem)
  // Web Khách cannot live; locked to 'audience' unless admin
  const [mode, setMode] = useState<'audience' | 'streamer'>('audience');

  // Video Config state (Streamer broadcast settings)
  const [videoConfig, setVideoConfig] = useState<VideoConfigOptions>(DEFAULT_VIDEO_CONFIG);
  const [selectedSvcLayer, setSelectedSvcLayer] = useState<'auto' | 'L3_HIGH' | 'L2_MID' | 'L1_LOW'>('auto');
  const [isConfigModalOpen, setIsConfigModalOpen] = useState(false);

  // Hardware Camera Error Modal (Requirement 3: Exact dialog)
  const [cameraError, setCameraError] = useState<string | null>(null);

  // Create Room Modal State
  const [isCreateRoomOpen, setIsCreateRoomOpen] = useState(false);
  const [newRoomTitle, setNewRoomTitle] = useState('');
  const [newRoomCategory, setNewRoomCategory] = useState('Đai Biến Hình DX & CSM');
  const [newRoomPinnedProduct, setNewRoomPinnedProduct] = useState(products[0]?.id || 'p1');

  // Streamer Video & Canvas Refs (Broadcast Feed)
  const videoRef = useRef<HTMLVideoElement>(null);
  const canvasRef = useRef<HTMLCanvasElement>(null);
  const mediaStreamRef = useRef<MediaStream | null>(null);
  const screenStreamRef = useRef<MediaStream | null>(null);
  const cameraStreamRef = useRef<MediaStream | null>(null);
  const pipVideoRef = useRef<HTMLVideoElement>(null);
  const filterProcessorRef = useRef<LiveFilterProcessor | null>(null);

  // Streamer Microphone & Camera hardware status
  const [isMicEnabled, setIsMicEnabled] = useState(true);
  const [isCameraEnabled, setIsCameraEnabled] = useState(true);
  const [isScreenSharing, setIsScreenSharing] = useState(false);
  const [isConfirmEndLiveOpen, setIsConfirmEndLiveOpen] = useState(false);
  const [isEndingLive, setIsEndingLive] = useState(false);

  // Streamer Live Inventory Management Modal
  const [isStockModalOpen, setIsStockModalOpen] = useState(false);
  const [stockMap, setStockMap] = useState<Record<string, number>>({});

  // -------------------------------------------------------------
  // 2. AUDIENCE / VIEWER EXCLUSIVE STATES
  // -------------------------------------------------------------
  // Viewer AR Personal Mirror & Try-On Modal
  const [isViewerArOpen, setIsViewerArOpen] = useState(false);
  const viewerVideoRef = useRef<HTMLVideoElement>(null);
  const viewerCanvasRef = useRef<HTMLCanvasElement>(null);
  const viewerMediaStreamRef = useRef<MediaStream | null>(null);
  const viewerFilterProcessorRef = useRef<LiveFilterProcessor | null>(null);
  const [viewerActiveFilter, setViewerActiveFilter] = useState<LiveFilterType>('smooth-skin');
  const [viewerLipstickShade, setViewerLipstickShade] = useState('Ruby Red #d62246');
  const [viewerGlassesStyle, setViewerGlassesStyle] = useState('Aviator Titan');
  const [isViewerCamReady, setIsViewerCamReady] = useState(false);

  // In-Live Cart Drawer (Viewer Exclusive)
  const [isInLiveCartOpen, setIsInLiveCartOpen] = useState(false);

  // Toggle Purchase Notification Banner (Viewer Customization)
  const [showPurchaseTicker, setShowPurchaseTicker] = useState(true);

  // Flash Sale Countdown & Voucher Claimed State
  const [flashSecondsLeft, setFlashSecondsLeft] = useState(300);
  const [isVoucherClaimed, setIsVoucherClaimed] = useState(false);

  // -------------------------------------------------------------
  // 3. STREAMER EXCLUSIVE MODALS
  // -------------------------------------------------------------
  const [isPinPickerOpen, setIsPinPickerOpen] = useState(false);
  const [isAdminModOpen, setIsAdminModOpen] = useState(false);

  // Real Chat State (100% REAL ACCOUNTS, ZERO FAKE BOT MESSAGES)
  const [messages, setMessages] = useState<LiveChatMessage[]>([]);
  const [chatInput, setChatInput] = useState('');
  const [isUploadingFile, setIsUploadingFile] = useState(false);
  const fileInputRef = useRef<HTMLInputElement>(null);
  const chatScrollRef = useRef<HTMLDivElement>(null);

  // Pinned Product in active room
  const pinnedProduct = products.find(p => p.id === activeRoom?.pinnedProductId) || products[0];

  // Purchase Notification Ticker Data
  const [recentPurchases, setRecentPurchases] = useState<Array<{
    id: string;
    customerName: string;
    productName: string;
    time: string;
  }>>([
    {
      id: 'p1',
      customerName: 'Hoàng Minh Quân',
      productName: 'Kamen Rider Zeztz DX Henshin Belt Lord Invoker',
      time: 'Vừa xong',
    },
    {
      id: 'p2',
      customerName: 'Trần Tuấn Kiệt',
      productName: 'Mô Hình S.H.Figuarts Kamen Rider Gavv Poppingummy Form',
      time: '1 phút trước',
    },
    {
      id: 'p3',
      customerName: 'Lê Bảo Nam',
      productName: 'DX Gotchardriver Special Darkness Edition',
      time: '2 phút trước',
    },
  ]);
  const [currentTickerIndex, setCurrentTickerIndex] = useState(0);

  // Viewer moderation status
  const [isUserBanned, setIsUserBanned] = useState(false);
  const [isUserKicked, setIsUserKicked] = useState(false);

  // List of 10 WebGL / AR Filters
  const FILTERS_LIST: Array<{ id: LiveFilterType; name: string; category: string; icon: string }> = [
    { id: 'none', name: 'Gốc (No Filter)', category: 'Mặc định', icon: 'fa-ban' },
    { id: 'smooth-skin', name: 'Mịn Da', category: 'Làm Đẹp', icon: 'fa-wand-magic-sparkles' },
    { id: 'bright-glow', name: 'Sáng Da', category: 'Làm Đẹp', icon: 'fa-sun' },
    { id: 'v-line-slim', name: 'Thon Mặt V-Line', category: 'Làm Đẹp', icon: 'fa-face-smile' },
    { id: 'bunny-cat-ears', name: 'Tai Mèo/Thỏ', category: 'Vui Nhộn', icon: 'fa-cat' },
    { id: 'cyber-sunglasses', name: 'Kính Râm Ngầu', category: 'Vui Nhộn', icon: 'fa-glasses' },
    { id: 'cyberpunk-glitch', name: 'Cyberpunk HUD', category: 'Vui Nhộn', icon: 'fa-bolt' },
    { id: 'vintage-retro', name: 'Vintage 35mm', category: 'Vui Nhộn', icon: 'fa-film' },
    { id: 'virtual-lipstick', name: 'Thử Son Môi AR', category: 'Thử Đồ Ảo', icon: 'fa-brush' },
    { id: 'designer-glasses', name: 'Thử Kính Mắt AR', category: 'Thử Đồ Ảo', icon: 'fa-eye' },
    { id: 'heart-sparkle-burst', name: 'Thả Tim & Lấp Lánh', category: 'Hiệu Ứng', icon: 'fa-heart' },
  ];

  // -------------------------------------------------------------
  // FETCH DATA: ROOMS, STATUS, REAL MESSAGES
  // -------------------------------------------------------------
  const fetchRooms = async () => {
    try {
      const res = await fetch('/api/live/rooms');
      if (res.ok) {
        const data = await res.json();
        const activeList: LiveRoom[] = data.rooms || [];
        setRooms(activeList);

        const current = activeList.find(r => r.id === activeRoomId) || activeList[0];
        if (current) {
          setActiveRoom(current);
          if (current.videoConfig) setVideoConfig(current.videoConfig);
          if (current.productStocks) setStockMap(current.productStocks);
        }
      }
    } catch (e) {
      console.warn('Failed to fetch live rooms', e);
    }
  };

  const fetchRoomMessages = async (roomId: string) => {
    if (isUserBanned || isUserKicked) return;
    try {
      const userId = currentUser?.id || 'anon';
      const res = await fetch(`/api/live/rooms/${roomId}/messages?userId=${userId}`);
      if (res.status === 403) {
        setIsUserBanned(true);
        return;
      }
      if (res.ok) {
        const data = await res.json();
        setMessages(data.messages || []);
      }
    } catch (e) {
      console.warn('Failed to fetch room messages', e);
    }
  };

  useEffect(() => {
    fetchRooms();
  }, []);

  useEffect(() => {
    if (activeRoom?.id) {
      fetchRoomMessages(activeRoom.id);
      const interval = setInterval(() => {
        fetchRoomMessages(activeRoom.id);
        fetchRooms();
      }, 3000);
      return () => clearInterval(interval);
    }
  }, [activeRoom?.id, currentUser, isUserBanned, isUserKicked]);

  // Auto scroll chat to bottom when real message arrives
  useEffect(() => {
    if (chatScrollRef.current) {
      chatScrollRef.current.scrollTop = chatScrollRef.current.scrollHeight;
    }
  }, [messages]);

  // Flash Sale Timer
  useEffect(() => {
    const timer = setInterval(() => {
      setFlashSecondsLeft(prev => (prev > 0 ? prev - 1 : 0));
    }, 1000);
    return () => clearInterval(timer);
  }, []);

  // Purchase notification rotation
  useEffect(() => {
    if (recentPurchases.length === 0) return;
    const tickerTimer = setInterval(() => {
      setCurrentTickerIndex(prev => (prev + 1) % recentPurchases.length);
    }, 5000);
    return () => clearInterval(tickerTimer);
  }, [recentPurchases.length]);

  // -------------------------------------------------------------
  // STREAMER CANVAS & BROADCAST RENDER LOOP
  // -------------------------------------------------------------
  useEffect(() => {
    if (!canvasRef.current) return;
    const processor = new LiveFilterProcessor(canvasRef.current);
    filterProcessorRef.current = processor;

    let animId: number;
    const renderLoop = () => {
      if (videoRef.current && videoRef.current.readyState >= 2) {
        processor.render(videoRef.current);
      } else {
        processor.render(null);
      }
      animId = requestAnimationFrame(renderLoop);
    };
    animId = requestAnimationFrame(renderLoop);

    return () => {
      cancelAnimationFrame(animId);
      processor.destroy();
    };
  }, []);

  // -------------------------------------------------------------
  // HARDWARE CAMERA & MICROPHONE CONTROLS (Streamer Exclusive)
  // -------------------------------------------------------------
  const startCameraStream = async () => {
    setCameraError(null);

    // Requirement 3: Hardware Camera Check
    const check = await verifyCameraPresence();
    if (!check.hasCamera) {
      setCameraError(check.errorMessage || 'Thiết bị của bạn không có camera nên không sử dụng được chức năng live');
      setMode('audience');
      return;
    }

    try {
      if (mediaStreamRef.current) {
        mediaStreamRef.current.getTracks().forEach(t => t.stop());
      }
      const stream = await getLiveStreamMedia(videoConfig);
      mediaStreamRef.current = stream;
      cameraStreamRef.current = stream;
      if (videoRef.current) {
        videoRef.current.srcObject = stream;
        videoRef.current.muted = true;
        videoRef.current.playsInline = true;
        videoRef.current.play().catch(e => console.warn('Autoplay prevented:', e));
      }
      setIsCameraEnabled(true);
      setIsMicEnabled(true);
      showToast('⚡ Luồng phát đã được kích hoạt thành công!', 'success');
    } catch (err: any) {
      console.error('Camera init error:', err);
      const msg = err.message || 'Thiết bị của bạn không có camera nên không sử dụng được chức năng live';
      setCameraError(msg);
      setMode('audience');
    }
  };

  // Synchronize video element whenever mode, camera, or screen sharing state updates
  useEffect(() => {
    if (videoRef.current) {
      const activeStream = isScreenSharing ? screenStreamRef.current : mediaStreamRef.current;
      if (activeStream && videoRef.current.srcObject !== activeStream) {
        videoRef.current.srcObject = activeStream;
        videoRef.current.muted = true;
        videoRef.current.playsInline = true;
        videoRef.current.play().catch(e => console.warn('Stream play sync err:', e));
      }
    }
  }, [mode, isCameraEnabled, isScreenSharing]);

  const stopCameraStream = () => {
    if (mediaStreamRef.current) {
      mediaStreamRef.current.getTracks().forEach(t => t.stop());
      mediaStreamRef.current = null;
    }
    if (cameraStreamRef.current) {
      cameraStreamRef.current.getTracks().forEach(t => t.stop());
      cameraStreamRef.current = null;
    }
    if (videoRef.current && !isScreenSharing) {
      videoRef.current.srcObject = null;
    }
  };

  const stopScreenShare = () => {
    if (screenStreamRef.current) {
      screenStreamRef.current.getTracks().forEach(t => t.stop());
      screenStreamRef.current = null;
    }
    setIsScreenSharing(false);
  };

  // Stop Real Screen Sharing and restore Camera stream
  const handleStopScreenShare = async () => {
    stopScreenShare();
    // Return to streamer camera feed
    if (cameraStreamRef.current && cameraStreamRef.current.active && cameraStreamRef.current.getVideoTracks().some(t => t.readyState === 'live')) {
      mediaStreamRef.current = cameraStreamRef.current;
      if (videoRef.current) {
        videoRef.current.srcObject = cameraStreamRef.current;
        videoRef.current.play().catch(e => console.warn('Camera replay error:', e));
      }
    } else {
      await startCameraStream();
    }
    showToast('📺 Đã dừng chia sẻ màn hình và quay lại camera streamer.', 'info');
  };

  // Toggle Real Screen Share (Streamer Exclusive) - 100% REAL HARDWARE CAPTURE, ZERO SIMULATION
  const handleToggleScreenShare = async () => {
    if (isScreenSharing) {
      await handleStopScreenShare();
    } else {
      try {
        const screenStream = await getScreenShareMedia();

        // Preserve camera stream for return or picture-in-picture
        if (mediaStreamRef.current && !cameraStreamRef.current) {
          cameraStreamRef.current = mediaStreamRef.current;
        }

        screenStreamRef.current = screenStream;
        if (videoRef.current) {
          videoRef.current.srcObject = screenStream;
          videoRef.current.play().catch(e => console.warn('Screen share play error:', e));
        }

        // Attach camera to PiP video if available
        if (pipVideoRef.current && cameraStreamRef.current) {
          pipVideoRef.current.srcObject = cameraStreamRef.current;
          pipVideoRef.current.play().catch(e => console.warn('PiP video play error:', e));
        }

        setIsScreenSharing(true);
        showToast('🖥️ Đang phát màn hình thật của bạn trực tiếp lên luồng Live!', 'success');

        // Handle user clicking native browser "Stop sharing" button
        const videoTrack = screenStream.getVideoTracks()[0];
        if (videoTrack) {
          videoTrack.onended = () => {
            handleStopScreenShare();
          };
        }
      } catch (e: any) {
        console.warn('Real screen share error or cancelled:', e);
        if (e.name === 'NotAllowedError' || e.name === 'AbortError') {
          showToast('Bạn đã hủy thao tác chia sẻ màn hình.', 'info');
          return;
        }
        showToast(`Không thể chia sẻ màn hình: ${e.message || 'Lỗi quyền truy cập'}`, 'error');
      }
    }
  };

  // Sync PiP video with camera stream whenever screen sharing is toggled
  useEffect(() => {
    if (isScreenSharing && pipVideoRef.current && cameraStreamRef.current) {
      pipVideoRef.current.srcObject = cameraStreamRef.current;
      pipVideoRef.current.play().catch(e => console.warn('PiP video play err:', e));
    }
  }, [isScreenSharing]);

  // Open Confirmation Modal to End Live Room (Streamer Exclusive)
  const handleEndLiveRoom = () => {
    if (!activeRoom) return;
    setIsConfirmEndLiveOpen(true);
  };

  // Execute End Live Room when user confirms in modal
  const executeEndLiveRoom = async () => {
    if (!activeRoom) return;
    setIsEndingLive(true);
    const endingId = activeRoom.id;
    const endingTitle = activeRoom.title;

    try {
      await fetch(`/api/live/rooms/${endingId}/end`, {
        method: 'POST',
        headers: { 'Content-Type': 'application/json' },
      });
    } catch (err) {
      console.warn('End room API error:', err);
    }

    // Stop all media hardware streams cleanly
    stopScreenShare();
    stopCameraStream();
    setIsScreenSharing(false);
    setIsConfirmEndLiveOpen(false);
    setIsEndingLive(false);

    // Filter out ended room
    const remaining = rooms.filter(r => r.id !== endingId && r.status === 'live');
    setRooms(remaining);
    setMode('audience');

    if (remaining.length > 0) {
      setActiveRoomId(remaining[0].id);
      setActiveRoom(remaining[0]);
      fetchRoomMessages(remaining[0].id);
    } else {
      setActiveRoom(null);
    }

    showToast(`🔴 Buổi phát sóng [${endingTitle}] đã kết thúc và đóng phòng thành công!`, 'success');
    fetchRooms();
  };

  // Reopen or Reset official demo room if all rooms were closed
  const handleResetOfficialRoom = async () => {
    try {
      const res = await fetch('/api/live/rooms/reset-official', { method: 'POST' });
      if (res.ok) {
        const data = await res.json();
        const activeList: LiveRoom[] = data.rooms || [];
        setRooms(activeList);
        if (activeList.length > 0) {
          setActiveRoomId(activeList[0].id);
          setActiveRoom(activeList[0]);
          fetchRoomMessages(activeList[0].id);
        }
        showToast('✅ Đã mở lại phòng Live Showcase chính thức!', 'success');
      }
    } catch {
      showToast('Không thể mở lại phòng live', 'error');
    }
  };

  // Toggle Streamer Mic
  const handleToggleMic = () => {
    if (mediaStreamRef.current) {
      const audioTracks = mediaStreamRef.current.getAudioTracks();
      const nextState = !isMicEnabled;
      audioTracks.forEach(t => (t.enabled = nextState));
      setIsMicEnabled(nextState);
      showToast(nextState ? '🎙️ Đã BẬT Micro (Thu giọng nhạy + Lọc ồn cực mạnh)' : '🔇 Đã TẮT Micro', 'info');
    }
  };

  // Toggle Streamer Camera
  const handleToggleCamera = () => {
    if (mediaStreamRef.current) {
      const videoTracks = mediaStreamRef.current.getVideoTracks();
      const nextState = !isCameraEnabled;
      videoTracks.forEach(t => (t.enabled = nextState));
      setIsCameraEnabled(nextState);
      showToast(nextState ? '📷 Đã BẬT Camera Streamer' : '🚫 Đã TẮT Camera Streamer', 'info');
    }
  };

  // Switch between Audience & Streamer Mode (Only Web Quản Lý / Admin Danh Nguyễn can stream)
  const handleToggleMode = async (targetMode: 'streamer' | 'audience') => {
    if (targetMode === 'streamer') {
      if (!isAdmin) {
        showToast('🔒 Web Khách không có quyền Live! Chỉ Web Quản Lý (Admin Danh Nguyễn) mới có thể phát trực tiếp.', 'error');
        if (openAdmin) openAdmin();
        setMode('audience');
        return;
      }

      const check = await verifyCameraPresence();
      if (!check.hasCamera) {
        setCameraError(check.errorMessage || 'Thiết bị của bạn không có camera nên không sử dụng được chức năng live');
        setMode('audience');
        return;
      }
      setMode('streamer');
      await startCameraStream();
    } else {
      setMode('audience');
      stopCameraStream();
    }
  };

  // Switch Room
  const handleSelectRoom = (room: LiveRoom) => {
    setActiveRoomId(room.id);
    setActiveRoom(room);
    setMessages([]);
    fetchRoomMessages(room.id);
    showToast(`Đã vào phòng phát sóng của [${room.hostName}]!`, 'info');
  };

  // Start My Own Live Stream Room
  const handleCreateRoom = async (e: React.FormEvent) => {
    e.preventDefault();
    if (!newRoomTitle.trim()) {
      showToast('Vui lòng nhập tiêu đề buổi live!', 'error');
      return;
    }

    const check = await verifyCameraPresence();
    if (!check.hasCamera) {
      setCameraError(check.errorMessage || 'Thiết bị của bạn không có camera nên không sử dụng được chức năng live');
      setIsCreateRoomOpen(false);
      return;
    }

    try {
      const payload = {
        hostId: currentUser?.id || 'host_' + Date.now().toString(36),
        hostName: currentUser?.name || 'Rider Collector',
        hostAvatar: currentUser?.avatar || '/Logo & Thương Hiệu (Brand Logo)/dreamina-2026-07-29-3008-A minimalist stencil-style logo of an oc....png',
        title: newRoomTitle.trim(),
        category: newRoomCategory,
        pinnedProductId: newRoomPinnedProduct,
      };

      const res = await fetch('/api/live/rooms', {
        method: 'POST',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify(payload),
      });

      if (res.ok) {
        const data = await res.json();
        const createdRoom = data.room;
        setRooms(prev => [createdRoom, ...prev]);
        setActiveRoomId(createdRoom.id);
        setActiveRoom(createdRoom);
        setIsCreateRoomOpen(false);
        setMode('streamer');
        await startCameraStream();
        showToast(`🎉 Phòng Live của bạn đã lên sóng! Khán giả có thể vào xem ngay.`, 'success');
      }
    } catch {
      showToast('Lỗi tạo phòng live, vui lòng thử lại', 'error');
    }
  };

  // -------------------------------------------------------------
  // STREAMER EXCLUSIVE MODERATION ACTIONS
  // -------------------------------------------------------------
  // Toggle Lock/Unlock Chat Room ("Tắt chat tổng / Khóa bình luận")
  const handleToggleLockChat = async () => {
    if (!activeRoom) return;
    try {
      const res = await fetch(`/api/live/rooms/${activeRoom.id}/lock-chat`, {
        method: 'POST',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify({ isLocked: !activeRoom.isChatLocked }),
      });
      if (res.ok) {
        const data = await res.json();
        setActiveRoom(prev => prev ? { ...prev, isChatLocked: data.isChatLocked } : prev);
        showToast(
          data.isChatLocked 
            ? '🔒 Đã KHÓA bình luận khán giả (Tắt chat tổng để tập trung giới thiệu)' 
            : '🔓 Đã MỞ lại tính năng bình luận cho khán giả!',
          'success'
        );
        fetchRoomMessages(activeRoom.id);
      }
    } catch {
      showToast('Lỗi thao tác khóa chat', 'error');
    }
  };

  // Pin Product
  const handlePinProduct = async (pId: string) => {
    if (!activeRoom) return;
    try {
      const res = await fetch('/api/live/pin-product', {
        method: 'POST',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify({ productId: pId, roomId: activeRoom.id }),
      });
      if (res.ok) {
        setActiveRoom(prev => prev ? { ...prev, pinnedProductId: pId } : prev);
        setIsPinPickerOpen(false);
        showToast('📌 Đã ghim sản phẩm lên vị trí nổi bật nhất cho tất cả người xem!', 'success');
      }
    } catch {
      showToast('Lỗi ghim sản phẩm', 'error');
    }
  };

  // Unpin Product
  const handleUnpinProduct = async () => {
    if (!activeRoom) return;
    try {
      await fetch('/api/live/pin-product', {
        method: 'POST',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify({ productId: '', roomId: activeRoom.id }),
      });
      setActiveRoom(prev => prev ? { ...prev, pinnedProductId: undefined } : prev);
      showToast('Đã bỏ ghim sản phẩm', 'info');
    } catch {
      showToast('Lỗi bỏ ghim sản phẩm', 'error');
    }
  };

  // Live Inventory Stock Update
  const handleUpdateStock = async (pId: string, delta: number) => {
    if (!activeRoom) return;
    const currentStock = stockMap[pId] ?? 10;
    const newStock = Math.max(0, currentStock + delta);
    try {
      const res = await fetch(`/api/live/rooms/${activeRoom.id}/update-stock`, {
        method: 'POST',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify({ productId: pId, newStock }),
      });
      if (res.ok) {
        const data = await res.json();
        setStockMap(data.productStocks || {});
        showToast(`Đã cập nhật kho: còn ${newStock} chiếc`, 'success');
      }
    } catch {
      showToast('Lỗi cập nhật kho hàng', 'error');
    }
  };

  // Moderator Kick
  const handleKickUser = async (userId: string, senderName: string) => {
    try {
      await fetch('/api/live/moderate/kick', {
        method: 'POST',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify({ userId, roomId: activeRoom?.id, reason: 'Vi phạm nội quy livestream' }),
      });
      showToast(`Đã thu hồi token và kick [${senderName}] khỏi phòng live!`, 'success');
      if (activeRoom) fetchRoomMessages(activeRoom.id);
    } catch {
      showToast('Lỗi thao tác kick', 'error');
    }
  };

  // Moderator Ban
  const handleBanUser = async (userId: string, senderName: string) => {
    try {
      await fetch('/api/live/moderate/ban', {
        method: 'POST',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify({ userId, roomId: activeRoom?.id, reason: 'Spam / Phá rối' }),
      });
      showToast(`Đã cấm vĩnh viễn tài khoản [${senderName}]`, 'success');
      if (activeRoom) fetchRoomMessages(activeRoom.id);
    } catch {
      showToast('Lỗi cấm tài khoản', 'error');
    }
  };

  // Hide Message
  const handleHideMessage = async (msgId: string) => {
    try {
      await fetch('/api/live/moderate/hide-message', {
        method: 'POST',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify({ messageId: msgId }),
      });
      setMessages(prev => prev.filter(m => m.id !== msgId));
      showToast('Đã ẩn bình luận spam này khỏi toàn bộ phòng live', 'info');
    } catch {
      showToast('Lỗi ẩn tin nhắn', 'error');
    }
  };

  // -------------------------------------------------------------
  // AUDIENCE / VIEWER EXCLUSIVE ACTIONS
  // -------------------------------------------------------------
  // Viewer AR Camera Stream (Runs locally for viewer only!)
  const startViewerArCamera = async () => {
    try {
      if (viewerMediaStreamRef.current) {
        viewerMediaStreamRef.current.getTracks().forEach(t => t.stop());
      }
      const stream = await navigator.mediaDevices.getUserMedia({
        video: { width: { ideal: 640 }, height: { ideal: 480 }, facingMode: 'user' },
        audio: false,
      });
      viewerMediaStreamRef.current = stream;
      if (viewerVideoRef.current) {
        viewerVideoRef.current.srcObject = stream;
        viewerVideoRef.current.play().catch(e => console.warn('Viewer camera play err:', e));
      }
      setIsViewerCamReady(true);
    } catch (e) {
      console.warn('Cannot access viewer webcam for AR try-on:', e);
      setIsViewerCamReady(false);
      showToast('Không thể mở camera thiết bị của bạn. Hiển thị mô phỏng gương AR!', 'info');
    }
  };

  const stopViewerArCamera = () => {
    if (viewerMediaStreamRef.current) {
      viewerMediaStreamRef.current.getTracks().forEach(t => t.stop());
      viewerMediaStreamRef.current = null;
    }
    if (viewerVideoRef.current) {
      viewerVideoRef.current.srcObject = null;
    }
    setIsViewerCamReady(false);
  };

  // Viewer AR Canvas render loop
  useEffect(() => {
    if (!isViewerArOpen || !viewerCanvasRef.current) return;
    const processor = new LiveFilterProcessor(viewerCanvasRef.current);
    viewerFilterProcessorRef.current = processor;
    processor.setFilter(viewerActiveFilter);

    let animId: number;
    const loop = () => {
      if (viewerVideoRef.current && viewerVideoRef.current.readyState >= 2) {
        processor.render(viewerVideoRef.current);
      } else {
        processor.render(null);
      }
      animId = requestAnimationFrame(loop);
    };
    animId = requestAnimationFrame(loop);

    return () => {
      cancelAnimationFrame(animId);
      processor.destroy();
    };
  }, [isViewerArOpen, viewerActiveFilter]);

  // Viewer Open AR Mirror
  const handleOpenViewerAr = async () => {
    setIsViewerArOpen(true);
    await startViewerArCamera();
  };

  // Viewer Close AR Mirror
  const handleCloseViewerAr = () => {
    stopViewerArCamera();
    setIsViewerArOpen(false);
  };

  // Viewer In-Live Order Now
  const handleLiveOrderNow = (product: Product) => {
    if (!currentUser) {
      showToast('Vui lòng đăng nhập để chốt đơn nhanh trên Live!', 'info');
      openAuth();
      return;
    }

    onBuyNow(product);

    if (filterProcessorRef.current) {
      filterProcessorRef.current.spawnBurst(25);
    }

    // Call server to record purchase, increment room sales & decrement live stock
    fetch('/api/live/purchase', {
      method: 'POST',
      headers: { 'Content-Type': 'application/json' },
      body: JSON.stringify({
        customerName: currentUser.name,
        productName: product.name,
        productImage: product.images[0],
        productPrice: product.price,
        productId: product.id,
        roomId: activeRoom?.id,
      }),
    })
      .then(res => res.json())
      .then(data => {
        if (data.totalOrders && activeRoom) {
          setActiveRoom(prev => prev ? { 
            ...prev, 
            totalOrders: data.totalOrders, 
            totalRevenue: data.totalRevenue,
            productStocks: data.productStocks 
          } : prev);
        }
      })
      .catch(() => {});

    setRecentPurchases(prev => [
      {
        id: 'pur_' + Date.now(),
        customerName: currentUser.name,
        productName: product.name,
        time: 'Vừa xong',
      },
      ...prev,
    ]);
  };

  // Claim Flash Sale Voucher (Viewer Exclusive)
  const handleClaimVoucher = () => {
    setIsVoucherClaimed(true);
    if (navigator.clipboard) {
      navigator.clipboard.writeText('LIVEVIP50');
    }
    showToast('🎉 Đã lưu mã [LIVEVIP50] (-15% tối đa 250.000đ)! Tự động áp dụng khi thanh toán.', 'success');
    if (filterProcessorRef.current) {
      filterProcessorRef.current.spawnBurst(20);
    }
  };

  // Send REAL Chat Message to current room (No fake accounts)
  const handleSendMessage = async (e: React.FormEvent) => {
    e.preventDefault();
    if (!chatInput.trim() || isUserBanned || isUserKicked || !activeRoom) return;

    const isAdminRole = currentUser?.role === 'admin' || (mode === 'streamer' && currentUser?.id === activeRoom.hostId);

    // If chat is locked and user is not admin/streamer
    if (activeRoom.isChatLocked && !isAdminRole) {
      showToast('Streamer đang tạm khóa bình luận phòng live để tập trung giới thiệu sản phẩm!', 'error');
      return;
    }

    const payload = {
      senderId: currentUser?.id || 'guest_' + Math.random().toString(36).substring(2, 6),
      senderName: currentUser?.name || (mode === 'streamer' ? activeRoom.hostName : 'Khán Giả'),
      senderAvatar: currentUser?.avatar || (mode === 'streamer' ? activeRoom.hostAvatar : '/BIỂU TƯỢNG DANH MỤC SẢN PHẨM/dlyjpm8-ea90294c-de09-4bc2-8718-6b49acbf082e.png'),
      senderBadge: mode === 'streamer' ? '👑 STREAMER' : (currentUser?.tierRank || (currentUser?.role === 'admin' ? '👑 BQT' : 'MEMBER')),
      text: chatInput.trim(),
      isAdmin: isAdminRole,
    };

    try {
      const res = await fetch(`/api/live/rooms/${activeRoom.id}/messages`, {
        method: 'POST',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify(payload),
      });
      if (res.ok) {
        const data = await res.json();
        setMessages(prev => [...prev, data.message]);
        setChatInput('');
      } else if (res.status === 423) {
        showToast('Streamer đang tạm khóa bình luận phòng live để tập trung giới thiệu sản phẩm!', 'error');
      } else if (res.status === 403) {
        showToast('Bạn đã bị cấm bình luận trên buổi Live này!', 'error');
        setIsUserBanned(true);
      }
    } catch {
      showToast('Lỗi gửi tin nhắn, vui lòng thử lại', 'error');
    }
  };

  // Handle Real File / Image Upload
  const handleFileUpload = async (e: React.ChangeEvent<HTMLInputElement>) => {
    const file = e.target.files?.[0];
    if (!file || !activeRoom) return;

    if (file.size > 20 * 1024 * 1024) {
      showToast('Tệp tin tối đa 20MB!', 'error');
      return;
    }

    setIsUploadingFile(true);
    showToast(`Đang tải tệp [${file.name}] lên máy chủ...`, 'info');

    const reader = new FileReader();
    reader.onload = async () => {
      try {
        const base64Data = reader.result as string;
        const uploadRes = await fetch('/api/live/upload', {
          method: 'POST',
          headers: { 'Content-Type': 'application/json' },
          body: JSON.stringify({
            fileName: file.name,
            mimeType: file.type,
            base64Data,
          }),
        });

        if (!uploadRes.ok) throw new Error('Upload failed');
        const uploadData = await uploadRes.json();

        await fetch(`/api/live/rooms/${activeRoom.id}/messages`, {
          method: 'POST',
          headers: { 'Content-Type': 'application/json' },
          body: JSON.stringify({
            senderId: currentUser?.id || 'guest',
            senderName: currentUser?.name || 'Khán Giả',
            senderAvatar: currentUser?.avatar || '/BIỂU TƯỢNG DANH MỤC SẢN PHẨM/dlyjpm8-ea90294c-de09-4bc2-8718-6b49acbf082e.png',
            text: file.type.startsWith('image/') ? '📷 Đã chia sẻ ảnh sản phẩm' : `📎 Đã gửi tệp: ${file.name}`,
            file: uploadData.file,
            isAdmin: currentUser?.role === 'admin',
          }),
        });

        fetchRoomMessages(activeRoom.id);
        showToast('Đã gửi tệp thành công!', 'success');
      } catch {
        showToast('Không thể tải tệp lên máy chủ', 'error');
      } finally {
        setIsUploadingFile(false);
        if (fileInputRef.current) fileInputRef.current.value = '';
      }
    };
    reader.readAsDataURL(file);
  };

  const formatTime = (secs: number) => {
    const m = Math.floor(secs / 60);
    const s = secs % 60;
    return `${m.toString().padStart(2, '0')}:${s.toString().padStart(2, '0')}`;
  };

  return (
    <div className="min-h-screen bg-[#050814] text-slate-100 flex flex-col relative pb-16">
      
      {/* ========================================================================= */}
      {/* 1. TOP DIRECTORY: CÁC TÀI KHOẢN ĐANG PHÁT LIVE (CLICK ĐỂ VÀO XEM)        */}
      {/* ========================================================================= */}
      <section className="bg-gradient-to-r from-[#070e24] via-[#091538] to-[#070e24] border-b border-cyan-500/30 px-4 py-3 shadow-xl sticky top-16 z-30">
        <div className="max-w-7xl mx-auto space-y-2.5">
          <div className="flex items-center justify-between">
            <div className="flex items-center gap-2">
              <span className="relative flex h-3 w-3 shrink-0">
                <span className="animate-ping absolute inline-flex h-full w-full rounded-full bg-rose-500 opacity-75"></span>
                <span className="relative inline-flex rounded-full h-3 w-3 bg-rose-600"></span>
              </span>
              <h2 className="text-xs sm:text-sm font-black uppercase text-white tracking-wider flex items-center gap-1.5">
                <span>KÊNH PHÁT TRỰC TIẾP CHÍNH THỨC</span>
                <span className="bg-rose-600/90 text-white text-[10px] px-2 py-0.2 rounded-full font-bold">
                  {rooms.length} Kênh Live
                </span>
              </h2>
            </div>

            <div className="flex items-center gap-2">
              {isAdmin ? (
                <>
                  {/* Role Indicator Badge */}
                  <span className={`text-[11px] font-black px-2.5 py-1 rounded-xl border flex items-center gap-1.5 ${
                    mode === 'streamer'
                      ? 'bg-rose-500/20 text-rose-300 border-rose-500/50 shadow-[0_0_10px_rgba(244,63,94,0.3)]'
                      : 'bg-cyan-500/20 text-cyan-300 border-cyan-500/50'
                  }`}>
                    <i className={`fa-solid ${mode === 'streamer' ? 'fa-microphone-lines' : 'fa-crown'}`}></i>
                    <span>{mode === 'streamer' ? 'Streamer: DANH NGUYỄN (Đang Live)' : 'Vai trò: QUẢN LÝ STORE'}</span>
                  </span>

                  {/* Toggle Mode Button */}
                  <button
                    onClick={() => handleToggleMode(mode === 'audience' ? 'streamer' : 'audience')}
                    className={`text-xs font-bold px-3 py-1.5 rounded-xl border transition flex items-center gap-1.5 cursor-pointer ${
                      mode === 'streamer'
                        ? 'bg-cyan-400 text-black border-cyan-300 shadow-[0_0_15px_rgba(0,255,255,0.4)]'
                        : 'bg-gradient-to-r from-amber-400 to-rose-500 text-black border-amber-300 font-extrabold shadow-lg'
                    }`}
                  >
                    <i className={`fa-solid ${mode === 'streamer' ? 'fa-tv' : 'fa-video'}`}></i>
                    <span>{mode === 'streamer' ? 'Xem Như Khán Giả' : '🔴 Lên Sóng Live Studio'}</span>
                  </button>
                </>
              ) : (
                <span className="text-[11px] font-bold px-3 py-1.5 rounded-xl border bg-cyan-950/80 border-cyan-400/40 text-cyan-300 flex items-center gap-1.5 shadow-sm">
                  <i className="fa-solid fa-tv text-cyan-400"></i>
                  <span>Web Khách: Xem Trực Tiếp & Mua Hàng</span>
                </span>
              )}
            </div>
          </div>

          {/* Horizontal List of Active Channels/Accounts */}
          <div className="flex items-center gap-3 overflow-x-auto pb-1 no-scrollbar">
            {rooms.map((room) => {
              const isSelected = activeRoom?.id === room.id;
              return (
                <div
                  key={room.id}
                  onClick={() => handleSelectRoom(room)}
                  className={`flex items-center gap-3 p-2 rounded-2xl border transition-all cursor-pointer shrink-0 max-w-xs sm:max-w-sm ${
                    isSelected
                      ? 'bg-gradient-to-r from-cyan-950/80 to-[#0c1c44] border-cyan-400 shadow-[0_0_20px_rgba(0,255,255,0.35)] scale-[1.02]'
                      : 'bg-[#091129]/90 border-slate-800 hover:border-cyan-500/50 hover:bg-[#0c183a]'
                  }`}
                >
                  <div className="relative w-11 h-11 shrink-0">
                    <img
                      src={room.hostAvatar}
                      alt={room.hostName}
                      className="w-full h-full object-cover rounded-full border-2 border-rose-500 p-0.5"
                    />
                    <span className="absolute -bottom-1 -right-1 bg-rose-600 text-white text-[8px] font-black px-1 rounded-full uppercase border border-black animate-pulse">
                      LIVE
                    </span>
                  </div>

                  <div className="min-w-0 flex-1">
                    <div className="flex items-center gap-1.5">
                      <span className="font-extrabold text-white text-xs truncate">
                        {room.hostName}
                      </span>
                      {room.isOfficial ? (
                        <span className="text-[9px] bg-cyan-500/20 text-cyan-300 font-bold px-1.5 py-0.2 rounded">
                          OFFICIAL
                        </span>
                      ) : (
                        <span className="text-[9px] bg-amber-500/20 text-amber-300 font-bold px-1.5 py-0.2 rounded">
                          {room.hostBadge}
                        </span>
                      )}
                    </div>

                    <p className="text-[11px] text-slate-300 truncate max-w-[190px]">
                      {room.title}
                    </p>

                    <div className="flex items-center gap-2 text-[10px] mt-0.5">
                      <span className="text-cyan-400 font-medium">{room.category}</span>
                      <span>•</span>
                      <span className="text-emerald-400 font-bold">
                        <i className="fa-solid fa-users mr-1 text-[9px]"></i>
                        {room.viewerCount} đang xem
                      </span>
                    </div>
                  </div>

                  <button
                    className={`text-[10px] font-black px-2.5 py-1.5 rounded-lg shrink-0 transition ${
                      isSelected
                        ? 'bg-cyan-400 text-black'
                        : 'bg-slate-800 text-slate-300 hover:text-white'
                    }`}
                  >
                    {isSelected ? 'Đang Xem' : 'Vào Xem'}
                  </button>
                </div>
              );
            })}
          </div>
        </div>
      </section>

      {/* ========================================================================= */}
      {/* 2. REAL-TIME PURCHASE TICKER & FLASH SALE BAR                             */}
      {/* ========================================================================= */}
      <div className="bg-[#0b132b] border-b border-cyan-500/20 py-1.5 px-4 text-xs overflow-hidden">
        <div className="max-w-7xl mx-auto flex items-center justify-between gap-3">
          
          {/* Purchase notification ticker (Audience can toggle on/off) */}
          <div className="flex items-center gap-2 overflow-hidden text-ellipsis whitespace-nowrap min-w-0">
            {showPurchaseTicker ? (
              <div className="flex items-center gap-2 overflow-hidden text-ellipsis whitespace-nowrap">
                <span className="bg-emerald-500/20 text-emerald-400 border border-emerald-500/40 text-[10px] font-black px-2 py-0.5 rounded-full shrink-0 flex items-center gap-1">
                  <span className="w-1.5 h-1.5 rounded-full bg-emerald-400 animate-ping"></span>
                  ĐƠN MỚI CHỐT
                </span>
                <div className="animate-fadeIn truncate text-slate-200 text-xs">
                  <span className="font-bold text-amber-300">
                    {recentPurchases[currentTickerIndex]?.customerName || 'Khách Hàng'}
                  </span>
                  <span className="text-slate-400 mx-1">vừa chốt</span>
                  <span className="font-extrabold text-cyan-300 underline">
                    [{recentPurchases[currentTickerIndex]?.productName || 'Đai Henshin Bandai'}]
                  </span>
                  <span className="text-slate-500 text-[11px] ml-2">({recentPurchases[currentTickerIndex]?.time})</span>
                </div>
              </div>
            ) : (
              <span className="text-slate-400 text-xs italic">
                (Đã ẩn thông báo chốt đơn trên màn hình)
              </span>
            )}
          </div>

          {/* Right Controls: Flash Sale & Toggle Ticker */}
          <div className="flex items-center gap-2.5 shrink-0">
            {/* Audience View Customization: Toggle Ticker */}
            {mode === 'audience' && (
              <button
                onClick={() => setShowPurchaseTicker(prev => !prev)}
                className="text-[10px] bg-slate-800 hover:bg-slate-700 text-slate-300 px-2 py-1 rounded border border-slate-700 transition"
                title="Bật/Tắt thanh thông báo chốt đơn"
              >
                <i className={`fa-solid ${showPurchaseTicker ? 'fa-bell-slash' : 'fa-bell'} mr-1`}></i>
                {showPurchaseTicker ? 'Ẩn Ticker' : 'Hiện Ticker'}
              </button>
            )}

            <span className="text-rose-400 font-mono font-bold flex items-center gap-1">
              <i className="fa-solid fa-bolt animate-pulse"></i>
              Flash Sale: {formatTime(flashSecondsLeft)}
            </span>

            {/* Audience Only: Voucher Claim Button */}
            {mode === 'audience' ? (
              <button
                onClick={handleClaimVoucher}
                disabled={isVoucherClaimed}
                className={`text-[11px] font-black px-2.5 py-1 rounded-lg transition ${
                  isVoucherClaimed ? 'bg-emerald-600 text-white' : 'bg-amber-400 hover:bg-amber-300 text-black shadow'
                }`}
              >
                {isVoucherClaimed ? '✓ Đã Lưu LIVEVIP50' : '⚡ Lưu Mã -15%'}
              </button>
            ) : (
              /* Streamer Only: Flash Sale Trigger Button */
              <button
                onClick={() => {
                  setFlashSecondsLeft(300);
                  showToast('⚡ Streamer đã kích hoạt Flash Sale 5 Phút trên toàn bộ phòng Live!', 'success');
                }}
                className="bg-rose-600 hover:bg-rose-500 text-white text-[11px] font-black px-2.5 py-1 rounded-lg transition shadow"
              >
                <i className="fa-solid fa-fire mr-1"></i> Kích Hoạt 5 Phút
              </button>
            )}
          </div>
        </div>
      </div>

      {/* ========================================================================= */}
      {/* 3. MAIN WORKSPACE: STRICT SEPARATION (STREAMER VS AUDIENCE)               */}
      {/* ========================================================================= */}
      <main className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 py-4 flex-1 w-full grid grid-cols-1 lg:grid-cols-12 gap-5 items-start">
        {!activeRoom ? (
          <div className="lg:col-span-12 bg-gradient-to-b from-[#0a1432] to-[#070c1e] border-2 border-cyan-500/40 rounded-3xl p-8 sm:p-12 text-center space-y-5 shadow-2xl my-6">
            <div className="w-20 h-20 rounded-full bg-rose-500/20 border-2 border-rose-500/60 text-rose-400 flex items-center justify-center mx-auto text-3xl shadow-[0_0_30px_rgba(244,63,94,0.3)]">
              <i className="fa-solid fa-circle-stop"></i>
            </div>
            <div className="space-y-2">
              <h3 className="text-xl sm:text-2xl font-black text-white uppercase tracking-wider">
                Hiện Không Có Phiên Live Nào Đang Phát
              </h3>
            </div>
            {isAdmin && (
              <div className="flex flex-wrap items-center justify-center gap-3 pt-2">
                <button
                  onClick={() => setIsCreateRoomOpen(true)}
                  className="bg-gradient-to-r from-amber-400 to-rose-500 hover:brightness-110 text-black font-black text-xs px-5 py-3 rounded-2xl shadow-xl transition flex items-center gap-2 cursor-pointer"
                >
                  <i className="fa-solid fa-plus text-sm"></i>
                  <span>Mở Kênh Live (Admin)</span>
                </button>
              </div>
            )}
          </div>
        ) : (
          <>
        {/* ========================================================= */}
        {/* LEFT / CENTER VIEWPORT (8 cols)                           */}
        {/* ========================================================= */}
        <section className="lg:col-span-8 flex flex-col gap-3">
          
          {/* Header Info */}
          <div className="bg-[#080f24] border border-cyan-500/30 rounded-2xl px-4 py-2.5 flex items-center justify-between gap-3 shadow-lg">
            <div className="flex items-center gap-3 min-w-0">
              <img
                src={activeRoom?.hostAvatar}
                alt={activeRoom?.hostName}
                className="w-10 h-10 rounded-full object-cover border-2 border-cyan-400 p-0.5"
              />
              <div className="min-w-0">
                <div className="flex items-center gap-2">
                  <h3 className="font-black text-white text-sm truncate">
                    {activeRoom?.title}
                  </h3>
                </div>
                <p className="text-[11px] text-cyan-300 font-semibold flex items-center gap-2">
                  <span>{activeRoom?.hostName}</span>
                  <span>•</span>
                  <span className="text-emerald-400 font-bold">
                    <i className="fa-solid fa-eye mr-1"></i>
                    {activeRoom?.viewerCount} Khán Giả
                  </span>
                </p>
              </div>
            </div>

            {/* Top Right Controls per Mode */}
            <div className="flex items-center gap-2 shrink-0">
              {mode === 'streamer' ? (
                /* Streamer Exclusive Config Button */
                <button
                  onClick={() => setIsConfigModalOpen(true)}
                  className="text-xs bg-slate-800 hover:bg-slate-700 text-cyan-300 border border-slate-600 px-3 py-1.5 rounded-lg font-bold flex items-center gap-1.5 shadow"
                >
                  <i className="fa-solid fa-sliders"></i>
                  <span>Cấu Hình Luồng</span>
                </button>
              ) : (
                /* Audience Exclusive Personal AR Mirror Button */
                <button
                  onClick={handleOpenViewerAr}
                  className="text-xs bg-gradient-to-r from-purple-600 to-pink-600 hover:brightness-110 text-white font-black px-3.5 py-1.5 rounded-xl border border-pink-400 shadow-[0_0_15px_rgba(236,72,153,0.4)] flex items-center gap-1.5 cursor-pointer animate-pulse"
                  title="Mở gương camera cá nhân để thử son, kính hoặc dùng filter mà không ảnh hưởng streamer"
                >
                  <i className="fa-solid fa-wand-magic-sparkles"></i>
                  <span>🪞 Thử Đồ AR Cá Nhân</span>
                </button>
              )}
            </div>
          </div>

          {/* Main Video Viewport */}
          <div className="relative bg-black rounded-2xl overflow-hidden border-2 border-cyan-500/40 shadow-[0_0_35px_rgba(6,182,212,0.25)] aspect-video flex items-center justify-center select-none">
            
            {/* Streamer Live Camera / Screen Share Video Feed (Native GPU rendering, NEVER hidden) */}
            {(mode === 'streamer' || mediaStreamRef.current) && (
              <video
                ref={videoRef}
                autoPlay
                playsInline
                muted
                onLoadedMetadata={(e) => {
                  const target = e.target as HTMLVideoElement;
                  target.play().catch(err => console.warn('Video auto-play err:', err));
                }}
                className={`w-full h-full ${
                  isScreenSharing ? 'object-contain bg-black z-10' : 'object-cover z-10'
                }`}
              />
            )}

            {/* Audience View: Live Studio Showcase Backdrop when viewing room */}
            {mode === 'audience' && !mediaStreamRef.current && (
              <div className="absolute inset-0 w-full h-full z-10 overflow-hidden">
                <img
                  src={activeRoom.thumbnail || '/Ảnh Showroom & Cửa Hàng/20240708_161850.jpg'}
                  alt={activeRoom.title}
                  className="w-full h-full object-cover filter brightness-90 scale-100"
                />
                <div className="absolute inset-0 bg-gradient-to-t from-[#040817] via-black/35 to-black/50 flex flex-col items-center justify-center p-6 text-center">
                  <div className="relative mb-3">
                    <div className="w-16 h-16 sm:w-20 sm:h-20 rounded-full border-2 border-rose-500 p-1 bg-black/60 shadow-[0_0_25px_rgba(244,63,94,0.6)] mx-auto overflow-hidden">
                      <img src={activeRoom.hostAvatar} alt={activeRoom.hostName} className="w-full h-full object-cover rounded-full" />
                    </div>
                    <span className="absolute -bottom-1 left-1/2 -translate-x-1/2 bg-rose-600 text-white text-[9px] font-black px-2 py-0.5 rounded-full uppercase border border-black animate-pulse shadow">
                      STREAMING
                    </span>
                  </div>

                  <h4 className="text-sm sm:text-base font-black text-white max-w-lg mb-1 drop-shadow-md">
                    {activeRoom.title}
                  </h4>
                  <p className="text-xs text-cyan-300 font-semibold mb-4">
                    Host: {activeRoom.hostName} • <span className="text-emerald-400 font-bold">{activeRoom.viewerCount} đang xem trực tiếp</span>
                  </p>

                  <div className="flex flex-wrap items-center justify-center gap-2">
                    {isAdmin ? (
                      <button
                        onClick={() => handleToggleMode('streamer')}
                        className="bg-gradient-to-r from-amber-400 to-rose-500 hover:brightness-110 text-black font-black text-xs px-4 py-2 rounded-xl shadow-lg transition flex items-center gap-1.5 cursor-pointer"
                      >
                        <i className="fa-solid fa-video"></i>
                        <span>Bật Camera & Lên Sóng Live (Admin)</span>
                      </button>
                    ) : (
                      <div className="bg-rose-950/70 border border-rose-500/40 text-rose-300 text-xs font-bold px-3 py-1.5 rounded-xl flex items-center gap-1.5">
                        <span className="w-2 h-2 rounded-full bg-rose-500 animate-ping"></span>
                        <span>Đang kết nối luồng Live từ Admin Store</span>
                      </div>
                    )}
                    <button
                      onClick={handleOpenViewerAr}
                      className="bg-purple-600/80 hover:bg-purple-600 text-white text-xs font-bold px-3.5 py-2 rounded-xl border border-purple-400/50 shadow transition flex items-center gap-1.5 cursor-pointer"
                    >
                      <i className="fa-solid fa-wand-magic-sparkles"></i>
                      <span>Thử Đồ AR Cá Nhân</span>
                    </button>
                  </div>
                </div>
              </div>
            )}

            {/* Streamer Camera Off Indicator */}
            {mode === 'streamer' && !isCameraEnabled && !isScreenSharing && (
              <div className="absolute inset-0 z-15 bg-[#070d1e]/90 flex flex-col items-center justify-center text-center p-4 space-y-2">
                <i className="fa-solid fa-video-slash text-rose-500 text-3xl"></i>
                <p className="text-sm font-bold text-white">Camera streamer đang tạm tắt</p>
                <p className="text-xs text-slate-400">Bấm nút "Camera: Đã Tắt" ở bảng điều khiển bên dưới để bật lại luồng hình ảnh</p>
                <button
                  onClick={handleToggleCamera}
                  className="bg-cyan-500 hover:bg-cyan-400 text-black font-bold text-xs px-3.5 py-1.5 rounded-lg transition mt-1"
                >
                  Bật Lại Camera
                </button>
              </div>
            )}

            {/* Canvas Stage: WebGL/2D Filter Renderer with AR and effects when in camera mode */}
            <canvas
              ref={canvasRef}
              width={1280}
              height={720}
              className="absolute inset-0 w-full h-full object-cover pointer-events-none z-20"
            />

            {/* Screen Share Active Banner (Centered Top HUD) */}
            {isScreenSharing && (
              <div className="absolute top-3 left-1/2 -translate-x-1/2 z-30 flex items-center gap-2 bg-indigo-950/90 border border-indigo-400/80 text-white px-3.5 py-1 rounded-full text-xs font-bold shadow-2xl backdrop-blur-md">
                <span className="w-2 h-2 rounded-full bg-emerald-400 animate-ping"></span>
                <span>🖥️ Đang Phát Màn Hình Thật Của Streamer</span>
                {mode === 'streamer' && (
                  <button
                    onClick={handleStopScreenShare}
                    className="ml-2 bg-rose-600 hover:bg-rose-500 text-white text-[10px] font-black px-2.5 py-0.5 rounded-lg transition cursor-pointer shadow"
                  >
                    Dừng Chia Sẻ
                  </button>
                )}
              </div>
            )}

            {/* Picture-in-Picture Mini Camera Stream of Streamer when Sharing Screen */}
            {isScreenSharing && isCameraEnabled && (
              <div className="absolute bottom-4 right-4 z-30 w-36 sm:w-44 aspect-video rounded-xl overflow-hidden border-2 border-cyan-400 shadow-[0_0_20px_rgba(0,255,255,0.4)] bg-black/95">
                <video
                  ref={pipVideoRef}
                  autoPlay
                  playsInline
                  muted
                  className="w-full h-full object-cover"
                />
                <div className="absolute bottom-1 left-1.5 bg-black/80 text-[9px] font-black text-rose-400 px-1.5 py-0.5 rounded flex items-center gap-1 border border-rose-500/40">
                  <span className="w-1.5 h-1.5 rounded-full bg-rose-500 animate-pulse"></span>
                  <span>Cam Streamer</span>
                </div>
              </div>
            )}

            {/* Video Overlay Top-Left: Live Tech HUD */}
            <div className="absolute top-3 left-3 z-20 flex flex-wrap items-center gap-1.5 pointer-events-none">
              <span className="bg-rose-600 text-white text-[10px] font-black px-2 py-0.5 rounded shadow flex items-center gap-1">
                <span className="w-1.5 h-1.5 rounded-full bg-white animate-pulse"></span>
                LIVEKIT SVC
              </span>
              <span className="bg-black/80 backdrop-blur-md text-cyan-300 border border-cyan-500/40 text-[10px] font-mono font-bold px-2 py-0.5 rounded">
                {videoConfig.resolution} @ {videoConfig.fps}FPS · {videoConfig.bitrateMbps} Mbps
              </span>
              {mode === 'streamer' && (
                <span className="bg-emerald-950/80 text-emerald-300 border border-emerald-500/40 text-[10px] font-bold px-2 py-0.5 rounded flex items-center gap-1">
                  <i className="fa-solid fa-microphone text-[9px]"></i> Mic Nhạy Cao (Active)
                </span>
              )}
            </div>

            {/* Video Overlay Top-Right: Quality Selector (Audience Only) */}
            {mode === 'audience' && (
              <div className="absolute top-3 right-3 z-20 flex items-center gap-1.5">
                <select
                  value={selectedSvcLayer}
                  onChange={(e) => {
                    const val = e.target.value as any;
                    setSelectedSvcLayer(val);
                    showToast(`Khán giả chuyển chất lượng xem sang: ${val === 'auto' ? 'Tự động (SVC Dynamic)' : val}`, 'info');
                  }}
                  className="bg-black/85 backdrop-blur-md text-cyan-300 border border-cyan-500/50 text-[11px] font-bold rounded-lg px-2.5 py-1 cursor-pointer focus:outline-none shadow-lg"
                >
                  <option value="auto">⚡ Tự Động (SVC Dynamic)</option>
                  <option value="L3_HIGH">1080p 60fps (FHD 4 Mbps)</option>
                  <option value="L2_MID">720p 30fps (HD 1.5 Mbps)</option>
                  <option value="L1_LOW">360p 30fps (Tiết Kiệm 4G)</option>
                </select>
              </div>
            )}

            {/* PINNED PRODUCT OVERLAY CARD (Audience Only - Bottom-Left) */}
            {mode === 'audience' && pinnedProduct && (
              <div className="absolute bottom-3 left-3 z-20 max-w-xs sm:max-w-sm bg-gradient-to-r from-[#070e24]/95 to-[#0b1536]/95 border-2 border-cyan-400 rounded-xl p-2.5 shadow-[0_0_25px_rgba(0,255,255,0.4)] backdrop-blur-md animate-fadeIn">
                <div className="flex items-center gap-2.5">
                  <div className="relative w-14 h-14 sm:w-16 sm:h-16 rounded-lg bg-black/60 border border-cyan-500/40 p-1 overflow-hidden shrink-0">
                    <img
                      src={pinnedProduct.images[0]}
                      alt={pinnedProduct.name}
                      className="w-full h-full object-contain"
                    />
                    <span className="absolute top-0 left-0 bg-rose-600 text-white text-[8px] font-black px-1 rounded-br">
                      GHIM
                    </span>
                  </div>

                  <div className="min-w-0 flex-1">
                    <h4 className="text-xs font-black text-white truncate" title={pinnedProduct.name}>
                      {pinnedProduct.name}
                    </h4>
                    <p className="text-[10px] text-cyan-300 font-semibold truncate">
                      {pinnedProduct.series}
                    </p>
                    <div className="flex items-baseline gap-2 mt-0.5">
                      <span className="text-sm font-black text-amber-400">
                        {pinnedProduct.price.toLocaleString('vi-VN')}₫
                      </span>
                      {stockMap[pinnedProduct.id] !== undefined && (
                        <span className="text-[10px] text-emerald-400 font-bold">
                          (Còn {stockMap[pinnedProduct.id]} cái)
                        </span>
                      )}
                    </div>
                  </div>
                </div>

                <div className="flex items-center gap-2 mt-2 pt-2 border-t border-cyan-500/20">
                  <button
                    onClick={() => onSelectProduct(pinnedProduct)}
                    className="flex-1 bg-slate-800 hover:bg-slate-700 text-cyan-300 text-[11px] font-bold py-1 px-2 rounded-lg transition text-center"
                  >
                    Chi Tiết
                  </button>

                  <button
                    onClick={() => {
                      onAddToCart(pinnedProduct);
                      showToast(`Đã thêm [${pinnedProduct.name}] vào giỏ!`, 'success');
                    }}
                    className="bg-cyan-500 hover:bg-cyan-400 text-black text-[11px] font-black py-1 px-2.5 rounded-lg transition"
                    title="Thêm vào giỏ hàng"
                  >
                    <i className="fa-solid fa-cart-plus"></i>
                  </button>

                  <button
                    onClick={() => handleLiveOrderNow(pinnedProduct)}
                    className="flex-1 bg-gradient-to-r from-amber-400 to-rose-500 hover:from-amber-300 hover:to-rose-400 text-black text-[11px] font-black py-1 px-2.5 rounded-lg transition shadow-[0_0_10px_rgba(245,158,11,0.4)]"
                  >
                    ⚡ Mua Ngay
                  </button>
                </div>
              </div>
            )}

            {/* Quick Action Floating Buttons (Audience Only - Bottom-Right) */}
            {mode === 'audience' && (
              <div className="absolute bottom-3 right-3 z-20 flex flex-col gap-2">
                {/* Floating Heart Burst */}
                <button
                  onClick={() => {
                    if (filterProcessorRef.current) {
                      filterProcessorRef.current.spawnBurst(20);
                    }
                    showToast('❤️ Bạn vừa thả tim cho buổi Livestream!', 'info');
                  }}
                  className="w-11 h-11 rounded-full bg-rose-600/90 hover:bg-rose-500 text-white shadow-[0_0_15px_rgba(244,63,94,0.6)] flex items-center justify-center text-lg active:scale-90 transition cursor-pointer"
                  title="Thả tim bay màn hình"
                >
                  <i className="fa-solid fa-heart animate-pulse"></i>
                </button>

                {/* Floating In-Live Cart Button */}
                <button
                  onClick={() => setIsInLiveCartOpen(true)}
                  className="w-11 h-11 rounded-full bg-amber-500/90 hover:bg-amber-400 text-black shadow-[0_0_15px_rgba(245,158,11,0.5)] flex items-center justify-center text-lg active:scale-90 transition cursor-pointer relative"
                  title="Mở Giỏ Hàng Trong Live (Chốt Đơn Nhanh)"
                >
                  <i className="fa-solid fa-bag-shopping"></i>
                  <span className="absolute -top-1 -right-1 bg-rose-600 text-white text-[9px] font-black w-5 h-5 rounded-full flex items-center justify-center border-2 border-black">
                    {products.length}
                  </span>
                </button>
              </div>
            )}
          </div>

          {/* ========================================================================= */}
          {/* 3.1 STREAMER EXCLUSIVE CONTROL DECK (Viewers CANNOT have)                 */}
          {/* ========================================================================= */}
          {mode === 'streamer' && (
            <div className="space-y-3">
              {/* Broadcast Controls Bar */}
              <div className="bg-gradient-to-r from-[#0a1638] via-[#0d1d4d] to-[#0a1638] border-2 border-cyan-400/60 rounded-2xl p-3 shadow-xl space-y-3">
                <div className="flex items-center justify-between pb-2 border-b border-cyan-500/30">
                  <div className="flex items-center gap-2">
                    <span className="w-2.5 h-2.5 rounded-full bg-rose-500 animate-ping"></span>
                    <span className="text-xs font-black text-white uppercase tracking-wider">
                      Bảng Điều Khiển Luồng Phát (Broadcast Control): {activeRoom?.hostName}
                    </span>
                  </div>

                  <div className="flex items-center gap-2 text-xs font-bold text-cyan-300">
                    <span>Độ phân giải: <strong className="text-white">{videoConfig.resolution}</strong></span>
                    <span>•</span>
                    <span>FPS: <strong className="text-amber-300">{videoConfig.fps}</strong></span>
                    <span>•</span>
                    <span>Bitrate: <strong className="text-emerald-300">{videoConfig.bitrateMbps} Mbps</strong></span>
                  </div>
                </div>

                {/* Hardware Toggles: Camera, Mic with Noise Suppression, Stabilization */}
                <div className="grid grid-cols-1 sm:grid-cols-2 md:grid-cols-4 gap-2 text-xs">
                  {/* Camera Toggle */}
                  <button
                    onClick={handleToggleCamera}
                    className={`p-2.5 rounded-xl font-bold flex items-center justify-center gap-2 transition ${
                      isCameraEnabled 
                        ? 'bg-cyan-500/20 text-cyan-300 border border-cyan-400' 
                        : 'bg-rose-950/40 text-rose-300 border border-rose-500/40'
                    }`}
                  >
                    <i className={`fa-solid ${isCameraEnabled ? 'fa-video' : 'fa-video-slash'}`}></i>
                    <span>{isCameraEnabled ? 'Camera: Đang Bật' : 'Camera: Đã Tắt'}</span>
                  </button>

                  {/* Mic Toggle with Noise Suppression Indicator */}
                  <button
                    onClick={handleToggleMic}
                    className={`p-2.5 rounded-xl font-bold flex items-center justify-center gap-2 transition ${
                      isMicEnabled 
                        ? 'bg-emerald-500/20 text-emerald-300 border border-emerald-400' 
                        : 'bg-rose-950/40 text-rose-300 border border-rose-500/40'
                    }`}
                  >
                    <i className={`fa-solid ${isMicEnabled ? 'fa-microphone' : 'fa-microphone-slash'}`}></i>
                    <span>{isMicEnabled ? 'Mic: Khử Ồn Siêu Nhạy' : 'Mic: Đã Tắt'}</span>
                  </button>

                  {/* Image Stabilization Status */}
                  <button
                    onClick={() => {
                      setVideoConfig(prev => ({ ...prev, stabilization: !prev.stabilization }));
                      showToast('Đã đổi trạng thái chống rung camera!', 'info');
                    }}
                    className={`p-2.5 rounded-xl font-bold flex items-center justify-center gap-2 transition ${
                      videoConfig.stabilization 
                        ? 'bg-blue-500/20 text-blue-300 border border-blue-400' 
                        : 'bg-slate-800 text-slate-400 border border-slate-700'
                    }`}
                  >
                    <i className="fa-solid fa-hand"></i>
                    <span>{videoConfig.stabilization ? 'Chống Rung: BẬT' : 'Chống Rung: TẮT'}</span>
                  </button>

                  {/* Continuous Auto-Focus Status */}
                  <button
                    onClick={() => {
                      setVideoConfig(prev => ({ ...prev, autofocus: !prev.autofocus }));
                      showToast('Đã đổi chế độ tự động lấy nét!', 'info');
                    }}
                    className={`p-2.5 rounded-xl font-bold flex items-center justify-center gap-2 transition ${
                      videoConfig.autofocus 
                        ? 'bg-purple-500/20 text-purple-300 border border-purple-400' 
                        : 'bg-slate-800 text-slate-400 border border-slate-700'
                    }`}
                  >
                    <i className="fa-solid fa-crosshairs"></i>
                    <span>{videoConfig.autofocus ? 'Lấy Nét: TỰ ĐỘNG' : 'Lấy Nét: THỦ CÔNG'}</span>
                  </button>
                </div>

                {/* Mic vocal indicator text */}
                <div className="bg-[#060e22] px-3 py-2 rounded-xl border border-cyan-500/20 text-[11px] text-slate-300 flex items-center justify-between">
                  <div className="flex items-center gap-2">
                    <i className="fa-solid fa-headset text-cyan-400"></i>
                    <span>Cấu hình Mic Studio: <strong className="text-white">Thu giọng nhạy cao + Triệt tạp âm môi trường chủ động (Echo Cancellation & Noise Suppression ON)</strong></span>
                  </div>
                  <span className="text-[10px] text-emerald-400 font-mono">48 kHz · Mono Studio</span>
                </div>
              </div>

              {/* E-Commerce Moderator & Admin Controls */}
              <div className="bg-[#091432] border border-cyan-500/30 rounded-2xl p-4 shadow-xl space-y-4">
                
                {/* 1. Live Sales Stats Dashboard */}
                <div className="grid grid-cols-2 sm:grid-cols-3 gap-3">
                  <div className="bg-[#060a18] p-3 rounded-xl border border-cyan-500/20">
                    <span className="text-[10px] text-slate-400 uppercase font-bold block mb-1">
                      Doanh Thu Phiên Live
                    </span>
                    <span className="text-lg font-black text-amber-400">
                      {(activeRoom?.totalRevenue || 0).toLocaleString('vi-VN')}₫
                    </span>
                  </div>

                  <div className="bg-[#060a18] p-3 rounded-xl border border-cyan-500/20">
                    <span className="text-[10px] text-slate-400 uppercase font-bold block mb-1">
                      Số Đơn Đã Chốt
                    </span>
                    <span className="text-lg font-black text-emerald-400">
                      {activeRoom?.totalOrders || 0} Đơn Hàng
                    </span>
                  </div>

                  <div className="col-span-2 sm:col-span-1 bg-[#060a18] p-3 rounded-xl border border-cyan-500/20 flex flex-col justify-between">
                    <span className="text-[10px] text-slate-400 uppercase font-bold block mb-1">
                      Sản Phẩm Đang Ghim
                    </span>
                    <span className="text-xs font-black text-cyan-300 truncate">
                      {pinnedProduct?.name || 'Chưa ghim sản phẩm'}
                    </span>
                  </div>
                </div>

                {/* 2. Streamer Quick Action Buttons */}
                <div className="flex items-center gap-2 flex-wrap pt-1">
                  {/* Pin Product */}
                  <button
                    onClick={() => setIsPinPickerOpen(true)}
                    className="bg-amber-500 hover:bg-amber-400 text-black text-xs font-black px-3.5 py-2 rounded-xl transition flex items-center gap-1.5 shadow"
                  >
                    <i className="fa-solid fa-thumbtack"></i>
                    <span>{pinnedProduct ? 'Đổi Sản Phẩm Ghim' : 'Ghim Sản Phẩm'}</span>
                  </button>

                  {pinnedProduct && (
                    <button
                      onClick={handleUnpinProduct}
                      className="bg-slate-800 hover:bg-slate-700 text-slate-300 text-xs font-bold px-3 py-2 rounded-xl transition"
                    >
                      Bỏ Ghim
                    </button>
                  )}

                  {/* Trigger Flash Sale */}
                  <button
                    onClick={() => {
                      setFlashSecondsLeft(300);
                      showToast('⚡ Đã kích hoạt Flash Sale 5 Phút trên toàn bộ phòng Live!', 'success');
                    }}
                    className="bg-rose-600 hover:bg-rose-500 text-white text-xs font-black px-3.5 py-2 rounded-xl transition flex items-center gap-1.5 shadow"
                  >
                    <i className="fa-solid fa-fire"></i>
                    <span>Tung Mã Flash Sale 5 Phút</span>
                  </button>

                  {/* Live Stock Inventory Management */}
                  <button
                    onClick={() => setIsStockModalOpen(true)}
                    className="bg-cyan-600 hover:bg-cyan-500 text-white text-xs font-black px-3.5 py-2 rounded-xl transition flex items-center gap-1.5 shadow"
                  >
                    <i className="fa-solid fa-boxes-stacked"></i>
                    <span>Quản Lý Kho Hàng Live</span>
                  </button>

                  {/* Toggle Chat Lock (Tắt chat tổng) */}
                  <button
                    onClick={handleToggleLockChat}
                    className={`text-xs font-black px-3.5 py-2 rounded-xl transition flex items-center gap-1.5 shadow ${
                      activeRoom?.isChatLocked
                        ? 'bg-emerald-600 hover:bg-emerald-500 text-white'
                        : 'bg-purple-600 hover:bg-purple-500 text-white'
                    }`}
                  >
                    <i className={`fa-solid ${activeRoom?.isChatLocked ? 'fa-lock-open' : 'fa-lock'}`}></i>
                    <span>{activeRoom?.isChatLocked ? 'Mở Lại Bình Luận' : 'Khóa Bình Luận (Tắt Chat)'}</span>
                  </button>

                  {/* Admin Viewer Moderation */}
                  <button
                    onClick={() => setIsAdminModOpen(true)}
                    className="bg-slate-800 hover:bg-slate-700 text-cyan-300 border border-cyan-500/40 text-xs font-bold px-3.5 py-2 rounded-xl transition flex items-center gap-1.5"
                  >
                    <i className="fa-solid fa-shield-halved"></i>
                    <span>Kick / Block Người Xem</span>
                  </button>

                  {/* Screen Share Button (Streamer Exclusive - 100% Real getDisplayMedia) */}
                  <button
                    onClick={handleToggleScreenShare}
                    className={`text-xs font-black px-4 py-2.5 rounded-xl transition flex items-center gap-2 shadow-lg cursor-pointer ${
                      isScreenSharing
                        ? 'bg-amber-400 text-black border-2 border-amber-300 animate-pulse shadow-[0_0_15px_rgba(251,191,36,0.5)]'
                        : 'bg-indigo-600 hover:bg-indigo-500 text-white border border-indigo-400/40'
                    }`}
                    title={isScreenSharing ? "Dừng chia sẻ màn hình máy tính" : "Chia sẻ màn hình thật từ máy tính/cửa sổ/tab của streamer"}
                  >
                    <i className="fa-solid fa-desktop text-sm"></i>
                    <span>{isScreenSharing ? '🖥️ Dừng Chia Sẻ Màn Hình' : '🖥️ Chia Sẻ Màn Hình Thật'}</span>
                  </button>

                  {/* End Live / Close Room Button (Streamer Exclusive - custom in-app modal) */}
                  <button
                    onClick={handleEndLiveRoom}
                    className="bg-gradient-to-r from-rose-700 to-rose-800 hover:from-rose-600 hover:to-rose-700 text-white text-xs font-black px-4 py-2.5 rounded-xl transition flex items-center gap-2 shadow-[0_0_15px_rgba(244,63,94,0.4)] cursor-pointer border border-rose-500/50"
                    title="Đóng phòng phát sóng và kết thúc livestream an toàn"
                  >
                    <i className="fa-solid fa-power-off text-sm"></i>
                    <span>🔴 Đóng Live (Kết Thúc)</span>
                  </button>
                </div>
              </div>
            </div>
          )}

          {/* ========================================================================= */}
          {/* 3.2 AUDIENCE EXCLUSIVE SHOPPING & INTERACTIVE BANNER                       */}
          {/* ========================================================================= */}
          {mode === 'audience' && (
            <div className="bg-[#09122c] border border-cyan-500/30 rounded-2xl p-3 shadow-lg flex items-center justify-between gap-3">
              <div className="flex items-center gap-3">
                <div className="w-10 h-10 rounded-xl bg-purple-600/30 border border-purple-500/40 flex items-center justify-center text-purple-300 text-lg">
                  <i className="fa-solid fa-wand-magic-sparkles"></i>
                </div>
                <div>
                  <h4 className="text-xs font-black text-white uppercase tracking-wider">
                    Gương AR Cá Nhân & Thử Đồ Ảo (Chỉ Bạn Thấy)
                  </h4>
                  <p className="text-[11px] text-slate-300">
                    Bật camera của riêng bạn để ướm thử son môi, kính thời trang hoặc tự áp filter mịn da mà không ảnh hưởng streamer!
                  </p>
                </div>
              </div>

              <div className="flex items-center gap-2 shrink-0">
                <button
                  onClick={handleOpenViewerAr}
                  className="bg-gradient-to-r from-purple-500 to-pink-500 hover:brightness-110 text-white font-black text-xs px-3.5 py-2 rounded-xl shadow transition flex items-center gap-1.5 cursor-pointer"
                >
                  <i className="fa-solid fa-camera"></i>
                  <span>Mở Gương AR</span>
                </button>

                <button
                  onClick={() => setIsInLiveCartOpen(true)}
                  className="bg-amber-500 hover:bg-amber-400 text-black font-black text-xs px-3.5 py-2 rounded-xl shadow transition flex items-center gap-1.5 cursor-pointer"
                >
                  <i className="fa-solid fa-cart-shopping"></i>
                  <span>Xem Giỏ Live ({products.length})</span>
                </button>
              </div>
            </div>
          )}
        </section>

        {/* ========================================================= */}
        {/* RIGHT: DEDICATED REAL LIVE CHAT (ZERO FAKE BOT ACCOUNTS)   */}
        {/* ========================================================= */}
        <section className="lg:col-span-4 bg-[#070c1e] border border-cyan-500/30 rounded-2xl flex flex-col h-[700px] shadow-2xl overflow-hidden relative">
          
          {/* Chat Header */}
          <div className="bg-[#09122c] border-b border-cyan-500/30 p-3 flex items-center justify-between">
            <div className="flex items-center gap-2">
              <i className="fa-solid fa-comments text-cyan-400 text-sm"></i>
              <h3 className="text-xs font-black uppercase text-white tracking-wider">
                Trò Chuyện Thực Tế (Không Bot)
              </h3>
            </div>

            <div className="flex items-center gap-2">
              {activeRoom?.isChatLocked && (
                <span className="text-[9px] bg-rose-500/20 text-rose-300 border border-rose-500/40 px-2 py-0.5 rounded font-bold">
                  🔒 Đã Khóa
                </span>
              )}
              <span className="text-[10px] text-emerald-400 bg-emerald-950/80 border border-emerald-500/30 px-2 py-0.5 rounded-full font-bold">
                Kênh: {activeRoom?.hostName}
              </span>
            </div>
          </div>

          {/* Real Chat Messages List */}
          <div ref={chatScrollRef} className="flex-1 overflow-y-auto p-3 space-y-3 text-xs">
            {messages.length === 0 ? (
              <div className="h-full flex flex-col items-center justify-center text-center p-6 text-slate-400 space-y-2">
                <div className="w-12 h-12 rounded-full bg-slate-800/80 border border-slate-700 flex items-center justify-center text-cyan-400 text-xl">
                  <i className="fa-regular fa-comment-dots"></i>
                </div>
                <p className="text-xs font-bold text-slate-300">
                  Chưa có bình luận nào trong phòng này
                </p>
                <p className="text-[11px] text-slate-500">
                  Phòng live chỉ hiển thị bình luận thật từ người dùng. Hãy đặt câu hỏi và giao lưu cùng streamer!
                </p>
              </div>
            ) : (
              messages.map((msg) => (
                <div 
                  key={msg.id} 
                  className={`p-2.5 rounded-xl border transition-all ${
                    msg.isAdmin 
                      ? 'bg-gradient-to-r from-amber-950/40 to-[#0a1432] border-amber-500/40 text-amber-100'
                      : 'bg-[#0a1128]/80 border-slate-800 text-slate-200'
                  }`}
                >
                  <div className="flex items-center justify-between gap-1 mb-1">
                    <div className="flex items-center gap-1.5 min-w-0">
                      <img
                        src={msg.senderAvatar}
                        alt={msg.senderName}
                        className="w-5 h-5 rounded-full object-cover border border-cyan-400/40 shrink-0"
                      />
                      <span className="font-extrabold text-white truncate text-[11px]">
                        {msg.senderName}
                      </span>
                      {msg.senderBadge && (
                        <span className={`text-[9px] font-black px-1.5 py-0.2 rounded shrink-0 ${
                          msg.isAdmin ? 'bg-amber-500 text-black' : 'bg-cyan-500/20 text-cyan-300'
                        }`}>
                          {msg.senderBadge}
                        </span>
                      )}
                    </div>

                    <div className="flex items-center gap-1 shrink-0">
                      <span className="text-[10px] text-slate-500 font-mono">{msg.createdAt}</span>
                      
                      {/* Streamer / Mod actions: Kick, Ban, Hide (Streamer only) */}
                      {(mode === 'streamer' || currentUser?.role === 'admin') && !msg.isAdmin && (
                        <div className="flex items-center gap-1 ml-1">
                          <button
                            onClick={() => handleHideMessage(msg.id)}
                            className="text-[10px] text-slate-400 hover:text-amber-400 p-0.5"
                            title="Ẩn tin nhắn này"
                          >
                            <i className="fa-solid fa-eye-slash"></i>
                          </button>
                          <button
                            onClick={() => handleKickUser(msg.senderId, msg.senderName)}
                            className="text-[10px] text-slate-400 hover:text-rose-400 p-0.5"
                            title="Kick người xem"
                          >
                            <i className="fa-solid fa-user-xmark"></i>
                          </button>
                          <button
                            onClick={() => handleBanUser(msg.senderId, msg.senderName)}
                            className="text-[10px] text-slate-400 hover:text-red-500 p-0.5"
                            title="Cấm vĩnh viễn"
                          >
                            <i className="fa-solid fa-ban"></i>
                          </button>
                        </div>
                      )}
                    </div>
                  </div>

                  {/* Message Text with Link Detection */}
                  {msg.text && (
                    <p className="text-[11px] leading-relaxed break-words text-slate-100">
                      {msg.text.split(/(https?:\/\/[^\s]+)/g).map((chunk, i) => {
                        if (chunk.match(/https?:\/\/[^\s]+/)) {
                          return (
                            <a
                              key={i}
                              href={chunk}
                              target="_blank"
                              rel="noopener noreferrer"
                              className="text-cyan-400 font-bold hover:underline inline-flex items-center gap-1"
                            >
                              <span>{chunk}</span>
                              <i className="fa-solid fa-arrow-up-right-from-square text-[9px]"></i>
                            </a>
                          );
                        }
                        return chunk;
                      })}
                    </p>
                  )}

                  {/* Rich Link Preview Box */}
                  {msg.links && msg.links.length > 0 && (
                    <div className="mt-2 space-y-1.5">
                      {msg.links.map((link, idx) => (
                        <a
                          key={idx}
                          href={link.url}
                          target="_blank"
                          rel="noopener noreferrer"
                          className="block bg-black/60 hover:bg-black/80 border border-cyan-500/30 rounded-lg p-2 transition group"
                        >
                          <div className="flex items-center gap-2">
                            {link.image && (
                              <img
                                src={link.image}
                                alt="Preview"
                                className="w-10 h-10 object-contain rounded bg-[#070d1e] p-0.5 shrink-0"
                              />
                            )}
                            <div className="min-w-0 flex-1">
                              <div className="text-[11px] font-black text-cyan-300 group-hover:underline truncate">
                                {link.title}
                              </div>
                              <div className="text-[10px] text-slate-400 line-clamp-1">
                                {link.description}
                              </div>
                              <div className="text-[9px] text-slate-500 font-mono mt-0.5">
                                🌐 {link.domain}
                              </div>
                            </div>
                          </div>
                        </a>
                      ))}
                    </div>
                  )}

                  {/* File / Image Attachment Preview with HTML5 download */}
                  {msg.file && (
                    <div className="mt-2">
                      {msg.file.mimeType.startsWith('image/') ? (
                        <div className="rounded-lg overflow-hidden border border-cyan-500/40 bg-black/50 max-w-[220px]">
                          <img
                            src={msg.file.url}
                            alt={msg.file.name}
                            className="w-full max-h-40 object-cover cursor-pointer hover:opacity-90"
                            onClick={() => window.open(msg.file?.url, '_blank')}
                          />
                          <div className="p-1.5 flex items-center justify-between text-[10px] bg-black/75">
                            <span className="truncate text-slate-300">{msg.file.name}</span>
                            <a
                              href={msg.file.url}
                              download={msg.file.name}
                              className="text-cyan-400 hover:text-cyan-300 font-bold ml-1"
                              title="Tải ảnh về máy"
                            >
                              <i className="fa-solid fa-download"></i>
                            </a>
                          </div>
                        </div>
                      ) : (
                        <div className="flex items-center justify-between bg-black/50 border border-cyan-500/30 rounded-lg p-2 max-w-xs">
                          <div className="flex items-center gap-2 min-w-0">
                            <i className="fa-solid fa-file-lines text-cyan-400 text-lg"></i>
                            <div className="min-w-0">
                              <div className="text-[11px] font-bold text-white truncate">{msg.file.name}</div>
                              <div className="text-[9px] text-slate-400">
                                {(msg.file.size / 1024).toFixed(1)} KB
                              </div>
                            </div>
                          </div>
                          <a
                            href={msg.file.url}
                            download={msg.file.name}
                            className="bg-cyan-500/20 hover:bg-cyan-500/30 text-cyan-300 font-bold text-xs px-2.5 py-1 rounded transition flex items-center gap-1 shrink-0"
                            title="Tải về máy qua HTML5 download"
                          >
                            <i className="fa-solid fa-download"></i> Tải
                          </a>
                        </div>
                      )}
                    </div>
                  )}
                </div>
              ))
            )}
          </div>

          {/* Chat Input Bar */}
          <div className="bg-[#091129] border-t border-cyan-500/30 p-2.5">
            {isUserBanned || isUserKicked ? (
              <div className="text-center py-2 text-rose-400 text-xs font-bold bg-rose-950/40 rounded-xl border border-rose-500/30">
                🚫 Bạn đã bị chặn bình luận trong phòng Live này.
              </div>
            ) : activeRoom?.isChatLocked && mode !== 'streamer' && currentUser?.role !== 'admin' ? (
              /* Notice when streamer locks chat for viewers */
              <div className="text-center py-2 text-amber-300 text-xs font-bold bg-amber-950/40 rounded-xl border border-amber-500/30 px-2">
                🔒 Streamer đang tạm khóa bình luận phòng live để tập trung giới thiệu sản phẩm.
              </div>
            ) : (
              <form onSubmit={handleSendMessage} className="space-y-2">
                <div className="flex items-center gap-2">
                  <input
                    type="text"
                    value={chatInput}
                    onChange={(e) => setChatInput(e.target.value)}
                    placeholder={
                      mode === 'streamer' 
                        ? 'Bình luận với tư cách Streamer/Chủ kênh...' 
                        : 'Bình luận thực tế, hỏi đáp, gửi link...'
                    }
                    className="flex-1 bg-[#050917] border border-cyan-500/40 rounded-xl px-3 py-2 text-xs text-white placeholder-slate-500 focus:outline-none focus:border-cyan-400 transition"
                  />

                  {/* Hidden File Input */}
                  <input
                    type="file"
                    ref={fileInputRef}
                    onChange={handleFileUpload}
                    className="hidden"
                  />

                  {/* File Upload Button */}
                  <button
                    type="button"
                    onClick={() => fileInputRef.current?.click()}
                    disabled={isUploadingFile}
                    className="bg-slate-800 hover:bg-slate-700 text-cyan-300 p-2 rounded-xl transition cursor-pointer"
                    title="Gửi ảnh hoặc tệp tin lên Live Chat"
                  >
                    <i className="fa-solid fa-paperclip text-xs"></i>
                  </button>

                  {/* Send Button */}
                  <button
                    type="submit"
                    disabled={!chatInput.trim()}
                    className="bg-cyan-500 hover:bg-cyan-400 disabled:opacity-50 text-black font-black px-3 py-2 rounded-xl text-xs transition cursor-pointer flex items-center gap-1"
                  >
                    <i className="fa-solid fa-paper-plane"></i>
                  </button>
                </div>

                <div className="flex items-center justify-between text-[10px] text-slate-400 px-1">
                  <span>🔒 Bình luận 100% người thật · Không tài khoản ảo</span>
                  {mode === 'audience' && (
                    <button
                      type="button"
                      onClick={() => {
                        if (filterProcessorRef.current) filterProcessorRef.current.spawnBurst(15);
                      }}
                      className="text-rose-400 hover:text-rose-300 font-bold"
                    >
                      ❤️ Bắn Tim
                    </button>
                  )}
                </div>
              </form>
            )}
          </div>
        </section>
        </>
      )}
      </main>

      {/* ========================================================================= */}
      {/* MODAL 1: AUDIENCE EXCLUSIVE PERSONAL AR MIRROR & TRY-ON MODAL             */}
      {/* ========================================================================= */}
      {isViewerArOpen && (
        <div className="fixed inset-0 z-50 bg-black/90 backdrop-blur-md flex items-center justify-center p-3 sm:p-5">
          <div className="bg-[#0b1430] border-2 border-pink-500/80 rounded-3xl p-5 max-w-2xl w-full max-h-[92vh] flex flex-col shadow-[0_0_50px_rgba(236,72,153,0.35)] animate-scaleUp">
            
            {/* Header */}
            <div className="flex items-center justify-between pb-3 border-b border-pink-500/30 mb-3">
              <div className="flex items-center gap-2">
                <i className="fa-solid fa-wand-magic-sparkles text-pink-400 text-lg"></i>
                <div>
                  <h3 className="text-sm font-black text-white uppercase tracking-wider">
                    Gương AR Cá Nhân & Thử Đồ Ảo (Chỉ Bạn Thấy)
                  </h3>
                  <p className="text-[10px] text-pink-300">
                    Camera & filter hoạt động trên máy của bạn — Streamer và người xem khác không thấy luồng này!
                  </p>
                </div>
              </div>

              <button
                onClick={handleCloseViewerAr}
                className="w-8 h-8 rounded-full bg-slate-800 text-slate-300 hover:text-white flex items-center justify-center cursor-pointer"
              >
                <i className="fa-solid fa-xmark"></i>
              </button>
            </div>

            {/* Main Mirror Viewport */}
            <div className="relative bg-black rounded-2xl overflow-hidden border border-pink-500/40 aspect-video flex items-center justify-center mb-3">
              <video
                ref={viewerVideoRef}
                playsInline
                muted
                className="hidden"
              />

              <canvas
                ref={viewerCanvasRef}
                width={640}
                height={480}
                className="w-full h-full object-contain"
              />

              <div className="absolute top-2 left-2 bg-black/80 backdrop-blur-sm text-pink-300 border border-pink-500/40 text-[10px] font-bold px-2 py-0.5 rounded">
                🪞 Gương AR: {FILTERS_LIST.find(f => f.id === viewerActiveFilter)?.name || 'Mặc định'}
              </div>

              {/* Virtual Try-On Details Overlay */}
              {viewerActiveFilter === 'virtual-lipstick' && (
                <div className="absolute bottom-2 left-2 bg-black/85 backdrop-blur-md border border-rose-500/40 text-rose-300 text-[11px] font-bold px-2.5 py-1 rounded-lg">
                  💄 Đang thử màu son: <span className="text-white">{viewerLipstickShade}</span>
                </div>
              )}

              {viewerActiveFilter === 'designer-glasses' && (
                <div className="absolute bottom-2 left-2 bg-black/85 backdrop-blur-md border border-cyan-500/40 text-cyan-300 text-[11px] font-bold px-2.5 py-1 rounded-lg">
                  👓 Đang ướm thử kính: <span className="text-white">{viewerGlassesStyle}</span>
                </div>
              )}
            </div>

            {/* 10 AR Filters Selector */}
            <div className="space-y-2 mb-3">
              <span className="text-[11px] font-bold text-slate-300 block">
                Chọn Filter AR & Làm Đẹp:
              </span>
              <div className="flex items-center gap-1.5 overflow-x-auto pb-1 no-scrollbar">
                {FILTERS_LIST.map((f) => {
                  const isSel = viewerActiveFilter === f.id;
                  return (
                    <button
                      key={f.id}
                      onClick={() => {
                        setViewerActiveFilter(f.id);
                        if (viewerFilterProcessorRef.current) {
                          viewerFilterProcessorRef.current.setFilter(f.id);
                        }
                      }}
                      className={`px-2.5 py-1.5 rounded-xl text-xs font-bold shrink-0 transition flex items-center gap-1.5 cursor-pointer ${
                        isSel
                          ? 'bg-gradient-to-r from-pink-500 to-purple-600 text-white shadow-[0_0_12px_rgba(236,72,153,0.5)] scale-105'
                          : 'bg-slate-800 text-slate-300 hover:bg-slate-700'
                      }`}
                    >
                      <i className={`fa-solid ${f.icon} text-xs`}></i>
                      <span>{f.name}</span>
                    </button>
                  );
                })}
              </div>
            </div>

            {/* Virtual Try-On Options (Son môi & Kính mắt) */}
            {viewerActiveFilter === 'virtual-lipstick' && (
              <div className="bg-[#070d1e] p-2.5 rounded-xl border border-rose-500/30 mb-3 space-y-1.5 text-xs">
                <span className="font-bold text-rose-300">Chọn Màu Son Môi AR Để Ướm Lên Môi:</span>
                <div className="flex items-center gap-2">
                  {['Ruby Red #d62246', 'Coral Pink #f76c6c', 'Velvet Cherry #800e13', 'Peach Glow #ff8fab'].map((shade) => (
                    <button
                      key={shade}
                      onClick={() => {
                        setViewerLipstickShade(shade);
                        showToast(`Đã áp dụng màu son ${shade}`, 'info');
                      }}
                      className={`px-2.5 py-1 rounded-lg font-bold transition text-[11px] ${
                        viewerLipstickShade === shade
                          ? 'bg-rose-600 text-white shadow'
                          : 'bg-slate-800 text-slate-300 hover:text-white'
                      }`}
                    >
                      {shade.split(' ')[0]}
                    </button>
                  ))}
                </div>
              </div>
            )}

            {viewerActiveFilter === 'designer-glasses' && (
              <div className="bg-[#070d1e] p-2.5 rounded-xl border border-cyan-500/30 mb-3 space-y-1.5 text-xs">
                <span className="font-bold text-cyan-300">Chọn Kiểu Kính Mắt Thời Trang Face Mesh:</span>
                <div className="flex items-center gap-2">
                  {['Aviator Titan', 'Wayfarer Black', 'Rider Visor Red', 'Cyber Neon Gold'].map((style) => (
                    <button
                      key={style}
                      onClick={() => {
                        setViewerGlassesStyle(style);
                        showToast(`Đã đeo thử kiểu kính: ${style}`, 'info');
                      }}
                      className={`px-2.5 py-1 rounded-lg font-bold transition text-[11px] ${
                        viewerGlassesStyle === style
                          ? 'bg-cyan-500 text-black shadow'
                          : 'bg-slate-800 text-slate-300 hover:text-white'
                      }`}
                    >
                      {style}
                    </button>
                  ))}
                </div>
              </div>
            )}

            {/* Footer Actions */}
            <div className="flex items-center gap-2 pt-2 border-t border-slate-800">
              <button
                onClick={handleCloseViewerAr}
                className="flex-1 bg-slate-800 hover:bg-slate-700 text-slate-300 font-bold py-2 rounded-xl text-xs transition"
              >
                Đóng Gương AR
              </button>

              {pinnedProduct && (
                <button
                  onClick={() => {
                    handleCloseViewerAr();
                    handleLiveOrderNow(pinnedProduct);
                  }}
                  className="flex-1 bg-gradient-to-r from-amber-400 to-rose-500 hover:brightness-110 text-black font-black py-2 rounded-xl text-xs transition shadow-lg"
                >
                  ⚡ Đặt Mua Món Đang Thử ({pinnedProduct.price.toLocaleString('vi-VN')}₫)
                </button>
              )}
            </div>
          </div>
        </div>
      )}

      {/* ========================================================================= */}
      {/* MODAL 2: REQUIREMENT 3 CAMERA MISSING NOTICE MODAL                        */}
      {/* ========================================================================= */}
      {cameraError && (
        <div className="fixed inset-0 z-50 bg-black/85 backdrop-blur-md flex items-center justify-center p-4">
          <div className="bg-gradient-to-b from-[#101a38] to-[#070c1e] border-2 border-rose-500 rounded-3xl p-6 max-w-md w-full shadow-[0_0_50px_rgba(244,63,94,0.4)] text-center animate-scaleUp">
            <div className="w-16 h-16 rounded-full bg-rose-500/20 border-2 border-rose-500 flex items-center justify-center mx-auto mb-4 text-rose-400 text-3xl">
              <i className="fa-solid fa-video-slash"></i>
            </div>

            <h3 className="text-lg font-black text-white uppercase tracking-wider mb-2">
              THÔNG BÁO THIẾT BỊ CAMERA
            </h3>

            {/* Requirement 3 Exact wording display */}
            <p className="text-sm font-bold text-rose-300 mb-6 bg-rose-950/50 p-3 rounded-xl border border-rose-500/30">
              {cameraError}
            </p>

            <div className="flex flex-col gap-2">
              <button
                onClick={() => {
                  setCameraError(null);
                  setMode('audience');
                  showToast('Đã chuyển sang chế độ Khán Giả Xem Live mượt mà!', 'info');
                }}
                className="w-full bg-gradient-to-r from-cyan-400 to-blue-500 hover:from-cyan-300 hover:to-blue-400 text-black font-black py-2.5 rounded-xl text-sm transition shadow-lg cursor-pointer"
              >
                <i className="fa-solid fa-tv mr-1.5"></i> Chuyển Sang Chế Độ Khán Giả Xem Live
              </button>

              <button
                onClick={() => setCameraError(null)}
                className="w-full bg-slate-800 hover:bg-slate-700 text-slate-300 font-bold py-2 rounded-xl text-xs transition"
              >
                Đóng
              </button>
            </div>
          </div>
        </div>
      )}

      {/* ========================================================================= */}
      {/* MODAL 3: IN-LIVE QUICK SHOPPING CART (POPUP DRAWER - AUDIENCE ONLY)       */}
      {/* ========================================================================= */}
      {isInLiveCartOpen && mode === 'audience' && (
        <div className="fixed inset-0 z-50 bg-black/80 backdrop-blur-sm flex justify-end">
          <div className="bg-[#091129] border-l border-cyan-500/30 w-full max-w-md h-full flex flex-col p-4 shadow-2xl animate-slideLeft">
            <div className="flex items-center justify-between pb-3 border-b border-cyan-500/20">
              <div className="flex items-center gap-2">
                <i className="fa-solid fa-bag-shopping text-amber-400 text-lg"></i>
                <h3 className="text-sm font-black text-white uppercase tracking-wider">
                  Sản Phẩm Trong Buổi Live ({products.length})
                </h3>
              </div>
              <button
                onClick={() => setIsInLiveCartOpen(false)}
                className="w-8 h-8 rounded-full bg-slate-800 text-slate-300 hover:text-white flex items-center justify-center cursor-pointer"
              >
                <i className="fa-solid fa-xmark"></i>
              </button>
            </div>

            <div className="flex-1 overflow-y-auto py-3 space-y-3">
              {products.map((p) => {
                const stock = stockMap[p.id] ?? 10;
                return (
                  <div
                    key={p.id}
                    className="bg-[#060a18] border border-cyan-500/20 rounded-xl p-3 flex items-center gap-3 hover:border-cyan-400/50 transition"
                  >
                    <img
                      src={p.images[0]}
                      alt={p.name}
                      className="w-16 h-16 object-contain rounded-lg bg-black/40 p-1 shrink-0"
                    />
                    <div className="min-w-0 flex-1">
                      <h4 className="text-xs font-bold text-white truncate" title={p.name}>
                        {p.name}
                      </h4>
                      <p className="text-[10px] text-cyan-300">{p.series}</p>
                      <div className="flex items-center gap-2 mt-1">
                        <span className="text-xs font-black text-amber-400">
                          {p.price.toLocaleString('vi-VN')}₫
                        </span>
                        <span className="text-[10px] text-emerald-400 font-bold">
                          (Kho: {stock})
                        </span>
                      </div>
                    </div>

                    <div className="flex flex-col gap-1.5 shrink-0">
                      <button
                        onClick={() => handleLiveOrderNow(p)}
                        className="bg-gradient-to-r from-amber-400 to-rose-500 hover:from-amber-300 hover:to-rose-400 text-black text-[10px] font-black px-2.5 py-1.5 rounded-lg transition shadow"
                      >
                        ⚡ Chốt Ngay
                      </button>
                      <button
                        onClick={() => {
                          onAddToCart(p);
                          showToast(`Đã thêm [${p.name}] vào giỏ`, 'success');
                        }}
                        className="bg-slate-800 hover:bg-slate-700 text-cyan-300 text-[10px] font-bold px-2 py-1 rounded-lg transition"
                      >
                        + Giỏ Hàng
                      </button>
                    </div>
                  </div>
                );
              })}
            </div>

            <div className="pt-3 border-t border-cyan-500/20 text-center">
              <p className="text-[11px] text-slate-400 mb-2">
                Áp mã <span className="font-bold text-amber-300">LIVEVIP50</span> để được giảm thêm 15% tối đa 250k
              </p>
              <button
                onClick={() => setIsInLiveCartOpen(false)}
                className="w-full bg-cyan-500 hover:bg-cyan-400 text-black font-black py-2 rounded-xl text-xs transition cursor-pointer"
              >
                Tiếp Tục Xem Live
              </button>
            </div>
          </div>
        </div>
      )}

      {/* ========================================================================= */}
      {/* MODAL 4: STREAMER VIDEO & SVC ADVANCED CONFIG MODAL                       */}
      {/* ========================================================================= */}
      {isConfigModalOpen && mode === 'streamer' && (
        <div className="fixed inset-0 z-50 bg-black/85 backdrop-blur-md flex items-center justify-center p-4">
          <div className="bg-[#0b1430] border-2 border-cyan-400 rounded-3xl p-6 max-w-lg w-full shadow-2xl animate-scaleUp">
            <div className="flex items-center justify-between pb-3 border-b border-cyan-500/30 mb-4">
              <div className="flex items-center gap-2">
                <i className="fa-solid fa-sliders text-cyan-400 text-lg"></i>
                <h3 className="text-sm font-black text-white uppercase tracking-wider">
                  Cấu Hình Video Phát Sóng
                </h3>
              </div>
              <button
                onClick={() => setIsConfigModalOpen(false)}
                className="w-7 h-7 rounded-full bg-slate-800 text-slate-300 hover:text-white flex items-center justify-center"
              >
                <i className="fa-solid fa-xmark text-xs"></i>
              </button>
            </div>

            <div className="space-y-4 text-xs">
              <div>
                <label className="block text-slate-300 font-bold mb-1.5">
                  Độ Phân Giải Cố Định:
                </label>
                <div className="grid grid-cols-2 gap-2">
                  <button
                    type="button"
                    onClick={() => setVideoConfig(prev => ({ ...prev, resolution: '1080p' }))}
                    className={`py-2 px-3 rounded-xl font-bold border transition ${
                      videoConfig.resolution === '1080p'
                        ? 'bg-cyan-500 text-black border-cyan-400 shadow-[0_0_12px_rgba(0,255,255,0.4)]'
                        : 'bg-slate-800 text-slate-300 border-slate-700'
                    }`}
                  >
                    1080p Full HD (1920x1080)
                  </button>
                  <button
                    type="button"
                    onClick={() => setVideoConfig(prev => ({ ...prev, resolution: '720p' }))}
                    className={`py-2 px-3 rounded-xl font-bold border transition ${
                      videoConfig.resolution === '720p'
                        ? 'bg-cyan-500 text-black border-cyan-400 shadow-[0_0_12px_rgba(0,255,255,0.4)]'
                        : 'bg-slate-800 text-slate-300 border-slate-700'
                    }`}
                  >
                    720p HD (1280x720)
                  </button>
                </div>
              </div>

              <div>
                <label className="block text-slate-300 font-bold mb-1.5">
                  Khóa Khung Hình (Framerate Lock):
                </label>
                <div className="grid grid-cols-2 gap-2">
                  <button
                    type="button"
                    onClick={() => setVideoConfig(prev => ({ ...prev, fps: 60 }))}
                    className={`py-2 px-3 rounded-xl font-bold border transition ${
                      videoConfig.fps === 60
                        ? 'bg-amber-400 text-black border-amber-300 shadow-[0_0_12px_rgba(245,158,11,0.4)]'
                        : 'bg-slate-800 text-slate-300 border-slate-700'
                    }`}
                  >
                    ⚡ Khóa 60 FPS (Siêu Mượt)
                  </button>
                  <button
                    type="button"
                    onClick={() => setVideoConfig(prev => ({ ...prev, fps: 30 }))}
                    className={`py-2 px-3 rounded-xl font-bold border transition ${
                      videoConfig.fps === 30
                        ? 'bg-amber-400 text-black border-amber-300 shadow-[0_0_12px_rgba(245,158,11,0.4)]'
                        : 'bg-slate-800 text-slate-300 border-slate-700'
                    }`}
                  >
                    🔒 Khóa 30 FPS (Tiêu Chuẩn)
                  </button>
                </div>
              </div>

              <div>
                <div className="flex justify-between items-center mb-1.5 font-bold">
                  <span className="text-slate-300">Cấu Hình Bit-rate Cao (2.5 - 4.0 Mbps):</span>
                  <span className="text-cyan-400 font-mono">{videoConfig.bitrateMbps} Mbps</span>
                </div>
                <input
                  type="range"
                  min="2.5"
                  max="4.0"
                  step="0.1"
                  value={videoConfig.bitrateMbps}
                  onChange={(e) => setVideoConfig(prev => ({ ...prev, bitrateMbps: parseFloat(e.target.value) }))}
                  className="w-full accent-cyan-400 cursor-pointer"
                />
                <div className="flex justify-between text-[10px] text-slate-400 mt-1 font-mono">
                  <span>2.5 Mbps</span>
                  <span>3.2 Mbps</span>
                  <span>4.0 Mbps (Tối Ưu LiveKit)</span>
                </div>
              </div>

              <div className="space-y-2 pt-2 border-t border-cyan-500/20">
                <label className="flex items-center gap-2 cursor-pointer">
                  <input
                    type="checkbox"
                    checked={videoConfig.stabilization}
                    onChange={(e) => setVideoConfig(prev => ({ ...prev, stabilization: e.target.checked }))}
                    className="accent-cyan-400 w-4 h-4"
                  />
                  <span className="text-slate-200 font-bold">Bật Tính Năng Chống Rung (Image Stabilization)</span>
                </label>

                <label className="flex items-center gap-2 cursor-pointer">
                  <input
                    type="checkbox"
                    checked={videoConfig.autofocus}
                    onChange={(e) => setVideoConfig(prev => ({ ...prev, autofocus: e.target.checked }))}
                    className="accent-cyan-400 w-4 h-4"
                  />
                  <span className="text-slate-200 font-bold">Tự Động Lấy Nét Camera Liên Tục (Continuous Auto-Focus)</span>
                </label>
              </div>
            </div>

            <div className="mt-5 flex items-center gap-2">
              <button
                type="button"
                onClick={async () => {
                  setIsConfigModalOpen(false);
                  await startCameraStream();
                  showToast('Đã lưu và áp dụng cấu hình phát sóng!', 'success');
                }}
                className="flex-1 bg-gradient-to-r from-cyan-400 to-blue-500 hover:from-cyan-300 hover:to-blue-400 text-black font-black py-2.5 rounded-xl transition text-center cursor-pointer"
              >
                Áp Dụng Cấu Hình
              </button>
            </div>
          </div>
        </div>
      )}

      {/* ========================================================================= */}
      {/* MODAL 5: PIN PRODUCT PICKER (Streamer Only)                               */}
      {/* ========================================================================= */}
      {isPinPickerOpen && mode === 'streamer' && (
        <div className="fixed inset-0 z-50 bg-black/85 backdrop-blur-md flex items-center justify-center p-4">
          <div className="bg-[#0a122c] border-2 border-amber-400 rounded-3xl p-5 max-w-lg w-full max-h-[80vh] flex flex-col shadow-2xl">
            <div className="flex items-center justify-between pb-3 border-b border-amber-500/30 mb-3">
              <h3 className="text-sm font-black text-white uppercase tracking-wider flex items-center gap-2">
                <i className="fa-solid fa-thumbtack text-amber-400"></i>
                Chọn Sản Phẩm Ghim Lên Màn Hình Live
              </h3>
              <button
                onClick={() => setIsPinPickerOpen(false)}
                className="w-7 h-7 rounded-full bg-slate-800 text-slate-300 hover:text-white flex items-center justify-center cursor-pointer"
              >
                <i className="fa-solid fa-xmark text-xs"></i>
              </button>
            </div>

            <div className="flex-1 overflow-y-auto space-y-2 pr-1">
              {products.map((p) => (
                <div
                  key={p.id}
                  onClick={() => handlePinProduct(p.id)}
                  className={`p-2.5 rounded-xl border flex items-center gap-3 cursor-pointer transition ${
                    activeRoom?.pinnedProductId === p.id
                      ? 'bg-amber-500/20 border-amber-400 shadow-[0_0_15px_rgba(245,158,11,0.3)]'
                      : 'bg-[#060a18] border-slate-800 hover:border-slate-600'
                  }`}
                >
                  <img
                    src={p.images[0]}
                    alt={p.name}
                    className="w-12 h-12 object-contain bg-black/40 rounded p-1 shrink-0"
                  />
                  <div className="min-w-0 flex-1">
                    <h4 className="text-xs font-bold text-white truncate">{p.name}</h4>
                    <div className="text-[11px] font-black text-amber-400">
                      {p.price.toLocaleString('vi-VN')}₫
                    </div>
                  </div>
                  {activeRoom?.pinnedProductId === p.id && (
                    <span className="bg-amber-400 text-black text-[10px] font-black px-2 py-0.5 rounded">
                      ĐANG GHIM
                    </span>
                  )}
                </div>
              ))}
            </div>
          </div>
        </div>
      )}

      {/* ========================================================================= */}
      {/* MODAL 6: LIVE STOCK INVENTORY MANAGEMENT (Streamer Only)                  */}
      {/* ========================================================================= */}
      {isStockModalOpen && mode === 'streamer' && (
        <div className="fixed inset-0 z-50 bg-black/85 backdrop-blur-md flex items-center justify-center p-4">
          <div className="bg-[#0a1435] border-2 border-cyan-400 rounded-3xl p-5 max-w-lg w-full max-h-[80vh] flex flex-col shadow-2xl">
            <div className="flex items-center justify-between pb-3 border-b border-cyan-500/30 mb-3">
              <h3 className="text-sm font-black text-white uppercase tracking-wider flex items-center gap-2">
                <i className="fa-solid fa-boxes-stacked text-cyan-400"></i>
                Quản Lý Kho Hàng Ngay Trong Live
              </h3>
              <button
                onClick={() => setIsStockModalOpen(false)}
                className="w-7 h-7 rounded-full bg-slate-800 text-slate-300 hover:text-white flex items-center justify-center cursor-pointer"
              >
                <i className="fa-solid fa-xmark text-xs"></i>
              </button>
            </div>

            <p className="text-xs text-slate-300 mb-3">
              Tăng/giảm số lượng tồn kho theo thời gian thực. Khán giả sẽ thấy số lượng này thay đổi ngay tức thì trên giỏ live!
            </p>

            <div className="flex-1 overflow-y-auto space-y-2 pr-1">
              {products.map((p) => {
                const currentStock = stockMap[p.id] ?? 10;
                return (
                  <div
                    key={p.id}
                    className="p-2.5 rounded-xl border border-slate-800 bg-[#060a18] flex items-center justify-between gap-3"
                  >
                    <div className="flex items-center gap-2.5 min-w-0">
                      <img
                        src={p.images[0]}
                        alt={p.name}
                        className="w-10 h-10 object-contain bg-black/40 rounded p-1 shrink-0"
                      />
                      <div className="min-w-0">
                        <h4 className="text-xs font-bold text-white truncate max-w-[180px]">{p.name}</h4>
                        <div className="text-[10px] text-amber-400">{p.price.toLocaleString('vi-VN')}₫</div>
                      </div>
                    </div>

                    <div className="flex items-center gap-2 shrink-0">
                      <button
                        onClick={() => handleUpdateStock(p.id, -1)}
                        className="w-7 h-7 rounded-lg bg-slate-800 hover:bg-slate-700 text-white font-bold"
                      >
                        -
                      </button>
                      <span className="font-mono font-black text-cyan-300 text-xs w-8 text-center">
                        {currentStock}
                      </span>
                      <button
                        onClick={() => handleUpdateStock(p.id, 1)}
                        className="w-7 h-7 rounded-lg bg-cyan-600 hover:bg-cyan-500 text-white font-bold"
                      >
                        +
                      </button>
                    </div>
                  </div>
                );
              })}
            </div>
          </div>
        </div>
      )}

      {/* ========================================================================= */}
      {/* MODAL 7: ADMIN MODERATION PANEL (Kick / Ban)                              */}
      {/* ========================================================================= */}
      {isAdminModOpen && mode === 'streamer' && (
        <div className="fixed inset-0 z-50 bg-black/85 backdrop-blur-md flex items-center justify-center p-4">
          <div className="bg-[#0a122c] border-2 border-rose-500 rounded-3xl p-5 max-w-md w-full shadow-2xl">
            <div className="flex items-center justify-between pb-3 border-b border-rose-500/30 mb-3">
              <h3 className="text-sm font-black text-white uppercase tracking-wider flex items-center gap-2">
                <i className="fa-solid fa-shield-halved text-rose-400"></i>
                Bảng Kiểm Duyệt & Quản Lý Người Xem
              </h3>
              <button
                onClick={() => setIsAdminModOpen(false)}
                className="w-7 h-7 rounded-full bg-slate-800 text-slate-300 hover:text-white flex items-center justify-center cursor-pointer"
              >
                <i className="fa-solid fa-xmark text-xs"></i>
              </button>
            </div>

            <div className="space-y-3 text-xs">
              <p className="text-slate-300">
                Sử dụng API máy chủ LiveKit để thu hồi Token và loại bỏ người xem xấu ngay tức thì.
              </p>

              {/* Active Viewers List for Direct Kicking */}
              <div className="bg-[#060a18] p-3 rounded-xl border border-slate-800 space-y-2 max-h-56 overflow-y-auto">
                <div className="font-bold text-white flex items-center justify-between">
                  <span>Người Xem Đang Hoạt Động ({Array.from(new Map(messages.filter(m => m.senderId !== 'system').map(m => [m.senderId, { id: m.senderId, name: m.senderName, avatar: m.senderAvatar, badge: m.senderBadge }])).values()).length}):</span>
                  <span className="text-[10px] text-cyan-400 font-normal">Bấm Kick trực tiếp</span>
                </div>
                {messages.filter(m => m.senderId !== 'system').length === 0 ? (
                  <p className="text-slate-400 text-center py-2 italic">Chưa có người xem trong phòng</p>
                ) : (
                  <div className="space-y-1.5">
                    {Array.from(
                      new Map(
                        messages
                          .filter(m => m.senderId !== 'system')
                          .map(m => [m.senderId, { id: m.senderId, name: m.senderName, avatar: m.senderAvatar, badge: m.senderBadge }])
                      ).values()
                    ).map((viewer: any) => (
                      <div key={viewer.id} className="flex items-center justify-between p-2 rounded-lg bg-slate-900 border border-slate-800">
                        <div className="flex items-center gap-2 min-w-0">
                          <img src={viewer.avatar} alt={viewer.name} className="w-7 h-7 rounded-full object-cover border border-cyan-500/40" />
                          <div className="min-w-0">
                            <div className="text-xs font-bold text-white truncate">{viewer.name}</div>
                            <div className="text-[9px] text-cyan-300">{viewer.badge || 'Viewer'}</div>
                          </div>
                        </div>
                        <button
                          onClick={() => handleKickUser(viewer.id, viewer.name)}
                          className="bg-rose-600/20 hover:bg-rose-600 text-rose-300 hover:text-white border border-rose-500/50 text-[10px] font-bold px-2.5 py-1 rounded-lg transition shrink-0"
                        >
                          <i className="fa-solid fa-user-xmark mr-1"></i> Kick
                        </button>
                      </div>
                    ))}
                  </div>
                )}
              </div>

              <div className="bg-[#060a18] p-3 rounded-xl border border-slate-800 space-y-2">
                <div className="font-bold text-white">Thao Tác Nhanh:</div>
                <div className="flex flex-col gap-2">
                  <button
                    onClick={() => {
                      const input = window.prompt('Nhập ID hoặc Tên tài khoản cần kick:');
                      if (input) handleKickUser(input, input);
                    }}
                    className="w-full bg-amber-500/20 hover:bg-amber-500/30 text-amber-300 border border-amber-500/40 py-2 rounded-lg font-bold"
                  >
                    <i className="fa-solid fa-user-xmark mr-1"></i> Kick Người Dùng Theo ID
                  </button>

                  <button
                    onClick={() => {
                      const input = window.prompt('Nhập ID hoặc Tên tài khoản cần CẤM VĨNH VIỄN:');
                      if (input) handleBanUser(input, input);
                    }}
                    className="w-full bg-rose-500/20 hover:bg-rose-500/30 text-rose-300 border border-rose-500/40 py-2 rounded-lg font-bold"
                  >
                    <i className="fa-solid fa-ban mr-1"></i> Cấm Vĩnh Viễn Người Dùng
                  </button>
                </div>
              </div>

              <button
                onClick={() => setIsAdminModOpen(false)}
                className="w-full bg-slate-800 hover:bg-slate-700 text-white font-bold py-2 rounded-xl"
              >
                Đóng
              </button>
            </div>
          </div>
        </div>
      )}

      {/* ========================================================================= */}
      {/* MODAL 8: CREATE NEW LIVE ROOM MODAL                                       */}
      {/* ========================================================================= */}
      {isCreateRoomOpen && (
        <div className="fixed inset-0 z-50 bg-black/85 backdrop-blur-md flex items-center justify-center p-4">
          <div className="bg-[#0b1430] border-2 border-cyan-400 rounded-3xl p-6 max-w-lg w-full shadow-2xl animate-scaleUp">
            <div className="flex items-center justify-between pb-3 border-b border-cyan-500/30 mb-4">
              <div className="flex items-center gap-2">
                <i className="fa-solid fa-video text-rose-500 text-lg"></i>
                <h3 className="text-sm font-black text-white uppercase tracking-wider">
                  Mở Phòng Live Sản Phẩm Từ Tài Khoản Của Bạn
                </h3>
              </div>
              <button
                onClick={() => setIsCreateRoomOpen(false)}
                className="w-7 h-7 rounded-full bg-slate-800 text-slate-300 hover:text-white flex items-center justify-center cursor-pointer"
              >
                <i className="fa-solid fa-xmark text-xs"></i>
              </button>
            </div>

            <form onSubmit={handleCreateRoom} className="space-y-4 text-xs">
              <div>
                <label className="block text-slate-300 font-bold mb-1">
                  Tiêu Đề Buổi Livestream:
                </label>
                <input
                  type="text"
                  required
                  value={newRoomTitle}
                  onChange={(e) => setNewRoomTitle(e.target.value)}
                  placeholder="Ví dụ: Unboxing Đai Gavv & Giao Lưu Tokusatsu..."
                  className="w-full bg-[#050917] border border-cyan-500/40 rounded-xl p-2.5 text-xs text-white focus:outline-none focus:border-cyan-400"
                />
              </div>

              <div>
                <label className="block text-slate-300 font-bold mb-1">
                  Danh Mục Phát Sóng:
                </label>
                <select
                  value={newRoomCategory}
                  onChange={(e) => setNewRoomCategory(e.target.value)}
                  className="w-full bg-[#050917] border border-cyan-500/40 rounded-xl p-2.5 text-xs text-white focus:outline-none focus:border-cyan-400"
                >
                  <option value="Đai Biến Hình DX & CSM">Đai Biến Hình DX & CSM</option>
                  <option value="Mô Hình S.H.Figuarts">Mô Hình S.H.Figuarts</option>
                  <option value="Đai Biến Hình & Vũ Khí">Đai Biến Hình & Vũ Khí</option>
                  <option value="Super Sentai & SMP Robot">Super Sentai & SMP Robot</option>
                  <option value="Giao Lưu Sưu Tầm & Đập Hộp">Giao Lưu Sưu Tầm & Đập Hộp</option>
                </select>
              </div>

              <div>
                <label className="block text-slate-300 font-bold mb-1">
                  Sản Phẩm Ghim Giới Thiệu Đầu Tiên:
                </label>
                <select
                  value={newRoomPinnedProduct}
                  onChange={(e) => setNewRoomPinnedProduct(e.target.value)}
                  className="w-full bg-[#050917] border border-cyan-500/40 rounded-xl p-2.5 text-xs text-white focus:outline-none focus:border-cyan-400"
                >
                  {products.map(p => (
                    <option key={p.id} value={p.id}>
                      {p.name} - {p.price.toLocaleString('vi-VN')}₫
                    </option>
                  ))}
                </select>
              </div>

              <div className="bg-[#070b18] p-3 rounded-xl border border-cyan-500/20 text-slate-300 space-y-1 text-[11px]">
                <p>
                  ⚡ Khi bấm <span className="font-bold text-cyan-300">"Bắt Đầu Phát Sóng"</span>, kênh của bạn sẽ lập tức xuất hiện trong danh mục các tài khoản đang live để tất cả khách hàng cùng bấm vào xem!
                </p>
              </div>

              <div className="flex items-center gap-2 pt-2">
                <button
                  type="button"
                  onClick={() => setIsCreateRoomOpen(false)}
                  className="flex-1 bg-slate-800 hover:bg-slate-700 text-slate-300 font-bold py-2.5 rounded-xl transition text-center cursor-pointer"
                >
                  Hủy Bỏ
                </button>
                <button
                  type="submit"
                  className="flex-1 bg-gradient-to-r from-amber-400 to-rose-500 hover:brightness-110 text-black font-black py-2.5 rounded-xl transition text-center shadow-lg cursor-pointer"
                >
                  Bắt Đầu Phát Sóng Ngay
                </button>
              </div>
            </form>
          </div>
        </div>
      )}

      {/* ========================================================================= */}
      {/* MODAL 9: CONFIRM END LIVE ROOM MODAL (Streamer Exclusive)                 */}
      {/* ========================================================================= */}
      {isConfirmEndLiveOpen && (
        <div className="fixed inset-0 z-50 bg-black/85 backdrop-blur-md flex items-center justify-center p-4">
          <div className="bg-[#0c142c] border-2 border-rose-500/80 rounded-3xl p-6 max-w-md w-full shadow-[0_0_50px_rgba(244,63,94,0.35)] animate-scaleUp text-center">
            <div className="w-16 h-16 rounded-full bg-rose-500/20 border-2 border-rose-500/60 text-rose-400 flex items-center justify-center mx-auto mb-4 text-2xl shadow-inner">
              <i className="fa-solid fa-power-off animate-pulse"></i>
            </div>

            <h3 className="text-base font-black text-white uppercase tracking-wider mb-2">
              Xác Nhận Đóng Live & Kết Thúc
            </h3>

            <p className="text-xs text-slate-300 mb-4 leading-relaxed">
              Bạn có chắc chắn muốn kết thúc buổi phát sóng <span className="font-extrabold text-cyan-300">[{activeRoom?.title || 'Phòng Live'}]</span>?
              Toàn bộ luồng camera và chia sẻ màn hình sẽ được đóng lại an toàn.
            </p>

            {/* Quick Session Stats summary */}
            <div className="grid grid-cols-3 gap-2 bg-[#060a18] p-3 rounded-2xl border border-slate-800 mb-5 text-xs">
              <div className="text-center">
                <span className="block text-[10px] text-slate-400">Đang xem</span>
                <span className="font-extrabold text-emerald-400">{activeRoom?.viewerCount || 0}</span>
              </div>
              <div className="text-center border-x border-slate-800">
                <span className="block text-[10px] text-slate-400">Đơn chốt</span>
                <span className="font-extrabold text-amber-400">{activeRoom?.totalOrders || 0}</span>
              </div>
              <div className="text-center">
                <span className="block text-[10px] text-slate-400">Doanh thu</span>
                <span className="font-extrabold text-cyan-300">{(activeRoom?.totalRevenue || 0).toLocaleString('vi-VN')}₫</span>
              </div>
            </div>

            <div className="flex items-center gap-3">
              <button
                type="button"
                disabled={isEndingLive}
                onClick={() => setIsConfirmEndLiveOpen(false)}
                className="flex-1 bg-slate-800 hover:bg-slate-700 text-slate-300 font-bold py-2.5 rounded-xl transition text-xs cursor-pointer"
              >
                Tiếp Tục Phát Sóng
              </button>

              <button
                type="button"
                disabled={isEndingLive}
                onClick={executeEndLiveRoom}
                className="flex-1 bg-gradient-to-r from-rose-600 to-rose-700 hover:from-rose-500 hover:to-rose-600 text-white font-black py-2.5 rounded-xl transition shadow-[0_0_20px_rgba(244,63,94,0.4)] text-xs flex items-center justify-center gap-2 cursor-pointer"
              >
                {isEndingLive ? (
                  <>
                    <i className="fa-solid fa-spinner fa-spin"></i>
                    <span>Đang Đóng...</span>
                  </>
                ) : (
                  <>
                    <i className="fa-solid fa-circle-stop"></i>
                    <span>Xác Nhận Đóng Live</span>
                  </>
                )}
              </button>
            </div>
          </div>
        </div>
      )}

    </div>
  );
};
