import React, { useState } from 'react';
import { Coupon, User } from '../types';

interface PromotionsViewProps {
  coupons: Coupon[];
  currentUser: User | null;
  showToast: (msg: string, type?: 'success' | 'error' | 'info') => void;
}

export const PromotionsView: React.FC<PromotionsViewProps> = ({ coupons, currentUser, showToast }) => {
  const [copiedCode, setCopiedCode] = useState<string | null>(null);

  const handleCopyCode = (code: string) => {
    navigator.clipboard.writeText(code);
    setCopiedCode(code);
    showToast(`🎟️ Đã sao chép mã voucher: ${code}`, 'success');
    setTimeout(() => setCopiedCode(null), 3000);
  };

  const referralLink = currentUser 
    ? `https://riderstore.vn/ref/${currentUser.referralCode}`
    : 'https://riderstore.vn/ref/RIDER2026';

  const handleCopyReferral = () => {
    navigator.clipboard.writeText(referralLink);
    showToast('🔗 Đã sao chép liên kết giới thiệu! Nhận 200 Rider Points khi bạn bè mua đơn đầu.', 'success');
  };

  return (
    <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 py-8 space-y-12 text-[#F5F2EB]">
      {/* Header */}
      <div className="border-b border-[#2A2A2A] pb-6">
        <h2 className="font-serif-title text-2xl sm:text-3xl font-black">
          Ưu Đãi & <span className="gold-gradient-text">KHO VOUCHER KAMEN RIDER</span>
        </h2>
        <p className="text-xs text-gray-400 mt-1">Lưu mã giảm giá mua đai DX/CSM và chương trình mời bạn bè nhận quà</p>
      </div>

      {/* Referral Program Banner */}
      <div className="bg-gradient-to-r from-[#1A1A1A] via-[#222222] to-[#1A1A1A] border border-[#C9A84C]/40 rounded-3xl p-6 sm:p-8 grid grid-cols-1 lg:grid-cols-12 gap-6 items-center shadow-2xl">
        <div className="lg:col-span-8 space-y-2">
          <span className="inline-block bg-[#C9A84C]/10 border border-[#C9A84C]/30 text-[#C9A84C] text-[10px] font-extrabold px-3 py-1 rounded-full uppercase">
            🤝 Giới Thiệu Bạn Bè - Cùng Nhận Quà
          </span>
          <h3 className="font-serif-title text-xl sm:text-2xl font-bold">Chia Sẻ Đam Mê Rider - Tặng 200 Rider Points</h3>
          <p className="text-xs text-gray-300 leading-relaxed">
            Mỗi khi người bạn sử dụng link giới thiệu của bạn đặt đơn mua đai biến hình đầu tiên, bạn nhận ngay 200 Rider Points và người bạn đó nhận mã giảm 100.000đ!
          </p>
        </div>

        <div className="lg:col-span-4 space-y-3 bg-[#0A0A0A] p-4 rounded-2xl border border-[#2A2A2A]">
          <span className="text-[10px] text-gray-400 font-bold uppercase block">Liên kết giới thiệu của bạn</span>
          <div className="flex gap-2">
            <input 
              type="text" 
              readOnly 
              value={referralLink} 
              className="w-full bg-[#1A1A1A] border border-[#2A2A2A] rounded-xl px-3 py-2 text-xs text-[#C9A84C] font-mono truncate"
            />
            <button 
              onClick={handleCopyReferral}
              className="px-4 py-2 bg-[#C9A84C] text-[#0A0A0A] font-extrabold text-xs rounded-xl whitespace-nowrap hover:brightness-110"
            >
              Sao Chép
            </button>
          </div>
        </div>
      </div>

      {/* Coupons List */}
      <div className="space-y-6">
        <h3 className="font-serif-title text-xl font-bold">Mã Giảm Giá Đang Khả Dụng</h3>

        <div className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-4 gap-4">
          {coupons.map((c) => (
            <div 
              key={c.code}
              className="bg-[#1A1A1A] border border-[#2A2A2A] hover:border-[#C9A84C] rounded-2xl p-5 flex flex-col justify-between space-y-4 shadow-lg transition"
            >
              <div className="space-y-2">
                <div className="flex items-center justify-between">
                  <span className="bg-[#C9A84C]/10 border border-[#C9A84C]/30 text-[#C9A84C] text-[10px] font-black px-2.5 py-0.5 rounded-full font-mono">
                    {c.code}
                  </span>
                  <span className="text-[10px] text-gray-500 font-medium">HSD: {c.expiry}</span>
                </div>

                <h4 className="font-bold text-sm text-[#F5F2EB]">{c.title}</h4>
                <p className="text-xs text-gray-400 leading-relaxed">{c.description}</p>
              </div>

              <div className="pt-3 border-t border-[#2A2A2A] flex items-center justify-between">
                <span className="text-[10px] text-gray-500">Đơn từ {(c.minOrder / 1000000).toFixed(1)}M</span>
                <button 
                  onClick={() => handleCopyCode(c.code)}
                  className="px-3.5 py-1.5 bg-[#222222] hover:bg-[#C9A84C] text-[#C9A84C] hover:text-[#0A0A0A] border border-[#C9A84C]/40 text-xs font-bold rounded-xl transition"
                >
                  {copiedCode === c.code ? 'Đã Copy!' : 'Lưu Mã'}
                </button>
              </div>
            </div>
          ))}
        </div>
      </div>
    </div>
  );
};
