import React, { useState, useMemo } from 'react';
import { Product, CategoryType, EraType } from '../types';
import { ProductCard } from '../components/ProductCard';

interface ShopViewProps {
  products: Product[];
  onSelectProduct: (p: Product) => void;
  onAddToCart: (p: Product, e: React.MouseEvent) => void;
  onAddToCompare?: (p: Product, e: React.MouseEvent) => void;
  wishlistIds?: string[];
  onToggleFavorite?: (p: Product, e?: React.MouseEvent) => void;
}

export const ShopView: React.FC<ShopViewProps> = ({
  products,
  onSelectProduct,
  onAddToCart,
  onAddToCompare,
  wishlistIds = [],
  onToggleFavorite
}) => {
  type PriceTier = 'all' | 'under-500k' | '500k-1.5m' | '1.5m-3.5m' | '3.5m-8m' | 'above-8m';
  const [selectedCategory, setSelectedCategory] = useState<CategoryType | 'all'>('all');
  const [selectedEra, setSelectedEra] = useState<EraType | 'all'>('all');
  const [selectedPriceTier, setSelectedPriceTier] = useState<PriceTier>('all');
  const [priceMax, setPriceMax] = useState<number>(20000000);
  const [sortBy, setSortBy] = useState<'featured' | 'price-asc' | 'price-desc' | 'rating' | 'bestseller'>('featured');
  const [conditionFilter, setConditionFilter] = useState<'all' | 'New Seal 100%' | 'Like New 99%'>('all');
  const [currentPage, setCurrentPage] = useState<number>(1);

  const filteredProducts = useMemo(() => {
    const list = products.filter(p => {
      if (selectedCategory !== 'all') {
        if (selectedCategory === 'shf-premium' && p.category !== 'shf-pbandai' && p.category !== 'shf-premium') return false;
        else if (selectedCategory === 'super-sentai' && p.category !== 'sentai' && p.category !== 'super-sentai') return false;
        else if (selectedCategory === 'item-card' && p.category !== 'item' && p.category !== 'item-card') return false;
        else if (selectedCategory === 'poster' && p.category !== 'poster') return false;
        else if (!['shf-premium', 'super-sentai', 'item-card', 'poster'].includes(selectedCategory) && p.category !== selectedCategory) return false;
      }
      if (selectedEra !== 'all' && p.era !== selectedEra) return false;
      if (conditionFilter !== 'all' && p.condition !== conditionFilter) return false;
      
      // Đa dạng mức giá: Lọc theo phân khúc giá chọn lọc
      if (selectedPriceTier !== 'all') {
        if (selectedPriceTier === 'under-500k' && p.price >= 500000) return false;
        if (selectedPriceTier === '500k-1.5m' && (p.price < 500000 || p.price > 1500000)) return false;
        if (selectedPriceTier === '1.5m-3.5m' && (p.price < 1500000 || p.price > 3500000)) return false;
        if (selectedPriceTier === '3.5m-8m' && (p.price < 3500000 || p.price > 8000000)) return false;
        if (selectedPriceTier === 'above-8m' && p.price < 8000000) return false;
      }

      if (p.price > priceMax) return false;
      return true;
    });

    // Sort immutable copy
    const sorted = [...list];
    if (sortBy === 'price-asc') sorted.sort((a, b) => a.price - b.price);
    if (sortBy === 'price-desc') sorted.sort((a, b) => b.price - a.price);
    if (sortBy === 'rating') sorted.sort((a, b) => b.rating - a.rating);
    if (sortBy === 'bestseller') sorted.sort((a, b) => b.soldCount - a.soldCount);
    return sorted;
  }, [products, selectedCategory, selectedEra, conditionFilter, selectedPriceTier, priceMax, sortBy]);

  const ITEMS_PER_PAGE = 16;
  const totalPages = Math.ceil(filteredProducts.length / ITEMS_PER_PAGE);
  const paginatedProducts = useMemo(() => {
    return filteredProducts.slice((currentPage - 1) * ITEMS_PER_PAGE, currentPage * ITEMS_PER_PAGE);
  }, [filteredProducts, currentPage]);

  return (
    <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 py-8 space-y-8">
      {/* Page Header */}
      <div className="border-b border-[#2A2A2A] pb-6">
        <h2 className="font-serif-title text-2xl sm:text-3xl font-black text-[#F5F2EB]">
          Danh Mục <span className="gold-gradient-text">TẤT CẢ SẢN PHẨM KAMEN RIDER</span>
        </h2>
        <p className="text-xs text-gray-400 mt-1">Đai biến hình DX, CSM, mô hình S.H.Figuarts & phụ kiện chính hãng Bandai Japan</p>
      </div>

      <div className="grid grid-cols-1 lg:grid-cols-12 gap-8 items-start">
        {/* Sidebar Filters */}
        <div className="lg:col-span-3 bg-[#1A1A1A] border border-[#2A2A2A] p-5 rounded-3xl space-y-6 text-xs text-[#F5F2EB]">
          <div className="flex items-center justify-between border-b border-[#2A2A2A] pb-3">
            <h4 className="font-bold text-xs uppercase tracking-wider text-[#C9A84C] flex items-center gap-2">
              <i className="fa-solid fa-sliders"></i> Bộ Lọc Nâng Cao
            </h4>
            <button 
              onClick={() => {
                setSelectedCategory('all');
                setSelectedEra('all');
                setSelectedPriceTier('all');
                setPriceMax(20000000);
                setConditionFilter('all');
              }}
              className="text-[10px] text-gray-400 hover:text-white underline cursor-pointer"
            >
              Đặt lại
            </button>
          </div>

          {/* Category Filter */}
          <div className="space-y-2">
            <label className="block font-bold text-gray-400 uppercase text-[10px]">Thư Mục Sản Phẩm</label>
            <div className="space-y-1">
              {[
                { id: 'all', label: 'Tất Cả Thư Mục', logo: '' },
                { id: 'shf', label: 'Mô Hình SHF Standard', logo: '/BIỂU TƯỢNG DANH MỤC SẢN PHẨM/dlyjpm8-ea90294c-de09-4bc2-8718-6b49acbf082e.png' },
                { id: 'shf-premium', label: 'Mô Hình SHF Premium', logo: '/BIỂU TƯỢNG DANH MỤC SẢN PHẨM/kamen_rider_kiva_logo_by_driftingcar_dg7tj5z-pre.png' },
                { id: 'super-sentai', label: 'Robot Super Sentai & SMP', logo: '/BIỂU TƯỢNG DANH MỤC SẢN PHẨM/kamen_rider_saber_logo_by_driftingcar_dgh9vay-pre.png' },
                { id: 'item-card', label: 'Item & Thẻ Bài Capsem', logo: '/BIỂU TƯỢNG DANH MỤC SẢN PHẨM/kamen_rider_femme_logo_by_driftingcar_dg73lkh-pre.png' },
                { id: 'dx-belt', label: 'Đai DX Belt & Driver', logo: '/BIỂU TƯỢNG DANH MỤC SẢN PHẨM/kamen_rider_revice_logo_by_driftingcar_dghk15w-pre.png' },
                { id: 'weapon', label: 'Vũ Khí & Khẩu Súng Kiếm', logo: '/BIỂU TƯỢNG DANH MỤC SẢN PHẨM/kamen_rider_knight_logo_by_driftingcar_dg73k3x-414w-2x.png' },
                { id: 'poster', label: 'Poster Khung Tranh Art', logo: '' },
              ].map(cat => (
                <button
                  key={cat.id}
                  onClick={() => setSelectedCategory(cat.id as any)}
                  className={`w-full text-left px-2.5 py-2 rounded-xl transition flex items-center gap-2.5 ${
                    selectedCategory === cat.id ? 'bg-[#C9A84C] text-[#0A0A0A] font-extrabold shadow-md' : 'hover:bg-[#222222] text-gray-300'
                  }`}
                >
                  {cat.logo ? (
                    <div className="w-6 h-6 rounded-lg bg-[#08070C] p-0.5 border border-[#C9A84C]/50 flex items-center justify-center shrink-0">
                      <img src={cat.logo} alt={cat.label} className="max-h-full max-w-full object-contain" />
                    </div>
                  ) : (
                    <i className="fa-solid fa-layer-group text-xs text-[#C9A84C] pl-1"></i>
                  )}
                  <span className="truncate text-xs">{cat.label}</span>
                </button>
              ))}
            </div>
          </div>

          {/* Era Filter */}
          <div className="space-y-2 pt-2 border-t border-[#2A2A2A]">
            <label className="block font-bold text-gray-400 uppercase text-[10px]">Kỷ Nguyên (Era)</label>
            <div className="grid grid-cols-3 gap-1.5">
              {['all', 'Reiwa', 'Heisei', 'Showa'].map(era => (
                <button
                  key={era}
                  onClick={() => setSelectedEra(era as any)}
                  className={`py-1.5 rounded-lg border text-center font-bold text-[11px] transition ${
                    selectedEra === era ? 'bg-[#C9A84C] text-[#0A0A0A] border-[#C9A84C]' : 'bg-[#0D0D0D] border-[#2A2A2A] text-gray-400'
                  }`}
                >
                  {era === 'all' ? 'Tất cả' : era}
                </button>
              ))}
            </div>
          </div>

          {/* Diverse Price Tiers Filter (Đa Dạng Mức Giá) */}
          <div className="space-y-2.5 pt-2 border-t border-[#2A2A2A]">
            <div className="flex justify-between items-center font-bold text-[10px] uppercase text-gray-300">
              <span className="flex items-center gap-1 text-amber-300">
                <i className="fa-solid fa-coins"></i> Phân Khúc Mức Giá
              </span>
              {selectedPriceTier !== 'all' && (
                <button 
                  onClick={() => setSelectedPriceTier('all')} 
                  className="text-[9px] text-cyan-300 underline font-normal"
                >
                  Xóa lọc giá
                </button>
              )}
            </div>
            
            <div className="space-y-1">
              {[
                { id: 'all', label: 'Tất Cả Mức Giá' },
                { id: 'under-500k', label: '⚡ Dưới 500.000đ (Thẻ/Box/Mini)' },
                { id: '500k-1.5m', label: '🪙 500.000đ - 1.500.000đ (Phổ thông)' },
                { id: '1.5m-3.5m', label: '⚔️ 1.500.000đ - 3.500.000đ (Đai DX)' },
                { id: '3.5m-8m', label: '🌟 3.500.000đ - 8.000.000đ (Cao cấp/SHF)' },
                { id: 'above-8m', label: '👑 Trên 8.000.000đ (CSM Hoàng Gia)' }
              ].map(tier => (
                <button
                  key={tier.id}
                  onClick={() => setSelectedPriceTier(tier.id as any)}
                  className={`w-full text-left px-2.5 py-1.5 rounded-lg border text-[11px] font-bold transition flex items-center justify-between ${
                    selectedPriceTier === tier.id
                      ? 'bg-amber-400 text-black border-amber-300 shadow-sm'
                      : 'bg-[#0f1422] border-slate-800 text-slate-300 hover:text-white hover:border-slate-700'
                  }`}
                >
                  <span>{tier.label}</span>
                  {selectedPriceTier === tier.id && <i className="fa-solid fa-check text-[10px]"></i>}
                </button>
              ))}
            </div>

            {/* Slider điều chỉnh linh hoạt */}
            <div className="pt-2">
              <div className="flex justify-between font-bold text-[10px] uppercase text-slate-400">
                <span>Trần Giá Lọc:</span>
                <span className="text-amber-300 font-mono font-black">{priceMax.toLocaleString('vi-VN')}đ</span>
              </div>
              <input 
                type="range" 
                min="100000" 
                max="20000000" 
                step="200000"
                value={priceMax}
                onChange={(e) => setPriceMax(Number(e.target.value))}
                className="w-full accent-amber-400 cursor-pointer mt-1"
              />
            </div>
          </div>

          {/* Condition Filter */}
          <div className="space-y-2 pt-2 border-t border-[#2A2A2A]">
            <label className="block font-bold text-gray-400 uppercase text-[10px]">Tình Trạng Hàng</label>
            <div className="space-y-1">
              {['all', 'New Seal 100%', 'Like New 99%'].map(cond => (
                <button
                  key={cond}
                  onClick={() => setConditionFilter(cond as any)}
                  className={`w-full text-left px-3 py-1.5 rounded-xl transition text-[11px] ${
                    conditionFilter === cond ? 'bg-[#222222] text-[#C9A84C] font-bold border border-[#C9A84C]/50' : 'text-gray-400 hover:text-white'
                  }`}
                >
                  {cond === 'all' ? 'Tất cả tình trạng' : cond}
                </button>
              ))}
            </div>
          </div>
        </div>

        {/* Catalog Main Grid */}
        <div className="lg:col-span-9 space-y-6">
          {/* Top Bar Sort */}
          <div className="bg-[#1A1A1A] border border-[#2A2A2A] p-4 rounded-2xl flex flex-col sm:flex-row items-start sm:items-center justify-between gap-4 text-xs">
            <span className="text-gray-400 font-medium">
              Hiển thị <strong className="text-[#F5F2EB]">{filteredProducts.length}</strong> sản phẩm phù hợp
            </span>

            <div className="flex items-center gap-2">
              <span className="text-gray-400">Sắp xếp:</span>
              <select 
                value={sortBy}
                onChange={(e) => setSortBy(e.target.value as any)}
                className="bg-[#0D0D0D] border border-[#2A2A2A] text-xs font-bold text-[#F5F2EB] px-3 py-2 rounded-xl focus:outline-none focus:border-[#C9A84C]"
              >
                <option value="featured">Nổi bật nhất</option>
                <option value="bestseller">Bán chạy nhất</option>
                <option value="price-asc">Giá: Thấp đến Cao</option>
                <option value="price-desc">Giá: Cao đến Thấp</option>
                <option value="rating">Đánh giá cao nhất</option>
              </select>
            </div>
          </div>

          {/* Grid List */}
          {filteredProducts.length === 0 ? (
            <div className="bg-[#1A1A1A] border border-[#2A2A2A] rounded-3xl p-12 text-center text-gray-500 space-y-3">
              <i className="fa-solid fa-ghost text-4xl text-gray-600 block"></i>
              <p className="font-bold text-gray-300">Không tìm thấy sản phẩm Kamen Rider phù hợp với bộ lọc</p>
              <button 
                onClick={() => {
                  setSelectedCategory('all');
                  setSelectedEra('all');
                  setPriceMax(12000000);
                  setConditionFilter('all');
                }}
                className="px-5 py-2 rounded-xl bg-[#222222] text-[#C9A84C] font-bold text-xs"
              >
                Xóa Bộ Lọc
              </button>
            </div>
          ) : (
            <div className="space-y-8">
              {/* Grid: 4 Products per Row (4 rows = 16 products per page) */}
              <div className="grid grid-cols-2 sm:grid-cols-4 gap-3.5 sm:gap-4">
                {paginatedProducts.map(p => (
                  <ProductCard 
                    key={p.id}
                    product={p}
                    onSelect={onSelectProduct}
                    onAddToCart={onAddToCart}
                    onAddToCompare={onAddToCompare}
                    isFavorite={wishlistIds.includes(p.id)}
                    onToggleFavorite={onToggleFavorite}
                  />
                ))}
              </div>

              {/* Pagination Controls */}
              {totalPages > 1 && (
                <div className="flex items-center justify-center gap-2 pt-4 border-t border-[#2A2A2A]">
                  <button
                    disabled={currentPage === 1}
                    onClick={() => setCurrentPage(p => Math.max(1, p - 1))}
                    className="px-3 py-2 rounded-xl bg-[#1A1A1A] border border-[#2A2A2A] text-xs font-bold text-gray-300 hover:text-[#C9A84C] disabled:opacity-40"
                  >
                    ← Trang Trước
                  </button>

                  {Array.from({ length: totalPages }).map((_, idx) => (
                    <button
                      key={idx}
                      onClick={() => setCurrentPage(idx + 1)}
                      className={`w-9 h-9 rounded-xl font-bold text-xs transition ${
                        currentPage === idx + 1
                          ? 'bg-[#C9A84C] text-[#0A0A0A] shadow-md shadow-[#C9A84C]/20 font-black'
                          : 'bg-[#1A1A1A] border border-[#2A2A2A] text-gray-400 hover:text-white'
                      }`}
                    >
                      {idx + 1}
                    </button>
                  ))}

                  <button
                    disabled={currentPage === totalPages}
                    onClick={() => setCurrentPage(p => Math.min(totalPages, p + 1))}
                    className="px-3 py-2 rounded-xl bg-[#1A1A1A] border border-[#2A2A2A] text-xs font-bold text-gray-300 hover:text-[#C9A84C] disabled:opacity-40"
                  >
                    Trang Sau →
                  </button>
                </div>
              )}
            </div>
          )}
        </div>
      </div>
    </div>
  );
};
