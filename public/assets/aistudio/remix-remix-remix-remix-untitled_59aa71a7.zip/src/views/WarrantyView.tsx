import React, { useState } from 'react';
import { WarrantyTicket } from '../types';

interface WarrantyViewProps {
  onAddWarrantyTicket: (ticket: WarrantyTicket) => void;
  showToast: (msg: string, type?: 'success' | 'error' | 'info') => void;
}

export const WarrantyView: React.FC<WarrantyViewProps> = ({ onAddWarrantyTicket, showToast }) => {
  const [lookupSerial, setLookupSerial] = useState('');
  const [lookupResult, setLookupResult] = useState<string | null>(null);

  // Form state
  const [name, setName] = useState('');
  const [phone, setPhone] = useState('');
  const [email, setEmail] = useState('');
  const [orderCode, setOrderCode] = useState('');
  const [serial, setSerial] = useState('');
  const [prodName, setProdName] = useState('DX Henshin Belt Gavv');
  const [issue, setIssue] = useState<'Lỗi Âm Thanh/Loa' | 'Lỗi Đèn LED' | 'Lỗi Nhận Thẻ/Buckle' | 'Hỏng Nút Bấm' | 'Khác'>('Lỗi Âm Thanh/Loa');
  const [desc, setDesc] = useState('');

  const handleLookup = (e: React.FormEvent) => {
    e.preventDefault();
    if (!lookupSerial.trim()) return;
    const clean = lookupSerial.trim().toUpperCase();
    if (clean.includes('BANDAI') || clean.length > 8) {
      setLookupResult(`✅ Mã Serial [${clean}] hợp lệ! Đã kích hoạt bảo hành Bandai Japan 1-đổi-1 trong 30 ngày (Đến ngày 20/08/2026).`);
    } else {
      setLookupResult(`⚠️ Mã Serial [${clean}] không tìm thấy trên hệ thống hoặc đã hết hạn.`);
    }
  };

  const handleSubmitTicket = (e: React.FormEvent) => {
    e.preventDefault();
    if (!name || !phone || !email || !orderCode || !desc) {
      showToast('⚠️ Vui lòng điền đủ các trường bắt buộc!', 'error');
      return;
    }

    const ticket: WarrantyTicket = {
      id: 'WR-' + Math.floor(100000 + Math.random() * 900000),
      customerName: name,
      customerPhone: phone,
      customerEmail: email,
      orderCode,
      productSerial: serial || 'BANDAI-AUTO-SERIAL',
      productName: prodName,
      issueType: issue,
      description: desc,
      status: 'Đang tiếp nhận',
      createdAt: new Date().toLocaleDateString('vi-VN')
    };

    onAddWarrantyTicket(ticket);
    setName('');
    setPhone('');
    setEmail('');
    setOrderCode('');
    setSerial('');
    setDesc('');
    showToast(`🎉 Đã gửi ticket bảo hành #${ticket.id}! Kỹ thuật viên sẽ gọi hỗ trợ trong 30 phút.`, 'success');
  };

  return (
    <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 py-8 space-y-12 text-[#F5F2EB]">
      {/* Page Header */}
      <div className="border-b border-[#2A2A2A] pb-6">
        <h2 className="font-serif-title text-2xl sm:text-3xl font-black">
          Bảo Hành & <span className="gold-gradient-text">HỖ TRỢ KỸ THUẬT ĐAI HENSHIN</span>
        </h2>
        <p className="text-xs text-gray-400 mt-1">Chính sách đổi mới 1-đổi-1 trong 30 ngày cho mạch loa & LED chính hãng Bandai Japan</p>
      </div>

      {/* 1. Policy & Care Guide */}
      <div className="grid grid-cols-1 lg:grid-cols-12 gap-8 items-start">
        <div className="lg:col-span-6 space-y-6">
          <div className="bg-[#1A1A1A] border border-[#2A2A2A] p-6 rounded-3xl space-y-4">
            <h3 className="font-serif-title text-lg font-bold text-[#C9A84C] flex items-center gap-2">
              <i className="fa-solid fa-shield-halved"></i> Chính Sách Đổi Trả 1-Đổi-1
            </h3>
            <ul className="space-y-2.5 text-xs text-gray-300">
              <li className="flex items-start gap-2">
                <i className="fa-solid fa-check text-emerald-400 mt-0.5"></i>
                <span><strong>Đổi mới 100%:</strong> Đổi ngay đai mới trong 30 ngày nếu phát sinh lỗi mạch chip, hỏng loa hoặc nút bấm.</span>
              </li>
              <li className="flex items-start gap-2">
                <i className="fa-solid fa-check text-emerald-400 mt-0.5"></i>
                <span><strong>Kiểm định Bandai Seal:</strong> Đai phải còn nguyên hộp, không có vệt nứt vỡ do va đập rơi ngâm nước.</span>
              </li>
              <li className="flex items-start gap-2">
                <i className="fa-solid fa-check text-emerald-400 mt-0.5"></i>
                <span><strong>Phí ship 0đ:</strong> NPTTEAMSTORE hỗ trợ 100% phí vận chuyển 2 chiều đối với sản phẩm lỗi bảo hành.</span>
              </li>
            </ul>
          </div>

          {/* Serial Code Lookup Widget */}
          <div className="bg-[#1A1A1A] border border-[#2A2A2A] p-6 rounded-3xl space-y-4">
            <h3 className="font-serif-title text-base font-bold text-[#F5F2EB]">Tra Cứu Mã Serial Bảo Hành</h3>
            <form onSubmit={handleLookup} className="flex gap-2">
              <input 
                type="text"
                value={lookupSerial}
                onChange={(e) => setLookupSerial(e.target.value)}
                placeholder="Nhập mã Serial trên hóa đơn / vỏ hộp..."
                className="flex-grow bg-[#0D0D0D] border border-[#2A2A2A] rounded-xl px-4 py-2.5 text-xs text-white uppercase font-mono"
              />
              <button type="submit" className="px-5 py-2.5 bg-[#C9A84C] text-[#0A0A0A] font-extrabold text-xs rounded-xl whitespace-nowrap">
                Tra Cứu
              </button>
            </form>
            {lookupResult && (
              <div className="bg-[#0D0D0D] border border-[#2A2A2A] p-3 rounded-xl text-xs text-gray-300">
                {lookupResult}
              </div>
            )}
          </div>
        </div>

        {/* 2. Online Registration Form */}
        <div className="lg:col-span-6 bg-[#1A1A1A] border border-[#2A2A2A] p-6 sm:p-8 rounded-3xl space-y-5 text-xs">
          <h3 className="font-serif-title text-xl font-bold text-[#F5F2EB]">Đăng Ký Yêu Cầu Bảo Hành Online</h3>

          <form onSubmit={handleSubmitTicket} className="space-y-4">
            <div className="grid grid-cols-2 gap-3">
              <div>
                <label className="block font-bold text-gray-400 uppercase text-[10px] mb-1">Họ tên khách hàng *</label>
                <input 
                  type="text"
                  required
                  value={name}
                  onChange={(e) => setName(e.target.value)}
                  className="w-full bg-[#0D0D0D] border border-[#2A2A2A] rounded-xl px-3.5 py-2.5 text-xs text-white"
                />
              </div>
              <div>
                <label className="block font-bold text-gray-400 uppercase text-[10px] mb-1">Số điện thoại *</label>
                <input 
                  type="tel"
                  required
                  value={phone}
                  onChange={(e) => setPhone(e.target.value)}
                  className="w-full bg-[#0D0D0D] border border-[#2A2A2A] rounded-xl px-3.5 py-2.5 text-xs text-white"
                />
              </div>
            </div>

            <div className="grid grid-cols-2 gap-3">
              <div>
                <label className="block font-bold text-gray-400 uppercase text-[10px] mb-1">Mã đơn hàng *</label>
                <input 
                  type="text"
                  required
                  value={orderCode}
                  onChange={(e) => setOrderCode(e.target.value)}
                  placeholder="RD-XXXXXX"
                  className="w-full bg-[#0D0D0D] border border-[#2A2A2A] rounded-xl px-3.5 py-2.5 text-xs text-white uppercase font-mono"
                />
              </div>
              <div>
                <label className="block font-bold text-gray-400 uppercase text-[10px] mb-1">Mã Serial sản phẩm</label>
                <input 
                  type="text"
                  value={serial}
                  onChange={(e) => setSerial(e.target.value)}
                  placeholder="BANDAI-..."
                  className="w-full bg-[#0D0D0D] border border-[#2A2A2A] rounded-xl px-3.5 py-2.5 text-xs text-white uppercase font-mono"
                />
              </div>
            </div>

            <div>
              <label className="block font-bold text-gray-400 uppercase text-[10px] mb-1">Loại sự cố gặp phải *</label>
              <select 
                value={issue}
                onChange={(e) => setIssue(e.target.value as any)}
                className="w-full bg-[#0D0D0D] border border-[#2A2A2A] rounded-xl px-3.5 py-2.5 text-xs text-white"
              >
                <option value="Lỗi Âm Thanh/Loa">Lỗi Âm Thanh / Mất Tiếng Loa</option>
                <option value="Lỗi Đèn LED">Lỗi Đèn LED Không Sáng</option>
                <option value="Lỗi Nhận Thẻ/Buckle">Lỗi Nhận Thẻ / Buckle / Item Khóa</option>
                <option value="Hỏng Nút Bấm">Kẹt Công Tắc / Nút Bấm Cơ</option>
                <option value="Khác">Khác...</option>
              </select>
            </div>

            <div>
              <label className="block font-bold text-gray-400 uppercase text-[10px] mb-1">Mô tả tình trạng lỗi chi tiết *</label>
              <textarea 
                required
                value={desc}
                onChange={(e) => setDesc(e.target.value)}
                placeholder="Vui lòng mô tả chi tiết lỗi chập pin, rè loa hay sai hiệu ứng..."
                className="w-full bg-[#0D0D0D] border border-[#2A2A2A] rounded-xl p-3 text-xs text-white h-24 resize-none"
              ></textarea>
            </div>

            <button 
              type="submit"
              className="w-full py-3.5 bg-gradient-to-r from-[#C9A84C] to-[#a27e2a] text-[#0A0A0A] font-extrabold text-xs rounded-xl shadow-lg hover:brightness-110"
            >
              Gửi Yêu Cầu Bảo Hành
            </button>
          </form>
        </div>
      </div>
    </div>
  );
};
